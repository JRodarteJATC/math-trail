"""Writes one Kahoot import spreadsheet per grade from exports/questions.json.
Layout follows Kahoot's own template: headers on row 8, questions from row 9, columns B to H.
Needs: pip install openpyxl"""
import json, os
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment

root = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'exports')
data = json.load(open(os.path.join(root, 'questions.json'), encoding='utf-8'))
HEAD = ['Question - max 120 characters', 'Answer 1 - max 75 characters', 'Answer 2 - max 75 characters', 'Answer 3 - max 75 characters',
        'Answer 4 - max 75 characters', 'Time limit (sec) – 5, 10, 20, 30, 60, 90, 120, or 240 secs', 'Correct answer(s) - choose at least one']
for grade, quiz in data.items():
    wb = Workbook(); ws = wb.active; ws.title = 'Sheet1'
    ws['B2'] = 'Quiz template'; ws['B2'].font = Font(bold=True, size=16)
    ws['B3'] = 'Add questions, at least two answer alternatives, time limit and choose correct answers (at least one). Have fun creating your awesome quiz!'
    ws['B4'] = 'Remember: questions have a limit of 120 characters and answers can have 75 characters max. Text will turn red in Excel or Google Docs if you exceed this limit.'
    ws['B5'] = quiz['title']
    for c, h in enumerate(HEAD, start=2):
        cell = ws.cell(row=8, column=c, value=h); cell.font = Font(bold=True); cell.alignment = Alignment(wrap_text=True, vertical='top')
    for i, r in enumerate(quiz['rows']):
        row = 9 + i
        ws.cell(row=row, column=1, value=i + 1)
        ws.cell(row=row, column=2, value=r['q'])
        for k in range(4):
            if k < len(r['answers']): ws.cell(row=row, column=3 + k, value=r['answers'][k])
        ws.cell(row=row, column=7, value=r['time'])
        ws.cell(row=row, column=8, value=r['correct'])
    ws.column_dimensions['A'].width = 5; ws.column_dimensions['B'].width = 70
    for col in 'CDEF': ws.column_dimensions[col].width = 26
    ws.column_dimensions['G'].width = 22; ws.column_dimensions['H'].width = 22
    name = os.path.join(root, 'kahoot', f'math-trail-grade-{int(grade):02d}.xlsx')
    wb.save(name); print('wrote', os.path.basename(name), len(quiz['rows']), 'questions')
