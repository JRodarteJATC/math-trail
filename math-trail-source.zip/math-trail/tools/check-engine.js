// Stress test: run every puzzle maker many times and check the answers hold up. Also checks the lessons and the maze breaks.
// Usage: node tools/check-engine.js [--samples]
const path = require('path');
for (const f of ['core', 'grades-1-4', 'grades-5-8', 'grades-9-12', 'lessons-1-6', 'lessons-7-12', 'maze-data']) require(path.join(__dirname, '..', 'js', f + '.js'));
const MT = globalThis.MT, RUNS = 600, samples = process.argv.includes('--samples');
let bad = 0, total = 0, evald = 0;
const fail = (where, msg, q) => { bad++; if (bad < 40) console.log('FAIL', where, '-', msg, q ? JSON.stringify(q).slice(0, 220) : ''); };
// independent arithmetic check for plain prompts such as "34 × 6 = ?"
const plainExpr = s => /^[\d\s().+\-×÷^]+ = \?$/.test(s) && !s.includes('..');
const evalExpr = s => Function('"use strict";return (' + s.replace(' = ?', '').replace(/×/g, '*').replace(/÷/g, '/').replace(/\^/g, '**') + ')')();

const kinds = {};
for (const gr of MT.grades) {
  if (gr.sections.length !== 5) fail(`grade ${gr.grade}`, 'expected 5 sections');
  gr.sections.forEach((sec, si) => sec.gens.forEach((gen, gi) => {
    const where = `G${gr.grade} "${sec.name}" #${gi + 1}`;
    for (let r = 0; r < RUNS; r++) {
      let q;
      try { q = gen(); } catch (e) { fail(where, 'threw: ' + e.message); break; }
      total++; kinds[q.kind] = (kinds[q.kind] || 0) + 1;
      if (!q.q || /undefined|NaN|Infinity\b/.test(JSON.stringify([q.q, q.opts, q.a, q.why, q.L, q.R, q.items, q.pairs, q.tiles]))) fail(where, 'bad text', q);
      if (q.kind === 'choice') {
        if (q.opts.length !== 4 || new Set(q.opts).size !== 4) fail(where, 'options not 4 distinct', q);
        if (!(q.a >= 0 && q.a < 4)) fail(where, 'answer index', q);
        // numeric options must not tie in value with the right answer
        const val = MT.value(q.opts[q.a].replace(/[{}]/g, ''));
        if (!Number.isNaN(val)) q.opts.forEach((o, i) => { if (i !== q.a && Math.abs(MT.value(o.replace(/[{}]/g, '')) - val) < 1e-9) fail(where, 'two options with the same value', q); });
        if (plainExpr(q.q) && !Number.isNaN(val)) { evald++; if (Math.abs(evalExpr(q.q) - val) > 1e-6) fail(where, 'arithmetic mismatch', q); }
      } else if (q.kind === 'input') {
        const v = MT.value(q.a);
        if (!Number.isFinite(v)) fail(where, 'answer is not a number', q);
        if (String(q.a).replace('-', '').length > 9) fail(where, 'answer too long to type', q);
        if (plainExpr(q.q)) { evald++; if (Math.abs(evalExpr(q.q) - v) > 1e-6) fail(where, 'arithmetic mismatch', q); }
      } else if (q.kind === 'tf') { if (typeof q.a !== 'boolean') fail(where, 'tf answer', q);
        const m = /^([\d\s().+\-×÷^]+) = (-?[\d.]+)$/.exec(q.q); if (m) { evald++; if ((Math.abs(evalExpr(m[1]) - +m[2]) < 1e-6) !== q.a) fail(where, 'true/false mismatch', q); }
      } else if (q.kind === 'compare') { if (!['<', '=', '>'].includes(q.a)) fail(where, 'sign', q);
      } else if (q.kind === 'order') { const vs = q.items.map(i => i.v); if (q.items.length < 3 || new Set(vs).size !== vs.length) fail(where, 'order items', q);
      } else if (q.kind === 'match') { if (q.pairs.length !== 4) fail(where, 'pairs', q);
      } else if (q.kind === 'pick') { const k = q.tiles.filter(t => t.ok).length; if (!k || k === q.tiles.length || new Set(q.tiles.map(t => t.t)).size !== q.tiles.length) fail(where, 'tiles', q);
      } else if (q.kind === 'target') { const n = q.tiles.length; let ok = false; for (let m = 1; m < 1 << n; m++) { let s = 0; for (let i = 0; i < n; i++) if (m >> i & 1) s += q.tiles[i]; if (s === q.T) ok = true; } if (!ok) fail(where, 'target unreachable', q);
      } else fail(where, 'unknown kind ' + q.kind);
      if (samples && r === 0) console.log(`${where} [${q.kind}] ${q.q}${q.L ? ` :: ${q.L} ? ${q.R}` : ''} => ${q.kind === 'choice' ? q.opts[q.a] + '   (others: ' + q.opts.filter((_, i) => i !== q.a).join(' | ') + ')' : q.kind === 'pick' ? q.tiles.map(t => (t.ok ? '[' + t.t + ']' : t.t)).join(' ') : q.kind === 'match' ? q.pairs.map(x => x.join('→')).join('; ') : q.kind === 'order' ? q.items.map(i => i.t).join(' ') : q.kind === 'target' ? q.tiles.join(' ') + ' → ' + q.T : q.a}`);
    }
  }));
}
// every topic needs a full lesson with all its parts
let lessons = 0;
for (const gr of MT.grades) gr.sections.forEach((sec, i) => {
  const les = MT.lessons[MT.sectionId(gr.grade, i)], where = `G${gr.grade} "${sec.name}" lesson`;
  if (!les) return fail(where, 'missing');
  lessons++;
  if (!les.idea || !les.watch || !(les.steps && les.steps.length >= 3) || !(les.ex && les.ex.length >= 2 && les.ex.every(e => e.length === 2))) fail(where, 'incomplete');
  if (/undefined|NaN/.test(MT.lessonHtml(sec, les))) fail(where, 'bad text');
});
console.log(`${lessons} full lessons`);

// every maze break must be solvable under the game's own rules (walls, locked doors, pick up everything first)
const TURN = { N: [1, -1, 0], E: [2, 0, 1], S: [4, 1, 0], W: [8, 0, -1] }, BACK = { 1: 4, 2: 8, 4: 1, 8: 2 };
function checkMaze(m, where) {
  const bits = (r, c) => parseInt(m.open[r][c], 16), inside = (r, c) => r >= 0 && c >= 0 && r < m.rows && c < m.cols;
  if (m.open.length !== m.rows || m.open.some(row => row.length !== m.cols)) return fail(where, 'grid size');
  for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++) for (const [bit, dr, dc] of Object.values(TURN)) {
    if (!(bits(r, c) & bit)) continue;
    if (!inside(r + dr, c + dc) || !(bits(r + dr, c + dc) & BACK[bit])) return fail(where, `wall mismatch at ${r},${c}`);
  }
  // the hint lines must follow open passages
  const walkLetters = (r, c, letters) => { for (const ch of letters) { const [bit, dr, dc] = TURN[ch]; if (!(bits(r, c) & bit)) return null; r += dr; c += dc; } return [r, c]; };
  const tip = walkLetters(m.start[0], m.start[1], m.path);
  if (!tip || tip[0] !== m.end[0] || tip[1] !== m.end[1]) fail(where, 'hint path does not reach the finish');
  for (const b of m.branches) if (!walkLetters(b[0], b[1], b[2])) fail(where, 'hint side trip crosses a wall');
  const cellsSeen = new Set(m.items.map(it => it.r + ',' + it.c));
  if (cellsSeen.size !== m.items.length || cellsSeen.has(m.start.join()) || cellsSeen.has(m.end.join())) fail(where, 'items overlap');
  for (const d of m.doors || []) if (!m.items.some(it => it.key === d.k)) fail(where, 'door without a key');

  // play it: always walk to the nearest thing still to pick up, then to the finish
  const got = new Set(), hasKey = k => got.has(m.items.findIndex(it => it.key === k));
  const itemAt = (r, c) => m.items.findIndex(it => it.r === r && it.c === c);
  const routeTo = (from, want) => {
    const prev = new Map([[from.join(), null]]); let frontier = [from];
    while (frontier.length) {
      const next = [];
      for (const [r, c] of frontier) for (const [bit, dr, dc] of Object.values(TURN)) {
        const n = [r + dr, c + dc], key = n.join();
        if (!(bits(r, c) & bit) || prev.has(key)) continue;
        const door = (m.doors || []).find(d => d.r === n[0] && d.c === n[1]);
        if (door && !hasKey(door.k)) continue;
        prev.set(key, [r, c]);
        if (want(n)) { const route = []; let x = n; while (x) { route.unshift(x); x = prev.get(x.join()); } return route; }
        next.push(n);
      }
      frontier = next;
    }
    return null;
  };
  let pos = m.start, steps = 0;
  while (got.size < m.items.length) {
    const route = routeTo(pos, n => { const i = itemAt(n[0], n[1]); return i >= 0 && !got.has(i); });
    if (!route) return fail(where, `cannot reach ${m.items.length - got.size} of the items`);
    steps += route.length - 1; pos = route[route.length - 1]; got.add(itemAt(pos[0], pos[1]));
  }
  if (pos[0] !== m.end[0] || pos[1] !== m.end[1]) {
    const route = routeTo(pos, n => n[0] === m.end[0] && n[1] === m.end[1]);
    if (!route) return fail(where, 'cannot reach the finish');
    steps += route.length - 1;
  }
  if (steps < m.walk) fail(where, `"walk" says ${m.walk} but ${steps} steps is enough`);

  // small mazes without doors: search every order to confirm "walk" really is the fewest steps
  if (m.items.length <= 9 && !m.doors) {
    const full = (1 << m.items.length) - 1, seen = new Set([m.start.join() + ',0']);
    let frontier = [[m.start[0], m.start[1], 0]], d = 0, best = -1;
    while (frontier.length && best < 0) {
      const next = [];
      for (const [r, c, mask] of frontier) {
        if (mask === full && r === m.end[0] && c === m.end[1]) { best = d; break; }
        for (const [bit, dr, dc] of Object.values(TURN)) {
          if (!(bits(r, c) & bit)) continue;
          const i = itemAt(r + dr, c + dc), nm = i >= 0 ? mask | 1 << i : mask, key = `${r + dr},${c + dc},${nm}`;
          if (!seen.has(key)) { seen.add(key); next.push([r + dr, c + dc, nm]); }
        }
      }
      frontier = next; d++;
    }
    if (best !== m.walk) fail(where, `"walk" is ${m.walk} but the fewest steps is ${best}`);
    return 'exact';
  }
  return 'played';
}
const mazes = MT.mazes || [];
if (mazes.length !== MT.grades.length * 3) fail('mazes', `expected ${MT.grades.length * 3}, found ${mazes.length}`);
let exact = 0;
mazes.forEach((m, i) => { if (checkMaze(m, `maze ${i + 1} "${m.title}"`) === 'exact') exact++; });
console.log(`${mazes.length} maze breaks solved (${exact} with the fewest steps confirmed by full search)`);
const gens = MT.grades.reduce((a, g) => a + g.sections.reduce((b, s) => b + s.gens.length, 0), 0);
console.log(`\n${MT.grades.length} grades, ${MT.grades.length * 5} sections, ${gens} puzzle makers, ${total} puzzles generated, ${evald} re-computed independently`);
console.log('kinds:', Object.entries(kinds).map(([k, v]) => `${k} ${Math.round(v / RUNS)}`).join(', '));
console.log(bad ? `FAILURES: ${bad}` : 'All checks passed');
process.exit(bad ? 1 : 0);
