// Stress test: run every puzzle maker many times and check the answers hold up.
// Usage: node tools/check-engine.js [--samples]
const path = require('path');
for (const f of ['core', 'grades-1-4', 'grades-5-8', 'grades-9-12']) require(path.join(__dirname, '..', 'js', f + '.js'));
const MT = globalThis.MT, RUNS = 600, samples = process.argv.includes('--samples');
let bad = 0, total = 0, evald = 0;
const fail = (where, msg, q) => { bad++; if (bad < 40) console.log('FAIL', where, '-', msg, q ? JSON.stringify(q).slice(0, 220) : ''); };
// independent arithmetic check for plain prompts such as "34 × 6 = ?"
const plainExpr = s => /^[\d\s().+\-×÷^]+ = \?$/.test(s) && !s.includes('..');
const evalExpr = s => Function('"use strict";return (' + s.replace(' = ?', '').replace(/×/g, '*').replace(/÷/g, '/').replace(/\^/g, '**') + ')')();

const kinds = {};
for (const gr of MT.grades) {
  if (gr.sections.length !== 5) fail(`grade ${gr.grade}`, 'expected 5 sections');
  gr.sections.forEach((sec, si) => sec.gens.forEach((gen, gi) => {
    const where = `G${gr.grade} "${sec.name}" #${gi + 1}`;
    for (let r = 0; r < RUNS; r++) {
      let q;
      try { q = gen(); } catch (e) { fail(where, 'threw: ' + e.message); break; }
      total++; kinds[q.kind] = (kinds[q.kind] || 0) + 1;
      if (!q.q || /undefined|NaN|Infinity\b/.test(JSON.stringify([q.q, q.opts, q.a, q.why, q.L, q.R, q.items, q.pairs, q.tiles]))) fail(where, 'bad text', q);
      if (q.kind === 'choice') {
        if (q.opts.length !== 4 || new Set(q.opts).size !== 4) fail(where, 'options not 4 distinct', q);
        if (!(q.a >= 0 && q.a < 4)) fail(where, 'answer index', q);
        // numeric options must not tie in value with the right answer
        const val = MT.value(q.opts[q.a].replace(/[{}]/g, ''));
        if (!Number.isNaN(val)) q.opts.forEach((o, i) => { if (i !== q.a && Math.abs(MT.value(o.replace(/[{}]/g, '')) - val) < 1e-9) fail(where, 'two options with the same value', q); });
        if (plainExpr(q.q) && !Number.isNaN(val)) { evald++; if (Math.abs(evalExpr(q.q) - val) > 1e-6) fail(where, 'arithmetic mismatch', q); }
      } else if (q.kind === 'input') {
        const v = MT.value(q.a);
        if (!Number.isFinite(v)) fail(where, 'answer is not a number', q);
        if (String(q.a).replace('-', '').length > 9) fail(where, 'answer too long to type', q);
        if (plainExpr(q.q)) { evald++; if (Math.abs(evalExpr(q.q) - v) > 1e-6) fail(where, 'arithmetic mismatch', q); }
      } else if (q.kind === 'tf') { if (typeof q.a !== 'boolean') fail(where, 'tf answer', q);
        const m = /^([\d\s().+\-×÷^]+) = (-?[\d.]+)$/.exec(q.q); if (m) { evald++; if ((Math.abs(evalExpr(m[1]) - +m[2]) < 1e-6) !== q.a) fail(where, 'true/false mismatch', q); }
      } else if (q.kind === 'compare') { if (!['<', '=', '>'].includes(q.a)) fail(where, 'sign', q);
      } else if (q.kind === 'order') { const vs = q.items.map(i => i.v); if (q.items.length < 3 || new Set(vs).size !== vs.length) fail(where, 'order items', q);
      } else if (q.kind === 'match') { if (q.pairs.length !== 4) fail(where, 'pairs', q);
      } else if (q.kind === 'pick') { const k = q.tiles.filter(t => t.ok).length; if (!k || k === q.tiles.length || new Set(q.tiles.map(t => t.t)).size !== q.tiles.length) fail(where, 'tiles', q);
      } else if (q.kind === 'target') { const n = q.tiles.length; let ok = false; for (let m = 1; m < 1 << n; m++) { let s = 0; for (let i = 0; i < n; i++) if (m >> i & 1) s += q.tiles[i]; if (s === q.T) ok = true; } if (!ok) fail(where, 'target unreachable', q);
      } else fail(where, 'unknown kind ' + q.kind);
      if (samples && r === 0) console.log(`${where} [${q.kind}] ${q.q}${q.L ? ` :: ${q.L} ? ${q.R}` : ''} => ${q.kind === 'choice' ? q.opts[q.a] + '   (others: ' + q.opts.filter((_, i) => i !== q.a).join(' | ') + ')' : q.kind === 'pick' ? q.tiles.map(t => (t.ok ? '[' + t.t + ']' : t.t)).join(' ') : q.kind === 'match' ? q.pairs.map(x => x.join('→')).join('; ') : q.kind === 'order' ? q.items.map(i => i.t).join(' ') : q.kind === 'target' ? q.tiles.join(' ') + ' → ' + q.T : q.a}`);
    }
  }));
}
const gens = MT.grades.reduce((a, g) => a + g.sections.reduce((b, s) => b + s.gens.length, 0), 0);
console.log(`\n${MT.grades.length} grades, ${MT.grades.length * 5} sections, ${gens} puzzle makers, ${total} puzzles generated, ${evald} re-computed independently`);
console.log('kinds:', Object.entries(kinds).map(([k, v]) => `${k} ${Math.round(v / RUNS)}`).join(', '));
console.log(bad ? `FAILURES: ${bad}` : 'All checks passed');
process.exit(bad ? 1 : 0);
