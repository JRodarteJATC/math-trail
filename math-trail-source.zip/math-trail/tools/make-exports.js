// Builds question sets for Kahoot and Blooket from the same puzzle makers the game uses.
// Usage: node tools/make-exports.js        (then: python3 tools/make-kahoot-xlsx.py)
// Blooket takes the CSV files directly. Kahoot needs .xlsx, which the Python step writes.
const fs = require('fs'), path = require('path');
for (const f of ['core', 'grades-1-4', 'grades-5-8', 'grades-9-12']) require(path.join(__dirname, '..', 'js', f + '.js'));
const MT = globalThis.MT, PER_SECTION = 5, out = path.join(__dirname, '..', 'exports');
fs.mkdirSync(path.join(out, 'blooket'), { recursive: true });
fs.mkdirSync(path.join(out, 'kahoot'), { recursive: true });

// plain text for other apps: {3/4} -> 3/4, the box -> ___
const plain = s => String(s).replace(/\{([^{}\/]+)\/([^{}]+)\}/g, (_, a, b) => (/\s/.test(a + b) ? `(${a})/(${b})` : `${a}/${b}`)).replace(/☐/g, '___').replace(/\s+/g, ' ').trim();
// turn a puzzle into a multiple-choice question, or null if it needs a picture or tapping
function toQuiz(q) {
  if (q.fig) return null;
  if (q.kind === 'choice') return { q: plain(q.q), answers: q.opts.map(plain), correct: q.a + 1 };
  if (q.kind === 'tf') return { q: 'True or false? ' + plain(q.q), answers: ['True', 'False'], correct: q.a ? 1 : 2 };
  if (q.kind === 'compare') return { q: `Which sign makes this true?  ${plain(q.L)}  ___  ${plain(q.R)}`, answers: ['<', '=', '>'], correct: ['<', '=', '>'].indexOf(q.a) + 1 };
  if (q.kind === 'input' && typeof q.a === 'number') {
    const opts = MT.shuffle([q.a, ...MT.near(q.a).slice(0, 3)]);
    return opts.length === 4 ? { q: plain(q.q), answers: opts.map(String), correct: opts.indexOf(q.a) + 1 } : null;
  }
  return null;
}
const csv = v => (/[",\n]/.test(String(v)) ? '"' + String(v).replace(/"/g, '""') + '"' : String(v));
const all = {};
for (const gr of MT.grades) {
  const rows = [], seen = new Set(), time = gr.grade <= 3 ? 20 : gr.grade <= 8 ? 30 : 60;
  for (const sec of gr.sections) {
    let got = 0, guard = 0;
    while (got < PER_SECTION && guard++ < 600) {
      const z = toQuiz(sec.gens[guard % sec.gens.length]());
      if (!z || seen.has(z.q) || z.q.length > 95 || z.answers.some(a => a.length > 60)) continue;   // Kahoot's safe limits
      seen.add(z.q); rows.push({ ...z, time, section: sec.name }); got++;
    }
  }
  all[gr.grade] = { title: `Math Trail - Grade ${gr.grade}: ${gr.title}`, rows };
  const id = String(gr.grade).padStart(2, '0');
  const lines = [
    ['Blooket\nImport Template', '', '', '', '', '', '', ''],
    ['Question #', 'Question Text', 'Answer 1', 'Answer 2', 'Answer 3\n(Optional)', 'Answer 4\n(Optional)', 'Time Limit (sec)\n(Max: 300 seconds)', 'Correct Answer(s)\n(Only include Answer #)'],
    ...rows.map((r, i) => [i + 1, r.q, r.answers[0], r.answers[1], r.answers[2] || '', r.answers[3] || '', r.time, r.correct]),
  ];
  fs.writeFileSync(path.join(out, 'blooket', `math-trail-grade-${id}.csv`), lines.map(l => l.map(csv).join(',')).join('\n') + '\n');
  console.log(`grade ${gr.grade}: ${rows.length} questions`);
}
fs.writeFileSync(path.join(out, 'questions.json'), JSON.stringify(all, null, 1));
