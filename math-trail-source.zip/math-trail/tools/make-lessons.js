// Builds printable lesson pages, one file per grade, in the lessons folder.
// Usage: node tools/make-lessons.js      (open a file in a browser and print, or save as PDF)
// Use these with Kahoot and Blooket, which hold questions only: teach the lesson first, then play the quiz.
const fs = require('fs'), path = require('path');
for (const f of ['core', 'grades-1-4', 'grades-5-8', 'grades-9-12', 'lessons-1-6', 'lessons-7-12']) require(path.join(__dirname, '..', 'js', f + '.js'));
const MT = globalThis.MT, out = path.join(__dirname, '..', 'lessons');
fs.mkdirSync(out, { recursive: true });
const ACCENT = ['#23794a', '#c9461f', '#14709f', '#5546cf'];

const css = accent => `
/*FONTS*/@import url("https://fonts.googleapis.com/css2?family=Fredoka:wght@500;600&family=Nunito:wght@400;700;800&display=swap");
@page{size:Letter;margin:0.6in 0.7in}
*{box-sizing:border-box}
html{background:#fff}
body{margin:0 auto;max-width:7.1in;padding:0 16px;font-family:Nunito,"Avenir Next","Segoe UI",sans-serif;font-size:12.5pt;line-height:1.5;color:#1d2a2e;--accent:${accent}}
h1,h2,h3,p,ol,dl,figure{margin:0}
.page{page-break-after:always;break-after:page;padding:10px 0;display:flex;flex-direction:column;gap:10pt}
.page:last-child{page-break-after:auto;break-after:auto}
.label{font-size:9.5pt;font-weight:800;letter-spacing:.09em;text-transform:uppercase;color:var(--accent)}
h1{font:600 30pt/1.1 Fredoka,"Arial Rounded MT Bold",sans-serif}
h2{font:600 24pt/1.15 Fredoka,"Arial Rounded MT Bold",sans-serif}
.lz{display:flex;flex-direction:column;gap:5pt}
.lz h3{font-size:9.5pt;font-weight:800;letter-spacing:.09em;text-transform:uppercase;color:#566669}
.idea{font-size:15pt;font-weight:700}
.steps{padding-left:1.4em;display:flex;flex-direction:column;gap:3pt}
.steps li::marker{font-weight:800;color:var(--accent)}
.exs{display:grid;grid-template-columns:1fr 1fr;gap:10pt}
.ex{border:1.5pt solid #cbd6c9;border-radius:9pt;padding:8pt 10pt;break-inside:avoid}
.ex-q{font:600 14pt/1.3 Fredoka,"Arial Rounded MT Bold",sans-serif;margin-bottom:3pt}
.watch{border:1.5pt solid #c98a00;border-radius:9pt;padding:8pt 10pt;background:#fdf6e3;break-inside:avoid}
.watch h3{color:#1d2a2e}
.words div{display:grid;grid-template-columns:1.9in 1fr;gap:0 10pt}
.words dt{font-weight:800}
.words dd{margin:0}
.lz-fig{display:flex;flex-direction:column;align-items:center;gap:3pt}
.lz-fig figcaption{font-size:11pt;color:#566669}
.fig{height:1.1in;width:auto;max-width:100% !important}
.toc{padding-left:1.4em;font-size:14pt;display:flex;flex-direction:column;gap:4pt}
.note{border:1.5pt solid var(--accent);border-radius:9pt;padding:9pt 11pt}
.foot{font-size:9.5pt;color:#566669}
.fr{display:inline-flex;flex-direction:column;align-items:center;vertical-align:middle;font-size:.82em;line-height:1.12;margin:0 .12em}
.fr span:first-child{border-bottom:.09em solid currentColor;padding:0 .2em}
.fr span:last-child{padding:0 .2em}
sup{font-size:.62em;line-height:0}
.f-fill{fill:var(--accent)} .f-empty{fill:#fff} .f-soft{fill:#e6efe6}
.f-edge{stroke:#1d2a2e;stroke-width:2} .f-face{fill:#fff;stroke:#1d2a2e;stroke-width:3}
.f-line{stroke:#1d2a2e;stroke-width:1.5} .f-hand{stroke:#1d2a2e;stroke-linecap:round} .f-ink{fill:#1d2a2e}
.f-text{fill:#1d2a2e;font-family:Nunito,sans-serif;font-weight:800;text-anchor:middle} .f-num{fill:#566669;font-family:Nunito,sans-serif;text-anchor:middle}
.f-grid{stroke:#cbd6c9;stroke-width:1} .f-axis{stroke:#1d2a2e;stroke-width:1.6}
.f-plot{stroke:var(--accent);stroke-width:3;stroke-linecap:round} .f-pt{fill:var(--accent);stroke:#fff;stroke-width:2}
@media screen{.page{border-bottom:2px dashed #cbd6c9}}
`;

for (const gr of MT.grades) {
  const g = gr.grade, id = String(g).padStart(2, '0');
  const cover = `<section class="page">
    <p class="label">Math Trail lesson book</p>
    <h1>Grade ${g} lessons</h1>
    <p class="idea">${MT.esc(gr.title)}</p>
    <div class="lz"><h3>In this book</h3><ol class="toc">${gr.sections.map(s => `<li>${MT.esc(s.name)}</li>`).join('')}</ol></div>
    <div class="note lz"><h3>How to use it</h3><p>Read one lesson together, then practice it. Each lesson matches 5 questions in the Grade ${g} Kahoot and Blooket sets, and one stop on the Grade ${g} trail in the Math Trail app.</p></div>
    <p class="foot">Every lesson has the big idea, the steps, two worked examples, one mistake to watch for, and the words to know.</p>
  </section>`;
  const pages = gr.sections.map((s, i) => `<section class="page">
    <p class="label">Grade ${g} · Lesson ${i + 1} of 5</p>
    <h2>${MT.esc(s.name)}</h2>
    ${MT.lessonHtml(s, MT.lessons[MT.sectionId(g, i)])}
  </section>`).join('\n');
  const html = `<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<title>Math Trail lessons: Grade ${g}</title>\n<style>${css(ACCENT[Math.ceil(g / 3) - 1])}</style>\n</head>\n<body>\n${cover}\n${pages}\n</body>\n</html>\n`;
  fs.writeFileSync(path.join(out, `grade-${id}-lessons.html`), html);
}
console.log('wrote', MT.grades.length, 'lesson books to', out);
