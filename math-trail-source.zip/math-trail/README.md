# Math Trail

Math puzzles for grades 1 to 12. Each grade is a trail of six stops: five topics and a mixed challenge. A player reads the lesson, solves 8 puzzles with 3 hearts, and must pass a stop to unlock the next one.

- 60 topics, each with a full lesson, and 265 puzzle makers. Numbers are random, so every round is different.
- 8 kinds of puzzle: tap the answer, type the answer, true or false, pick the sign, put in order, match the pairs, tap all that fit, make the number.
- 36 maze breaks, three per grade. Passing stops 2, 4 and 6 of a grade each unlocks a pick-it-up maze as a reward.
- Progress (stars and maze wins) is saved in the browser on that device. There are no accounts and nothing is sent anywhere.
- Plain HTML, CSS and JavaScript. No build step, no dependencies.

## Lessons

Every topic has a full lesson: the big idea, the steps, two worked examples, one mistake to watch for, and the words to know.

- **In the app:** the lesson opens before each stop, and "Read all Grade N lessons" on a trail shows the five lessons on one page.
- **For Kahoot and Blooket:** those sites hold questions only, so the lessons are in the `lessons` folder as one printable book per grade (PDF, plus the HTML it was made from). Teach the lesson, then play the quiz.

Lesson text lives in `js/lessons-1-6.js` and `js/lessons-7-12.js`. After editing, run `node tools/make-lessons.js` to rebuild the HTML books, then print them to PDF from a browser.

## Maze breaks

Every second stop on a trail unlocks a maze. The player picks up every item, then reaches the finish. Mazes are optional: the next stop is open either way.

- Grades 1 to 4 get the starter mazes (6 by 6 up to 18 by 18 squares).
- Grades 5 to 8 get the hard mazes (18 by 18 up to 30 by 34), with more wrong turns and side trips.
- Grades 9 to 12 get the biggest mazes (up to 40 by 46), with locked doors that need a key.

Move with the arrow keys, by dragging through the maze, or with the on-screen arrows. "Show the way" draws the route for a few seconds.

The game is `js/maze.js` and the 36 mazes are in `js/maze-data.js` (the format is described at the top of that file).

## Run it

Open `index.html` in a browser.

## Put it on GitHub Pages

1. Create a new repository on GitHub and upload everything in this folder (keep the folder structure).
2. In the repository, open **Settings > Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, pick the `main` branch and the `/ (root)` folder, then save.
4. After a minute the site is live at `https://YOUR-USERNAME.github.io/YOUR-REPO/`.

## Put it on Firebase Hosting

`firebase.json` is already set up to serve this folder.

1. Create a project at https://console.firebase.google.com
2. Install the tools once: `npm install -g firebase-tools`
3. In this folder run `firebase login`, then `firebase use --add` and pick your project.
4. Run `firebase deploy --only hosting`.

## Kahoot and Blooket

Kahoot and Blooket do not host apps. They run quizzes from question sets, so the `exports` folder has a ready-made set for every grade (25 multiple-choice questions each, 5 per topic).

- **Kahoot:** files in `exports/kahoot/*.xlsx`. In the Kahoot creator choose **Add question > Import > Import spreadsheet** and upload a file.
- **Blooket:** files in `exports/blooket/*.csv`. When creating a set choose **CSV Import** (or **Spreadsheet Import** inside an existing set) and upload a file. If Blooket rejects a file, open its own template and paste the rows in.

Picture puzzles and the tap-to-sort kinds only exist in the app, so the quiz sets use the question types those sites support.

To make fresh question sets with new numbers:

```
node tools/make-exports.js
python3 tools/make-kahoot-xlsx.py     # needs: pip install openpyxl
```

## Change or add questions

Topics live in `js/grades-1-4.js`, `js/grades-5-8.js` and `js/grades-9-12.js`. Each topic has a `tip` (the mini lesson) and a list of `gens`, small functions that each return one puzzle. The builders (`mc`, `num`, `tf`, `cmp`, `ord`, `matchOf`, `pickFrom`, `target`) are in `js/core.js`.

After editing, run the checker. It generates 159,000 puzzles and tests every answer, checks that all 60 lessons are complete, and plays all 36 mazes:

```
node tools/check-engine.js
```

Rules of the game (puzzles per stop, hearts) are the constants at the top of `js/app.js`. Which stops unlock a maze is set by `mazeAfter` and `mazeOpen` in the same file.
