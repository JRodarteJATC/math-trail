/* Math Trail - grades 9 to 12 (algebra, geometry, algebra 2, pre-calculus and calculus). */
(function () {
  const { rnd, ri, pick, shuffle, range, distinct, nz, rd, fact, fr, p, poly, lin, mono, fac, facs, cx, mc, mcn, num, tf, matchOf, pickAll, figTri } = MT;
  const SUB = '₀₁₂₃₄₅₆₇₈₉', sub = n => String(n).split('').map(c => SUB[c]).join('');
  const quadCount = () => {                       // a quadratic with 0, 1 or 2 real solutions
    const kind = pick([0, 1, 2]);
    if (kind === 2) { const [r, s] = distinct(2, -6, 6); return { cs: [1, -(r + s), r * s], n: 'Two' }; }
    if (kind === 1) { const r = nz(-6, 6); return { cs: [1, -2 * r, r * r], n: 'One' }; }
    const h = ri(-3, 3), k = ri(1, 9); return { cs: [1, -2 * h, h * h + k], n: 'None' };
  };
  const disc = ([a, b, c]) => b * b - 4 * a * c;

  MT.grades.push({
    grade: 9, title: 'Algebra: polynomials, factoring and quadratics', sections: [
      { name: 'Polynomials', tip: 'Like terms have the same letter and power, so you can combine them: 3x + 2x = 5x. To expand brackets, multiply everything inside. (x + 2)(x + 3) = x^2 + 3x + 2x + 6 = x^2 + 5x + 6.', gens: [
        () => { const a = ri(2, 9), c = ri(2, 9), b = ri(2, 12), d = ri(1, 12); return mc(`Simplify: ${a}x + ${b} + ${c}x - ${d}`, lin(a + c, b - d), [lin(a + c, b + d), lin(a * c, b - d), lin(a + c + b, -d), lin(a + c, d - b || 1), lin(a + c + 1, b - d)], `x terms: ${a}x + ${c}x = ${a + c}x. Numbers: ${b} - ${d} = ${b - d}.`); },
        () => { const a = ri(2, 6), b = ri(2, 6), c = ri(1, 9); return mc(`Expand: ${a}(${lin(b, -c)})`, lin(a * b, -a * c), [lin(a * b, -c), lin(a + b, -a * c), lin(a * b, a * c), lin(b, -a * c)], `Multiply both terms by ${a}: ${a * b}x and ${a * c}.`); },
        () => { const a = nz(-6, 6), b = nz(-6, 6); return mc(`Expand: ${fac(a)}${fac(b)}`, poly([1, a + b, a * b]), [poly([1, a * b, a + b]), poly([1, a + b, -a * b]), poly([1, a - b, a * b]), poly([1, 0, a * b]), poly([1, a + b + 1, a * b])], `First, outer, inner, last: x^2 ${a < 0 ? '-' : '+'} ${Math.abs(a)}x ${b < 0 ? '-' : '+'} ${Math.abs(b)}x ${a * b < 0 ? '-' : '+'} ${Math.abs(a * b)}.`); },
        () => { const a = ri(1, 3), b = nz(-5, 5), c = ri(-9, 9), x = ri(-3, 4); return num(`If x = ${x}, what is ${poly([a, b, c])}?`, a * x * x + b * x + c, `${a === 1 ? '' : a + ' × '}${p(x)}^2 = ${a * x * x}, ${b} × ${p(x)} = ${b * x}. Total: ${a * x * x + b * x + c}.`); },
      ] },
      { name: 'Factoring', tip: 'Factoring undoes expanding. For x^2 + 5x + 6, find two numbers that multiply to 6 and add to 5: they are 2 and 3. So x^2 + 5x + 6 = (x + 2)(x + 3).', gens: [
        () => { let a = nz(-7, 7), b = nz(-7, 7); if (a === -b) b = b > 0 ? b + 1 : b - 1; return mc(`Factor: ${poly([1, a + b, a * b])}`, facs(a, b), [facs(-a, -b), facs(a, -b), facs(-a, b), facs(a + 1, b - 1 || 2), facs(a * b, 1)], `Find two numbers that multiply to ${a * b} and add to ${a + b}: ${a} and ${b}.`); },
        () => { const g = ri(2, 6), [a, b] = pick([[2, 3], [3, 2], [1, 4], [3, 4], [2, 5], [5, 2], [4, 3], [1, 3]]); return mc(`Factor completely: ${poly([a * g, b * g, 0])}`, `${g}x(${lin(a, b)})`, [`${g}(${lin(a, b)})`, `x(${lin(a * g, b * g)})`, `${g}x(${lin(a, b * g)})`, `${g}x(${lin(b, a)})`], `Both terms share ${g}x. Take it out: ${g}x(${lin(a, b)}).`); },
        () => { const k = ri(2, 12); return mc(`Factor: x^2 - ${k * k}`, `(x + ${k})(x - ${k})`, [`(x - ${k})^2`, `(x + ${k})^2`, `(x + ${k * k})(x - 1)`, `x(x - ${k * k})`], `A difference of squares: a^2 - b^2 = (a + b)(a - b), with b = ${k}.`); },
        () => { const a = nz(-6, 6), b = nz(-6, 6), ok = rnd() < 0.5; return tf(`${fac(a)}${fac(b)} = ${poly([1, ok ? a + b : a * b, ok ? a * b : a + b])}`, ok || a + b === a * b, `The middle number is the sum (${a + b}) and the last number is the product (${a * b}).`); },
      ] },
      { name: 'Quadratic equations', tip: 'If two things multiply to zero, one of them is zero. (x - 2)(x - 3) = 0 means x = 2 or x = 3. So factor first, then set each bracket to zero.', gens: [
        () => { const [r, s] = distinct(2, -6, 6), bad = shuffle([-r, -s, r + s, r * s, r + 1, s - 1, 0, r - 1].filter((v, i, a) => v !== r && v !== s && a.indexOf(v) === i)).slice(0, 4); return pickAll(`Tap every solution of ${poly([1, -(r + s), r * s])} = 0.`, [{ t: String(r), ok: true }, { t: String(s), ok: true }, ...bad.map(v => ({ t: String(v), ok: false }))], `It factors to ${facs(-r, -s)} = 0, so x = ${Math.min(r, s)} or x = ${Math.max(r, s)}.`); },
        () => { const [r, s] = distinct(2, -8, 8); return num(`What is the larger solution of ${facs(-r, -s)} = 0?`, Math.max(r, s), `Each bracket can be zero: x = ${Math.min(r, s)} or x = ${Math.max(r, s)}.`); },
        () => { const { cs, n } = quadCount(); return mc(`How many real solutions does ${poly(cs)} = 0 have?`, n, ['None', 'One', 'Two', 'Three'], `b^2 - 4ac = ${disc(cs)}. ${disc(cs) > 0 ? 'Positive means two solutions.' : disc(cs) === 0 ? 'Zero means one solution.' : 'Negative means no real solutions.'}`); },
        () => { const k = ri(2, 13); return num(`x^2 = ${k * k}. What is the positive solution?`, k, `√${k * k} = ${k} (and -${k} also works).`); },
        () => { const h = nz(-6, 6), c = ri(-9, 9); return mcn(`What is the x-coordinate of the vertex of y = ${poly([1, -2 * h, c])}?`, h, `x = -b ÷ (2a) = ${2 * h} ÷ 2 = ${h}.`, [-h, 2 * h, -2 * h]); },
      ] },
      { name: 'Inequalities', tip: 'Solve an inequality like an equation, with one extra rule: when you multiply or divide by a negative number, flip the sign. -2x < 6 becomes x > -3.', gens: [
        () => { const a = ri(2, 9), b = ri(1, 12), x = nz(-6, 9); return mc(`Solve: ${a}x + ${b} > ${a * x + b}`, `x > ${x}`, [`x < ${x}`, `x > ${x + b}`, `x ≥ ${x}`, `x > ${-x}`], `Subtract ${b}, then divide by ${a}. The sign stays the same.`); },
        () => { const a = ri(2, 9), k = nz(-8, 8); return mc(`Solve: -${a}x < ${a * k}`, `x > ${-k}`, [`x < ${-k}`, `x > ${k}`, `x < ${k}`], 'Dividing by a negative number flips the sign.'); },
        () => { const a = ri(2, 5), b = ri(-6, 6), x0 = ri(-3, 5), c = a * x0 + b; return pickAll(`Tap every number that makes ${lin(a, b)} ≤ ${c} true.`, shuffle(range(x0 - 3, x0 + 3)).slice(0, 6).map(v => ({ t: String(v), ok: v <= x0 })), `Solving gives x ≤ ${x0}.`); },
        () => { const a = ri(2, 6), b = ri(1, 9), x0 = ri(-2, 6), c = a * x0 - b, v = x0 + pick([-2, -1, 0, 1, 2]); return tf(`x = ${v} makes ${a}x - ${b} ≥ ${c} true.`, v >= x0, `Solving gives x ≥ ${x0}.`); },
      ] },
      { name: 'Functions', tip: 'A function is a rule: put a number in, get one number out. If f(x) = 2x + 1, then f(3) = 2 × 3 + 1 = 7. The x-intercept is where y = 0.', gens: [
        () => { const a = ri(1, 3), b = nz(-5, 5), c = ri(-9, 9), x = ri(-3, 4); return num(`f(x) = ${poly([a, b, c])}. What is f(${x})?`, a * x * x + b * x + c, `Replace x with ${p(x)}: ${a * x * x} ${b * x < 0 ? '-' : '+'} ${Math.abs(b * x)} ${c < 0 ? '-' : '+'} ${Math.abs(c)} = ${a * x * x + b * x + c}.`); },
        () => { const a = ri(2, 5), b = ri(2, 3), x = ri(2, 4); return num(`f(x) = ${a} · ${b}^x. What is f(${x})?`, a * b ** x, `${b}^${x} = ${b ** x}, and ${a} × ${b ** x} = ${a * b ** x}.`); },
        () => { const m = nz(-5, 5), k = nz(-6, 6); return num(`Where does y = ${lin(m, -m * k)} cross the x-axis? (Give the x value.)`, k, `Set y = 0: ${m}x = ${m * k}, so x = ${k}.`); },
        () => { const m = nz(-4, 5), b = ri(-6, 6), f = x => m * x + b; return mc(`Which rule fits this table?   x: 1, 2, 3   y: ${f(1)}, ${f(2)}, ${f(3)}`, `y = ${lin(m, b)}`, [`y = ${lin(m, b + 1)}`, `y = ${lin(m + 1, b - 1)}`, `y = ${lin(-m, b)}`, `y = ${lin(m + 1, b)}`], `y changes by ${m} each step, so the slope is ${m}. Then check a point.`); },
      ] },
    ],
  });

  const POLY_NAME = { 3: 'triangle', 4: 'square', 5: 'pentagon', 6: 'hexagon', 8: 'octagon', 9: 'nonagon', 10: 'decagon', 12: 'dodecagon' };
  const SPECIAL = [['sin 30°', '{1/2}'], ['cos 60°', '{1/2}'], ['sin 45°', '{√2/2}'], ['cos 45°', '{√2/2}'], ['sin 60°', '{√3/2}'], ['cos 30°', '{√3/2}'], ['tan 45°', '1'], ['sin 90°', '1'], ['cos 90°', '0'], ['cos 0°', '1'], ['sin 0°', '0'], ['tan 60°', '√3']];
  const TRIP = [[3, 4, 5], [6, 8, 10], [5, 12, 13], [8, 15, 17], [9, 12, 15]];
  MT.grades.push({
    grade: 10, title: 'Geometry: angles, similarity, trig and circles', sections: [
      { name: 'Angles', tip: 'Angles in a triangle add to 180°. Angles on a straight line add to 180° (supplementary). Angles in a right angle add to 90° (complementary). A polygon with n sides has angles adding to (n - 2) × 180°.', gens: [
        () => { const a = ri(25, 95), b = ri(25, 150 - a); return num(`Two angles of a triangle are ${a}° and ${b}°. What is the third angle, in degrees?`, 180 - a - b, `180 - ${a} - ${b} = ${180 - a - b}.`); },
        () => { const sup = rnd() < 0.5, a = sup ? ri(20, 160) : ri(10, 80); return num(`Two angles are ${sup ? 'supplementary' : 'complementary'}. One is ${a}°. What is the other, in degrees?`, (sup ? 180 : 90) - a, `${sup ? 'Supplementary angles add to 180' : 'Complementary angles add to 90'}: ${(sup ? 180 : 90) - a}.`); },
        () => { const n = ri(5, 12); return num(`What is the sum of the interior angles of a polygon with ${n} sides, in degrees?`, (n - 2) * 180, `(${n} - 2) × 180 = ${(n - 2) * 180}.`); },
        () => { const n = pick([3, 4, 5, 6, 8, 9, 10, 12]), a = (n - 2) * 180 / n; return mcn(`How many degrees is each interior angle of a regular ${POLY_NAME[n]} (${n} sides)?`, a, `(${n} - 2) × 180 ÷ ${n} = ${a}.`, [360 / n, 180 - a === 360 / n ? a + 15 : 180 - a]); },
        () => { const a = ri(20, 160); return num(`Two straight lines cross. One angle is ${a}°. What is the angle directly opposite it?`, a, 'Opposite (vertical) angles are equal.'); },
      ] },
      { name: 'Similar triangles', tip: 'Similar shapes have the same angles, and their sides are multiplied by one scale factor. If the factor is 3, a side of 4 becomes 12. Areas are multiplied by the factor squared.', gens: [
        () => { const [a, b, c] = pick([[3, 4, 5], [4, 5, 6], [5, 7, 8], [6, 7, 9], [2, 3, 4]]), k = ri(2, 6); return num(`Two triangles are similar. The small one has sides ${a}, ${b}, ${c}. The side matching ${a} in the big one is ${a * k}. How long is the side matching ${b}?`, b * k, `The scale factor is ${a * k} ÷ ${a} = ${k}. ${b} × ${k} = ${b * k}.`); },
        () => { const h = ri(4, 9), s = ri(2, 6), k = ri(2, 6); return mcn(`A ${h}-foot pole casts a ${s}-foot shadow. At the same time a tree casts a ${s * k}-foot shadow. How tall is the tree, in feet?`, h * k, `The tree's shadow is ${k} times as long, so the tree is ${k} times as tall: ${h * k}.`, [h + s * k - s, h * s]); },
        () => { const k = ri(2, 7); return mcn(`Two similar figures have a scale factor of ${k}. Their areas are multiplied by what number?`, k * k, `Areas use the scale factor squared: ${k}^2 = ${k * k}.`, [k, 2 * k, k ** 3]); },
        () => { const a = ri(2, 7), b = ri(a + 1, 9), k = ri(2, 6); return num(`Solve for x: {${a}/${b}} = {${a * k}/x}`, b * k, `${a} × ${k} = ${a * k}, so x = ${b} × ${k} = ${b * k}.`); },
      ] },
      { name: 'Right-triangle trig', tip: 'SOH-CAH-TOA. sin θ = opposite ÷ hypotenuse. cos θ = adjacent ÷ hypotenuse. tan θ = opposite ÷ adjacent. The hypotenuse is the longest side, across from the right angle.', gens: [
        () => { const [a, b, c] = pick(TRIP), f = pick(['sin', 'cos', 'tan']), all = { sin: fr(a, c), cos: fr(b, c), tan: fr(a, b) }; return mc(`What is ${f} θ?`, all[f], [all.sin, all.cos, all.tan, fr(b, a), fr(c, a), fr(c, b)], `${f} θ = ${f === 'sin' ? 'opposite ÷ hypotenuse' : f === 'cos' ? 'adjacent ÷ hypotenuse' : 'opposite ÷ adjacent'} = ${all[f]}.`, figTri(a, b, c, true)); },
        () => matchOf('Match each name to its rule.', () => pick([['sin θ', 'opposite ÷ hypotenuse'], ['cos θ', 'adjacent ÷ hypotenuse'], ['tan θ', 'opposite ÷ adjacent'], ['Pythagorean theorem', 'a^2 + b^2 = c^2'], ['Angles in a triangle', 'add to 180°']]), 'SOH-CAH-TOA: Sine Opposite Hypotenuse, Cosine Adjacent Hypotenuse, Tangent Opposite Adjacent.'),
        () => { const [q, a] = pick(SPECIAL); return mc(`${q} = ?`, a, shuffle(['0', '{1/2}', '{√2/2}', '{√3/2}', '1', '√3']), `This is one of the special values worth knowing: ${q} = ${a}.`); },
        () => { const [a, , c] = pick(TRIP), k = ri(2, 5); return num(`In a right triangle, sin θ = {${a}/${c}}. The hypotenuse is ${c * k}. How long is the opposite side?`, a * k, `Opposite = hypotenuse × sin θ = ${c * k} × {${a}/${c}} = ${a * k}.`); },
      ] },
      { name: 'Circles and solids', tip: 'Circle: area = πr^2, circumference = 2πr. A sector is a slice: take the same fraction of the area as the angle is of 360°. Cylinder volume = πr^2h. A cone is one third of that.', gens: [
        () => { const r = ri(2, 6), h = ri(3, 10); return mc(`A cylinder has radius ${r} and height ${h}. What is its volume?`, `${r * r * h}π`, [`${2 * r * h}π`, `${r * h}π`, `${2 * r * r * h}π`, `${r * r + h}π`, `${r * r * h + r}π`], `V = πr^2h = π × ${r * r} × ${h} = ${r * r * h}π.`); },
        () => { const r = pick([3, 6, 9]), v = 4 * r ** 3 / 3; return mc(`A sphere has radius ${r}. What is its volume?`, `${v}π`, [`${r ** 3}π`, `${3 * r * r}π`, `${4 * r ** 3}π`, `${2 * r ** 3}π`], `V = {4/3}πr^3 = {4/3} × ${r ** 3} × π = ${v}π.`); },
        () => { const r = pick([6, 12]), deg = pick([60, 90, 120, 180]), a = r * r * deg / 360; return mc(`A sector with a ${deg}° angle is cut from a circle of radius ${r}. What is its area?`, `${a}π`, [`${r * r}π`, `${r * deg / 180}π`, `${2 * a}π`, `${a + r}π`], `The sector is {${deg}/360} of the circle: {${deg}/360} × ${r * r}π = ${a}π.`); },
        () => { const v = ri(4, 30); return num(`A cylinder has a volume of ${3 * v}. A cone has the same base and height. What is the cone's volume?`, v, `A cone is one third of the cylinder: ${3 * v} ÷ 3 = ${v}.`); },
        () => { const r = pick([6, 12, 18]), deg = pick([60, 90, 120, 180]), L = r * deg / 180; return mc(`How long is a ${deg}° arc on a circle of radius ${r}?`, `${L}π`, [`${2 * r}π`, `${r * r * deg / 360}π`, `${2 * L}π`, `${L + 1}π`], `The arc is {${deg}/360} of the circumference ${2 * r}π: ${L}π.`); },
      ] },
      { name: 'Coordinate geometry', tip: 'Distance between two points uses the Pythagorean theorem: √(run^2 + rise^2). The midpoint is the average of the x values and the average of the y values. Perpendicular slopes are negative reciprocals.', gens: [
        () => { const [a, b, c] = pick([[3, 4, 5], [6, 8, 10], [5, 12, 13], [8, 15, 17]]), x1 = ri(-5, 5), y1 = ri(-5, 5), sx = pick([-1, 1]), sy = pick([-1, 1]); return num(`What is the distance between (${x1}, ${y1}) and (${x1 + sx * a}, ${y1 + sy * b})?`, c, `Run ${a}, rise ${b}: √(${a * a} + ${b * b}) = √${c * c} = ${c}.`); },
        () => { const mx = ri(-5, 6), my = ri(-5, 6), dx = ri(1, 5), dy = ri(1, 5); return mc(`What is the midpoint of (${mx - dx}, ${my - dy}) and (${mx + dx}, ${my + dy})?`, `(${mx}, ${my})`, [`(${2 * dx}, ${2 * dy})`, `(${2 * mx}, ${2 * my})`, `(${my}, ${mx})`, `(${mx + 1}, ${my})`, `(${mx}, ${my - 1})`], `Average the x values and the y values: (${mx}, ${my}).`); },
        () => { const m = pick([2, 3, 4, 5, -2, -3, -4]); return mc(`A line has slope ${m}. What is the slope of a line perpendicular to it?`, fr(-1, m), [String(m), String(-m), fr(1, m)], 'Flip the fraction and change the sign.'); },
        () => { const h = nz(-6, 6), k = nz(-6, 6), r = ri(2, 9); return num(`A circle has the equation (x ${h < 0 ? '+' : '-'} ${Math.abs(h)})^2 + (y ${k < 0 ? '+' : '-'} ${Math.abs(k)})^2 = ${r * r}. What is its radius?`, r, `The right side is r^2, so r = √${r * r} = ${r}.`); },
      ] },
    ],
  });

  MT.grades.push({
    grade: 11, title: 'Algebra 2: complex numbers, logs and sequences', sections: [
      { name: 'Complex numbers', tip: 'i is the square root of -1, so i^2 = -1. Powers of i repeat every four: i, -1, -i, 1. Add complex numbers by combining real parts and i parts: (2 + 3i) + (1 - i) = 3 + 2i.', gens: [
        () => { const n = ri(2, 23); return mc(`i^${n} = ?`, ['1', 'i', '-1', '-i'][n % 4], ['1', 'i', '-1', '-i'], `Powers of i repeat every 4. ${n} ÷ 4 leaves remainder ${n % 4}.`); },
        () => { const k = ri(2, 12); return mc(`√(-${k * k}) = ?`, `${k}i`, [`-${k}`, `${k}`, `${k * k}i`, `-${k}i`], `√(-${k * k}) = √${k * k} × √(-1) = ${k}i.`); },
        () => { const a = nz(-8, 8), b = nz(-8, 8), c = nz(-8, 8), d = nz(-8, 8); return mc(`(${cx(a, b)}) + (${cx(c, d)}) = ?`, cx(a + c, b + d), [cx(a + c, b - d), cx(a - c, b + d), cx(a + d, b + c), cx(a + c + 1, b + d), cx(a + c, b + d + 1)], `Real parts: ${a} + ${p(c)} = ${a + c}. i parts: ${b} + ${p(d)} = ${b + d}.`); },
        () => { const a = ri(1, 5), b = nz(-4, 4), c = ri(1, 5), d = nz(-4, 4); return mc(`(${cx(a, b)})(${cx(c, d)}) = ?`, cx(a * c - b * d, a * d + b * c), [cx(a * c + b * d, a * d + b * c), cx(a * c, b * d), cx(a * c - b * d, a * d - b * c), cx(a * c - b * d + 1, a * d + b * c), cx(a * c - b * d, a * d + b * c + 1)], `Multiply out and use i^2 = -1: ${a * c} ${a * d + b * c < 0 ? '-' : '+'} ${Math.abs(a * d + b * c)}i ${-b * d < 0 ? '-' : '+'} ${Math.abs(b * d)}.`); },
        () => { const { cs } = quadCount(); return num(`What is the discriminant (b^2 - 4ac) of ${poly(cs)} = 0?`, disc(cs), `(${cs[1]})^2 - 4 × ${cs[0]} × ${p(cs[2])} = ${disc(cs)}. ${disc(cs) < 0 ? 'Negative, so the solutions are complex.' : ''}`); },
      ] },
      { name: 'Exponents and logs', tip: 'A logarithm asks: what power? log₂ 8 = 3 because 2^3 = 8. Logs turn multiplying into adding: log(ab) = log a + log b. A fraction power is a root: 8^(1/3) = 2.', gens: [
        () => { const b = pick([2, 3, 4, 5, 10]), e = ri(2, b === 2 ? 6 : b === 10 ? 4 : 3); return num(`log${sub(b)} ${b ** e} = ?`, e, `${b}^${e} = ${b ** e}, so the answer is ${e}.`); },
        () => { const b = pick([2, 3, 5]), e = ri(2, b === 2 ? 7 : 4); return num(`Solve: ${b}^x = ${b ** e}`, e, `${b}^${e} = ${b ** e}, so x = ${e}.`); },
        () => { const k = pick([2, 3, 4]), d = pick([2, 3]), n = pick([1, 2, 3].filter(v => v !== d)); return num(`${k ** d}^(${n}/${d}) = ?`, k ** n, `Take the ${d === 2 ? 'square' : 'cube'} root first: ${k}. Then raise it to the power ${n}: ${k ** n}.`); },
        () => pick([
          () => mc('log(a) + log(b) = ?', 'log(ab)', ['log(a + b)', 'log(a) · log(b)', 'log(a/b)'], 'Adding logs multiplies what is inside.'),
          () => mc('log(a) - log(b) = ?', 'log(a/b)', ['log(a - b)', 'log(ab)', 'log(b/a)'], 'Subtracting logs divides what is inside.'),
          () => mc('log(a^n) = ?', 'n · log(a)', ['log(a) + n', 'log(na)', 'log(a)^n'], 'A power inside a log comes out in front.'),
        ])(),
        () => { const a = ri(1, 5), b = ri(1, 5); return num(`log₂ ${2 ** a} + log₂ ${2 ** b} = ?`, a + b, `${a} + ${b} = ${a + b}.`); },
        () => { const b = pick([2, 3, 5, 10]), ok = rnd() < 0.5; return tf(ok ? `log${sub(b)} 1 = 0` : `log${sub(b)} ${b} = 0`, ok, `${b}^0 = 1, so log${sub(b)} 1 = 0. And log${sub(b)} ${b} = 1.`); },
      ] },
      { name: 'Sequences and series', tip: 'Arithmetic sequences add the same amount each time: term n = first + (n - 1) × difference. Geometric sequences multiply by the same ratio each time: term n = first × ratio^(n - 1).', gens: [
        () => { const a = ri(1, 12), d = nz(-5, 9), n = ri(8, 20); return num(`An arithmetic sequence starts ${a}, ${a + d}, ${a + 2 * d}, ...  What is term number ${n}?`, a + (n - 1) * d, `${a} + (${n} - 1) × ${p(d)} = ${a + (n - 1) * d}.`); },
        () => { const a = ri(1, 5), r = pick([2, 3]), n = ri(4, 6); return num(`A geometric sequence starts ${a}, ${a * r}, ${a * r * r}, ...  What is term number ${n}?`, a * r ** (n - 1), `${a} × ${r}^${n - 1} = ${a * r ** (n - 1)}.`); },
        () => { const a = ri(1, 9), d = ri(1, 6), n = ri(5, 12); return num(`What is the sum of the first ${n} terms of ${a}, ${a + d}, ${a + 2 * d}, ...?`, n * (2 * a + (n - 1) * d) / 2, `The last term is ${a + (n - 1) * d}. Sum = ${n} × (first + last) ÷ 2 = ${n * (2 * a + (n - 1) * d) / 2}.`); },
        () => { const a = ri(2, 6), r = ri(2, 5); return mcn(`What is the common ratio of ${a}, ${a * r}, ${a * r * r}, ...?`, r, `Divide a term by the one before it: ${a * r} ÷ ${a} = ${r}.`, [a * r - a, a]); },
        () => { const a = ri(2, 12), d = ri(2, 7); return mc(`Which rule gives the sequence ${a}, ${a + d}, ${a + 2 * d}, ...?`, `aₙ = ${lin(d, a - d, 'n')}`, [`aₙ = ${lin(a, d, 'n')}`, `aₙ = ${lin(d, a, 'n')}`, `aₙ = ${lin(a, -d, 'n')}`, `aₙ = ${lin(d + 1, a - d - 1, 'n')}`], `It goes up by ${d}, so the rule has ${d}n. Check n = 1: ${d} + ${p(a - d)} = ${a}.`); },
        () => { const n = pick([10, 20, 25, 40, 50, 100]); return num(`1 + 2 + 3 + ... + ${n} = ?`, n * (n + 1) / 2, `${n} × (${n} + 1) ÷ 2 = ${n * (n + 1) / 2}.`); },
      ] },
      { name: 'Function moves', tip: 'f(g(x)) means do g first, then f. To find an inverse, swap x and y and solve for y. y = (x - h)^2 + k is the basic parabola moved right h and up k, so its vertex is (h, k).', gens: [
        () => { const a = ri(2, 5), b = nz(-6, 6), c = nz(-5, 5), x = ri(-3, 3); return num(`f(x) = ${lin(a, b)} and g(x) = ${poly([1, 0, c])}. What is f(g(${x}))?`, a * (x * x + c) + b, `g(${x}) = ${x * x + c}. Then f(${x * x + c}) = ${a * (x * x + c) + b}.`); },
        () => { const a = ri(2, 7), b = nz(-9, 9), s = b < 0 ? '+' : '-', o = b < 0 ? '-' : '+', B = Math.abs(b); return mc(`What is the inverse of f(x) = ${lin(a, b)}?`, `(x ${s} ${B}) ÷ ${a}`, [`(x ${o} ${B}) ÷ ${a}`, `${a}(x ${s} ${B})`, `x ÷ ${a} ${s} ${B}`, `${a}x ${s} ${B}`], `Swap and solve: x = ${a}y ${b < 0 ? '-' : '+'} ${B}, so y = (x ${s} ${B}) ÷ ${a}.`); },
        () => { const [h, k] = distinct(2, 1, 8).map(v => v * pick([-1, 1])); return mc(`What is the vertex of y = (x ${h < 0 ? '+' : '-'} ${Math.abs(h)})^2 ${k < 0 ? '-' : '+'} ${Math.abs(k)}?`, `(${h}, ${k})`, [`(${-h}, ${k})`, `(${h}, ${-k})`, `(${k}, ${h})`, `(${-h}, ${-k})`], `Compare with (x - h)^2 + k: h = ${h}, k = ${k}.`); },
        () => { const n = ri(2, 9), dir = pick(['up', 'down', 'left', 'right']), all = { up: `y = x^2 + ${n}`, down: `y = x^2 - ${n}`, left: `y = (x + ${n})^2`, right: `y = (x - ${n})^2` }; return mc(`The graph of y = x^2 is moved ${n} units ${dir}. What is the new equation?`, all[dir], Object.values(all), 'Up and down change the number added outside. Left and right change x inside the bracket, with the opposite sign.'); },
      ] },
      { name: 'Polynomials and rational expressions', tip: 'Remainder theorem: when you divide p(x) by (x - a), the remainder is p(a). Zeros are the x values that make the polynomial 0. To simplify a fraction of polynomials, factor and cancel.', gens: [
        () => { const a = nz(-3, 3), b = ri(-4, 4), c = ri(-6, 6), d = ri(-9, 9); return num(`What is the remainder when ${poly([1, b, c, d])} is divided by ${fac(-a)}?`, a ** 3 + b * a * a + c * a + d, `Put x = ${a} into the polynomial: ${a ** 3 + b * a * a + c * a + d}.`); },
        () => { const rs = distinct(3, 1, 7).map(v => v * pick([-1, 1])), bad = rs.map(v => -v).filter(v => !rs.includes(v)); return pickAll(`Tap every zero of f(x) = ${rs.map(r => fac(-r)).join('')}.`, [...rs.map(v => ({ t: String(v), ok: true })), ...bad.map(v => ({ t: String(v), ok: false })), ...(bad.length ? [] : [{ t: '0', ok: false }])], 'Each bracket is zero when x has the opposite sign of the number in it.'); },
        () => { const k = ri(2, 9); return mc(`Simplify: (x^2 - ${k * k}) ÷ (x - ${k})`, `x + ${k}`, [`x - ${k}`, `x^2 + ${k}`, `x - ${k * k}`, `x + ${k * k}`], `x^2 - ${k * k} = (x + ${k})(x - ${k}). Cancel (x - ${k}).`); },
        () => { const n = ri(2, 5), a = nz(-4, 4), ans = n % 2 === 0 ? (a > 0 ? 'Up on both sides' : 'Down on both sides') : (a > 0 ? 'Down on the left, up on the right' : 'Up on the left, down on the right'); return mc(`What does the graph of y = ${mono(a, n)} + ... do at its far ends?`, ans, ['Up on both sides', 'Down on both sides', 'Down on the left, up on the right', 'Up on the left, down on the right'], `Degree ${n} is ${n % 2 ? 'odd' : 'even'} and the leading number is ${a > 0 ? 'positive' : 'negative'}.`); },
      ] },
    ],
  });

  const SIN = { 0: '0', 30: '{1/2}', 45: '{√2/2}', 60: '{√3/2}', 90: '1', 180: '0', 270: '-1' };
  const COS = { 0: '1', 30: '{√3/2}', 45: '{√2/2}', 60: '{1/2}', 90: '0', 180: '-1', 270: '0' };
  const RAD = [[30, '{π/6}'], [45, '{π/4}'], [60, '{π/3}'], [90, '{π/2}'], [120, '{2π/3}'], [135, '{3π/4}'], [150, '{5π/6}'], [180, 'π'], [270, '{3π/2}'], [360, '2π']];
  const TRIG_FACTS = [
    () => mc('sin^2 θ + cos^2 θ = ?', '1', ['0', '2', 'tan^2 θ'], 'This is the Pythagorean identity. It is true for every angle.'),
    () => mc('tan θ = ?', '{sin θ/cos θ}', ['{cos θ/sin θ}', 'sin θ · cos θ', '{1/sin θ}'], 'Tangent is sine divided by cosine.'),
    () => mc('In which quadrant are sine and cosine both negative?', 'III', ['I', 'II', 'IV'], 'In quadrant III both x and y are negative.'),
    () => mc('In which quadrant is sine positive and cosine negative?', 'II', ['I', 'III', 'IV'], 'In quadrant II, x is negative and y is positive.'),
    () => mc('What is the period of y = sin x?', '2π', ['π', '{π/2}', '4π'], 'The sine wave repeats every full turn, 2π.'),
    () => mc('What is the largest value of y = 3 sin x?', '3', ['1', '6', '3π'], 'Sine goes from -1 to 1, so 3 sin x goes from -3 to 3.'),
  ];
  const DERIVS = [['sin x', 'cos x'], ['cos x', '-sin x'], ['e^x', 'e^x'], ['ln x', '{1/x}'], ['x^2', '2x'], ['x^3', '3x^2'], ['5x', '5'], ['{1/x}', '-{1/x^2}']];
  const ANTIS = [['cos x', 'sin x + C'], ['sin x', '-cos x + C'], ['e^x', 'e^x + C'], ['{1/x}', 'ln|x| + C'], ['2x', 'x^2 + C'], ['1', 'x + C'], ['3x^2', 'x^3 + C']];
  const nPr = (n, r) => fact(n) / fact(n - r), nCr = (n, r) => nPr(n, r) / fact(r);
  MT.grades.push({
    grade: 12, title: 'Pre-calculus and calculus', sections: [
      { name: 'Unit circle', tip: 'On the unit circle, cos θ is the x value and sin θ is the y value. Full turn = 360° = 2π radians, so 180° = π. Key values: sin 30° = {1/2}, sin 45° = {√2/2}, sin 60° = {√3/2}.', gens: [
        () => { const f = pick(['sin', 'cos']), deg = pick([0, 30, 45, 60, 90, 180, 270]), a = (f === 'sin' ? SIN : COS)[deg]; return mc(`${f} ${deg}° = ?`, a, shuffle(['0', '1', '-1', '{1/2}', '{√2/2}', '{√3/2}', '-{1/2}']), `On the unit circle at ${deg}°, the ${f === 'sin' ? 'y' : 'x'} value is ${a}.`); },
        () => { const [deg, r] = pick(RAD); return mc(`Convert ${deg}° to radians.`, r, shuffle(RAD.map(x => x[1])), `Multiply by {π/180}: ${deg} × {π/180} = ${r}.`); },
        () => matchOf('Match the degrees to the radians.', () => { const [d, r] = pick(RAD); return [`${d}°`, r]; }, '180° = π radians. Everything else is a fraction of that.'),
        () => pick(TRIG_FACTS)(),
      ] },
      { name: 'Limits', tip: 'A limit is the value a function gets close to. For a smooth function, just plug the number in. If you get {0/0}, factor and cancel first. As x grows huge, {1/x} goes to 0.', gens: [
        () => { const a = ri(-3, 4), b = nz(-5, 5), c = ri(-9, 9); return num(`lim (x → ${a}) of ${poly([1, b, c])} = ?`, a * a + b * a + c, `Polynomials are smooth, so plug in x = ${a}: ${a * a + b * a + c}.`); },
        () => { const a = ri(1, 9); return num(`lim (x → ${a}) of (x^2 - ${a * a}) ÷ (x - ${a}) = ?`, 2 * a, `Factor the top: (x + ${a})(x - ${a}). Cancel (x - ${a}), leaving x + ${a}, which goes to ${2 * a}.`); },
        () => { const r = ri(1, 4), k = ri(2, 6), q = ri(1, 9), s = ri(1, 9); return num(`lim (x → ∞) of (${poly([r * k, 0, q])}) ÷ (${poly([r, s, 0])}) = ?`, k, `Same top power on both, so use the leading numbers: ${r * k} ÷ ${r} = ${k}.`); },
        () => pick([
          () => { const k = ri(2, 9); return mc(`lim (x → ∞) of {${k}/x} = ?`, '0', ['∞', String(k), '1', 'Does not exist'], 'A fixed number divided by something huge gets as close to 0 as you like.'); },
          () => mc('lim (x → 0) of {sin x/x} = ?', '1', ['0', '∞', 'Does not exist'], 'This is a famous limit: sin x and x are almost equal near 0.'),
          () => { const k = ri(2, 9); return mc(`lim (x → ∞) of ${k}x^2 = ?`, '∞', ['0', String(k), '1'], 'The function keeps growing without any bound.'); },
        ])(),
      ] },
      { name: 'Derivatives', tip: 'The derivative is the slope of a curve. Power rule: bring the power down in front, then lower the power by one. The derivative of x^3 is 3x^2. The derivative of a plain number is 0.', gens: [
        () => { const a = ri(2, 7), n = ri(2, 6); return mc(`What is the derivative of ${mono(a, n)}?`, mono(a * n, n - 1), [mono(a, n - 1), mono(a * n, n), mono(a * (n - 1), n - 1), mono(a * n, n + 1), mono(a + n, n - 1)], `Bring the ${n} down: ${a} × ${n} = ${a * n}. Lower the power to ${n - 1}.`); },
        () => { const a = ri(1, 6), b = nz(-9, 9), c = nz(-9, 9); return mc(`f(x) = ${poly([a, b, c])}. What is f'(x)?`, lin(2 * a, b), [lin(a, b), lin(2 * a, c), poly([2 * a, b, 0]), lin(2 * a, b + c), lin(2 * a + 1, b)], `${mono(a, 2)} becomes ${mono(2 * a, 1)}, ${mono(b, 1)} becomes ${b}, and the plain number disappears.`); },
        () => { const a = ri(1, 5), b = nz(-8, 8), c = ri(-9, 9), x = ri(-3, 4); return num(`f(x) = ${poly([a, b, c])}. What is the slope of the tangent line at x = ${x}?`, 2 * a * x + b, `f'(x) = ${lin(2 * a, b)}. At x = ${x}: ${2 * a * x + b}.`); },
        () => matchOf('Match each function to its derivative.', () => pick(DERIVS), 'These basic derivatives are worth memorizing.'),
        () => { const a = ri(1, 6), b = ri(1, 12), t = ri(1, 6); return num(`A position is s(t) = ${poly([a, b, 0], 't')}. What is the velocity at t = ${t}?`, 2 * a * t + b, `Velocity is the derivative: ${lin(2 * a, b, 't')}. At t = ${t}: ${2 * a * t + b}.`); },
      ] },
      { name: 'Integrals', tip: 'Integrating undoes differentiating. Power rule backwards: raise the power by one, then divide by the new power, and add C. ∫ 2x dx = x^2 + C. A definite integral gives the area under the curve.', gens: [
        () => { const a = ri(1, 6), n = ri(1, 4); return mc(`∫ ${mono(a * (n + 1), n)} dx = ?`, `${mono(a, n + 1)} + C`, [`${mono(a * (n + 1), n + 1)} + C`, `${mono(a * (n + 1) * n, n - 1)} + C`, `${mono(a, n)} + C`, `${mono(a + 1, n + 1)} + C`, `${mono(a * (n + 1) + 1, n + 1)} + C`], `Raise the power to ${n + 1} and divide by ${n + 1}: ${a * (n + 1)} ÷ ${n + 1} = ${a}.`); },
        () => { const k = ri(1, 5), b = ri(1, 6); return num(`∫ from 0 to ${b} of ${mono(2 * k, 1)} dx = ?`, k * b * b, `The antiderivative is ${mono(k, 2)}. At ${b} it is ${k * b * b}, at 0 it is 0.`); },
        () => { const k = ri(2, 9), a = ri(0, 5), b = a + ri(1, 6); return num(`∫ from ${a} to ${b} of ${k} dx = ?`, k * (b - a), `It is a rectangle: height ${k}, width ${b - a}. Area = ${k * (b - a)}.`); },
        () => { const b = ri(1, 5); return num(`∫ from 0 to ${b} of 3x^2 dx = ?`, b ** 3, `The antiderivative is x^3. At ${b} it is ${b ** 3}, at 0 it is 0.`); },
        () => matchOf('Match each function to its antiderivative.', () => pick(ANTIS), 'Check by differentiating the answer: you should get the function back.'),
      ] },
      { name: 'Counting and probability', tip: 'n! means n × (n - 1) × ... × 1. Use permutations when order matters and combinations when it does not. For independent events, multiply the chances: two heads in a row is {1/2} × {1/2} = {1/4}.', gens: [
        () => { const n = ri(3, 6); return num(`${n}! = ?`, fact(n), `${range(1, n).reverse().join(' × ')} = ${fact(n)}.`); },
        () => { const n = ri(4, 8), r = ri(2, 3); return num(`${r} people are picked from ${n} to stand in a line (order matters). How many different lines are possible?`, nPr(n, r), `${range(n - r + 1, n).reverse().join(' × ')} = ${nPr(n, r)}.`); },
        () => { const n = ri(4, 9), r = ri(2, 3); return num(`A team of ${r} is chosen from ${n} people (order does not matter). How many different teams are possible?`, nCr(n, r), `${nPr(n, r)} ordered picks ÷ ${fact(r)} orders of each team = ${nCr(n, r)}.`); },
        () => { const n = ri(2, 5); return mc(`You flip a fair coin ${n} times. What is the chance of all heads?`, `{1/${2 ** n}}`, [`{1/${2 * n + 1}}`, '{1/2}', fr(n, 2 ** (n + 1)), `{1/${2 ** (n + 1)}}`, `{1/${2 ** n + 2}}`], `Multiply {1/2} by itself ${n} times: {1/${2 ** n}}.`); },
        () => { const k = ri(1, 6); return mc(`You roll two number cubes. What is the chance both show ${k}?`, '{1/36}', ['{1/6}', '{1/12}', '{1/3}', '{1/18}'], '{1/6} × {1/6} = {1/36}.'); },
        () => { const d = pick([2, 4, 5, 10]), a = d * ri(2, 12); return num(`A game pays $${a} with probability {1/${d}} and $0 otherwise. What is the expected value, in dollars?`, a / d, `${a} × {1/${d}} = ${a / d}.`); },
      ] },
    ],
  });
})();
