/* Math Trail - full lessons, grades 1 to 6.
   Each lesson: idea (the big idea), steps (how to do it), ex (worked examples), watch (a common mistake),
   and optionally words (vocabulary) and fig + cap (a picture). Keys are g<grade>s<topic>, topics count from 0. */
(function () {
  const { figDots, figClock, figBar, figRect, figGrid } = MT;
  MT.lessons = MT.lessons || {};
  const L = (id, lesson) => { MT.lessons[id] = lesson; };

  // text helpers shared by the app and the printable lesson pages
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const fmt = s => esc(s)
    .replace(/\{([^{}\/]+)\/([^{}]+)\}/g, '<span class="fr"><span>$1</span><span>$2</span></span>')
    .replace(/\^\(([^)]+)\)/g, '<sup>$1</sup>')
    .replace(/\^(-?(?:\w+(?:\.\d+)?|☐))/g, '<sup>$1</sup>');
  MT.esc = esc; MT.fmt = fmt;
  MT.lessonHtml = (st, les) => {
    if (!les) return `<p class="tip">${fmt(st.tip)}</p>`;
    return `<section class="lz"><h3>The big idea</h3><p class="idea">${fmt(les.idea)}</p></section>` +
      (les.fig ? `<figure class="lz-fig">${les.fig}<figcaption>${fmt(les.cap || '')}</figcaption></figure>` : '') +
      `<section class="lz"><h3>How to do it</h3><ol class="steps">${les.steps.map(s => `<li>${fmt(s)}</li>`).join('')}</ol></section>` +
      `<section class="lz"><h3>Worked examples</h3><div class="exs">${les.ex.map(([q, a]) => `<div class="ex"><p class="ex-q">${fmt(q)}</p><p>${fmt(a)}</p></div>`).join('')}</div></section>` +
      `<section class="lz watch"><h3>Watch out</h3><p>${fmt(les.watch)}</p></section>` +
      (les.words ? `<section class="lz"><h3>Words to know</h3><dl class="words">${les.words.map(([t, d]) => `<div><dt>${fmt(t)}</dt><dd>${fmt(d)}</dd></div>`).join('')}</dl></section>` : '');
  };

  // ---------------- Grade 1
  L('g1s0', {
    idea: 'Counting numbers go in order. Each number is one more than the number before it. A number that comes later is bigger.',
    fig: figDots(2, 5), cap: 'Count the dots. 2 rows of 5 makes 10.',
    steps: ['Say the numbers in order: 1, 2, 3, 4, 5 and so on.', 'To find the number after, count one more.', 'To find the number before, count one back.', 'To put numbers in order, find the smallest first. Then find the next smallest.'],
    ex: [['What number comes right after 29?', 'Count one more. After 29 comes 30.'], ['Put 14, 9 and 21 in order.', '9 is the smallest. Next is 14. Then 21. The order is 9, 14, 21.']],
    watch: 'After a 9 the tens change. 19 goes to 20. 29 goes to 30.',
    words: [['before', 'the number that comes just earlier'], ['after', 'the number that comes next']],
  });
  L('g1s1', {
    idea: 'Adding means putting groups together to find how many in all. The answer is called the sum.',
    steps: ['Find the bigger number.', 'Start at the bigger number and count on the smaller number.', 'The last number you say is the answer.'],
    ex: [['8 + 3 = ?', 'Start at 8. Count on 3: 9, 10, 11. So 8 + 3 = 11.'], ['6 + ☐ = 10', 'Count from 6 up to 10: 7, 8, 9, 10. That is 4 counts. The missing number is 4.']],
    watch: 'You can add in any order. 3 + 8 is the same as 8 + 3. Start with the bigger number so you count less.',
    words: [['sum', 'the answer when you add'], ['count on', 'keep counting up from a number']],
  });
  L('g1s2', {
    idea: 'Subtracting means taking some away to find how many are left. The answer is called the difference.',
    steps: ['Start at the first number.', 'Count back the number you are taking away.', 'The last number you say is the answer.', 'Check by adding: the answer plus the number you took away gives the first number.'],
    ex: [['12 - 4 = ?', 'Start at 12. Count back 4: 11, 10, 9, 8. So 12 - 4 = 8. Check: 8 + 4 = 12.'], ['15 - ☐ = 9', 'Count back from 15 to 9: 14, 13, 12, 11, 10, 9. That is 6 counts. The missing number is 6.']],
    watch: 'Order matters when you subtract. The number you start with goes first. 9 - 4 is 5, but you cannot swap them.',
    words: [['difference', 'the answer when you subtract'], ['count back', 'count down from a number']],
  });
  L('g1s3', {
    idea: 'We use signs to compare numbers. < means "is less than". > means "is greater than". = means "is the same as".',
    steps: ['Look at the tens first. More tens means a bigger number.', 'If the tens are the same, look at the ones.', 'Point the open side of the sign at the bigger number.'],
    ex: [['47 ☐ 52', '47 has 4 tens. 52 has 5 tens. 52 is bigger, so 47 < 52.'], ['6 + 3 ☐ 9', 'First add: 6 + 3 = 9. Both sides are the same, so 6 + 3 = 9.']],
    watch: 'Think of the sign as a hungry mouth. It always opens toward the bigger number.',
    words: [['greater than', 'bigger than'], ['less than', 'smaller than']],
  });
  L('g1s4', {
    idea: 'A two-digit number is made of tens and ones. The first digit tells how many tens. The second digit tells how many ones.',
    steps: ['Read the first digit. That is the number of tens.', 'Read the second digit. That is the number of ones.', 'Tens are worth 10 each. 4 tens is 40.', 'Add the tens and the ones together to get the number.'],
    ex: [['What is 4 tens and 7 ones?', '4 tens is 40. Add 7 ones. 40 + 7 = 47.'], ['What is 10 more than 36?', 'Add one more ten. The tens digit goes from 3 to 4. The ones stay the same. The answer is 46.']],
    watch: '53 and 35 use the same digits but they are different numbers. 53 has 5 tens. 35 has only 3 tens.',
    words: [['digit', 'one of the symbols 0 to 9'], ['tens', 'groups of ten']],
  });

  // ---------------- Grade 2
  L('g2s0', {
    idea: 'To add bigger numbers, add the ones first and then the tens. If the ones make 10 or more, carry a ten.',
    steps: ['Write the numbers one above the other. Line up the ones and the tens.', 'Add the ones.', 'If the ones add to 10 or more, write the ones digit and carry 1 to the tens.', 'Add the tens. Include the 1 you carried.'],
    ex: [['38 + 25 = ?', 'Ones: 8 + 5 = 13. Write 3 and carry 1. Tens: 3 + 2 + 1 = 6. The answer is 63.'], ['42 + 31 = ?', 'Ones: 2 + 1 = 3. Tens: 4 + 3 = 7. Nothing to carry. The answer is 73.']],
    watch: 'Do not forget the ten you carried. Write a small 1 above the tens so you remember it.',
    words: [['carry', 'move a ten over to the tens column']],
  });
  L('g2s1', {
    idea: 'To subtract bigger numbers, subtract the ones first and then the tens. If there are not enough ones, borrow a ten.',
    steps: ['Line up the ones and the tens.', 'Look at the ones. If the top digit is too small, borrow 1 ten. That gives you 10 more ones.', 'Subtract the ones.', 'Subtract the tens. Remember the top tens went down by 1 if you borrowed.', 'Check by adding your answer to the number you took away.'],
    ex: [['52 - 27 = ?', 'You cannot take 7 from 2, so borrow. 12 - 7 = 5. The tens are now 4. 4 - 2 = 2. The answer is 25. Check: 25 + 27 = 52.'], ['68 - 25 = ?', 'Ones: 8 - 5 = 3. Tens: 6 - 2 = 4. No borrowing. The answer is 43.']],
    watch: 'Always take the bottom digit from the top digit. Do not flip them when the top one is smaller. Borrow instead.',
    words: [['borrow', 'take one ten and turn it into ten ones']],
  });
  L('g2s2', {
    idea: 'Skip counting means jumping by the same amount each time. It makes counting faster and gets you ready for multiplying.',
    steps: ['Look at two numbers next to each other. Find how big the jump is.', 'Check that the next jump is the same size.', 'Keep adding that jump to go forward. Subtract it to go back.'],
    ex: [['5, 10, 15, ☐', 'Each number is 5 more. 15 + 5 = 20. The next number is 20.'], ['Count back by 10s: 70, 60, 50, ☐', 'Each number is 10 less. 50 - 10 = 40.']],
    watch: 'Check the jump between more than one pair of numbers. The jump must stay the same all the way.',
    words: [['pattern', 'something that repeats in the same way']],
  });
  L('g2s3', {
    idea: 'Even numbers can be split into two equal groups. Odd numbers have one left over. Bigger numbers have hundreds, tens and ones.',
    steps: ['To tell even from odd, look only at the last digit.', 'If the last digit is 0, 2, 4, 6 or 8, the number is even.', 'If the last digit is 1, 3, 5, 7 or 9, the number is odd.', 'In a three-digit number, the first digit is hundreds, the second is tens, the third is ones.'],
    ex: [['Is 37 even or odd?', 'The last digit is 7. So 37 is odd.'], ['What is 4 hundreds, 0 tens and 6 ones?', '400 + 0 + 6 = 406.']],
    watch: 'Zero holds a place. 406 is not the same as 46. The 0 shows there are no tens.',
    words: [['even', 'can be shared equally by 2'], ['odd', 'has 1 left over when shared by 2']],
  });
  L('g2s4', {
    idea: 'A clock has two hands. The short hand shows the hour. The long hand shows the minutes. Coins each have their own value.',
    fig: figClock(3, 30), cap: 'This clock shows 3:30. The long hand is on the 6.',
    steps: ['Read the short hand first. It tells the hour.', 'Read the long hand. On the 12 it is :00. On the 3 it is :15. On the 6 it is :30. On the 9 it is :45.', 'For coins, learn the values: quarter 25, dime 10, nickel 5, penny 1.', 'Count the biggest coins first, then the smaller ones.'],
    ex: [['How many cents are 2 dimes and 3 nickels?', 'Count the dimes: 10, 20. Count on the nickels: 25, 30, 35. That is 35 cents.'], ['A toy costs 35 cents. You pay 50 cents. How much change?', '50 - 35 = 15. You get 15 cents back.']],
    watch: 'At 3:30 the short hand is halfway between 3 and 4. The hour is still 3 until the long hand gets back to 12.',
    words: [['half past', '30 minutes after the hour'], ['change', 'the money you get back']],
  });

  // ---------------- Grade 3
  L('g3s0', {
    idea: 'Multiplying is a fast way to add equal groups. 4 × 3 means 4 groups of 3.',
    fig: figDots(3, 4), cap: '3 rows with 4 in each row: 3 × 4 = 12.',
    steps: ['Read a × b as "a groups of b".', 'Skip count by b, a times. Or picture rows and columns.', 'You can swap the order. 4 × 3 gives the same answer as 3 × 4.', 'Learn the times tables so the answers come quickly.'],
    ex: [['4 × 3 = ?', 'Count by 3s four times: 3, 6, 9, 12. So 4 × 3 = 12.'], ['6 × ☐ = 42', 'Count by 6s until you reach 42: 6, 12, 18, 24, 30, 36, 42. That is 7 counts. The missing number is 7.']],
    watch: 'Multiplying is not adding. 4 × 3 is 12, but 4 + 3 is only 7.',
    words: [['product', 'the answer when you multiply'], ['array', 'things set out in rows and columns']],
  });
  L('g3s1', {
    idea: 'Dividing means sharing into equal groups. It is the opposite of multiplying.',
    steps: ['Read 12 ÷ 3 as "12 shared into 3 equal groups".', 'Ask: what number times 3 makes 12?', 'Use your times tables to find it.', 'Check by multiplying your answer by the number you divided by.'],
    ex: [['12 ÷ 3 = ?', '3 × 4 = 12, so 12 ÷ 3 = 4.'], ['20 cookies are shared equally by 5 friends. How many each?', '5 × 4 = 20, so each friend gets 4 cookies.']],
    watch: 'Order matters. 12 ÷ 3 is 4. The big number being shared goes first.',
    words: [['quotient', 'the answer when you divide'], ['fact family', '3 × 4 = 12, 4 × 3 = 12, 12 ÷ 3 = 4, 12 ÷ 4 = 3']],
  });
  L('g3s2', {
    idea: 'A fraction names equal parts of a whole. The bottom number says how many equal parts there are. The top number says how many parts you have.',
    fig: figBar(3, 4), cap: '3 of the 4 equal parts are shaded. That is {3/4}.',
    steps: ['Count all the equal parts. That is the bottom number.', 'Count the shaded parts. That is the top number.', 'Same bottom numbers: the fraction with the bigger top is bigger.', 'Same top numbers: the fraction with the smaller bottom is bigger, because the pieces are bigger.'],
    ex: [['Which is bigger, {3/8} or {5/8}?', 'The pieces are the same size. 5 pieces is more than 3. So {5/8} is bigger.'], ['Which is bigger, {1/4} or {1/8}?', 'Cutting into 4 makes bigger pieces than cutting into 8. So {1/4} is bigger.']],
    watch: 'The parts must be equal. A bigger bottom number means smaller pieces: {1/8} is smaller than {1/4}.',
    words: [['numerator', 'the top number'], ['denominator', 'the bottom number']],
  });
  L('g3s3', {
    idea: 'Perimeter is the distance around a shape. Area is the space inside it.',
    fig: figRect(5, 3), cap: 'A rectangle 5 units long and 3 units wide.',
    steps: ['For perimeter, add the lengths of all the sides.', 'For the area of a rectangle, multiply length × width.', 'Perimeter is measured in units. Area is measured in square units.', 'If you know the area and one side, divide to find the other side.'],
    ex: [['A rectangle is 5 by 3. Find the perimeter and the area.', 'Perimeter: 5 + 3 + 5 + 3 = 16 units. Area: 5 × 3 = 15 square units.'], ['A rectangle has area 24. One side is 6. How long is the other side?', '24 ÷ 6 = 4. The other side is 4.']],
    watch: 'Do not mix them up. Perimeter goes around, so you add. Area fills the inside, so you multiply.',
    words: [['perimeter', 'the distance around a shape'], ['area', 'the space inside a shape']],
  });
  L('g3s4', {
    idea: 'Rounding swaps a number for a nearby number that is easier to work with, like the nearest ten or hundred.',
    steps: ['Find the place you are rounding to.', 'Look at the digit just to the right of it.', 'If that digit is 5 or more, round up. If it is 4 or less, stay the same.', 'Change all the digits to the right into zeros.'],
    ex: [['Round 47 to the nearest ten.', 'The ones digit is 7. That is 5 or more, so round up. The answer is 50.'], ['Round 362 to the nearest hundred.', 'The tens digit is 6. That is 5 or more, so round up. The answer is 400.']],
    watch: '5 rounds up. 45 rounds to 50, not 40.',
    words: [['round', 'change to a nearby easier number'], ['estimate', 'a close answer, not the exact one']],
  });

  // ---------------- Grade 4
  L('g4s0', {
    idea: 'Break a big multiplication into smaller parts that you already know, then add the parts together.',
    steps: ['Split one number into tens and ones.', 'Multiply each part by the other number.', 'Add the answers.', 'To multiply by 10, 100 or 1000, write that many zeros on the end.'],
    ex: [['34 × 6 = ?', '30 × 6 = 180 and 4 × 6 = 24. Add them: 180 + 24 = 204.'], ['23 × 14 = ?', '23 × 10 = 230 and 23 × 4 = 92. Add them: 230 + 92 = 322.']],
    watch: 'Remember the zero when you multiply tens. 30 × 6 is 180, not 18.',
    words: [['partial products', 'the smaller answers you add together']],
  });
  L('g4s1', {
    idea: 'Sometimes a number does not share out evenly. What is left over is called the remainder.',
    steps: ['Ask how many times the divider fits into the number without going over.', 'Multiply to see how much that uses.', 'Subtract to find what is left. That is the remainder.', 'Write the answer with R, like 3 R2.', 'Check: divider × answer + remainder gives the starting number.'],
    ex: [['17 ÷ 5 = ?', '5 fits in 3 times: 5 × 3 = 15. Left over: 17 - 15 = 2. The answer is 3 R2. Check: 5 × 3 + 2 = 17.'], ['47 ÷ 6 = ?', '6 × 7 = 42. Left over: 47 - 42 = 5. The answer is 7 R5.']],
    watch: 'The remainder must be smaller than the number you divide by. If it is not, the divider fits in one more time.',
    words: [['remainder', 'what is left over after dividing'], ['divisor', 'the number you divide by']],
  });
  L('g4s2', {
    idea: 'Factors are numbers that divide evenly into a number. Multiples are what you get when you skip count. A prime has only two factors: 1 and itself.',
    steps: ['To find factors, look for pairs that multiply to the number. Start with 1 and work up.', 'To find multiples, skip count: 3, 6, 9, 12 and so on.', 'To test for prime, try dividing by 2, 3, 5 and 7. If none divide evenly (for numbers under 100), it is prime.', 'The least common multiple is the first number that appears in both lists of multiples.'],
    ex: [['Find all the factors of 12.', 'Pairs: 1 × 12, 2 × 6, 3 × 4. The factors are 1, 2, 3, 4, 6 and 12.'], ['What is the least common multiple of 4 and 6?', 'Multiples of 4: 4, 8, 12. Multiples of 6: 6, 12. The first one they share is 12.']],
    watch: '1 is not a prime number. 2 is the only even prime.',
    words: [['factor', 'a number that divides evenly into another'], ['multiple', 'a number in the times table of another'], ['prime', 'a number with exactly two factors']],
  });
  L('g4s3', {
    idea: 'Different fractions can name the same amount. {1/2}, {2/4} and {3/6} are all equal. They are called equivalent fractions.',
    fig: figBar(2, 4), cap: '{2/4} covers the same amount as {1/2}.',
    steps: ['Multiply the top and bottom by the same number to get an equal fraction.', 'Or divide the top and bottom by the same number to simplify.', 'To compare two fractions, give them the same bottom number first.', 'Then compare the top numbers.'],
    ex: [['{2/3} = {☐/12}', 'The bottom was multiplied by 4 (3 × 4 = 12). Multiply the top by 4 too: 2 × 4 = 8. So {2/3} = {8/12}.'], ['Which is bigger, {3/4} or {2/3}?', 'Use twelfths. {3/4} = {9/12} and {2/3} = {8/12}. 9 is more than 8, so {3/4} is bigger.']],
    watch: 'Do the same thing to the top and the bottom, and only multiply or divide. Adding the same number does not work.',
    words: [['equivalent', 'equal in value'], ['simplify', 'write with the smallest numbers possible']],
  });
  L('g4s4', {
    idea: 'Decimals are another way to write fractions with 10 or 100 on the bottom. The first place after the point is tenths. The second is hundredths.',
    steps: ['Read 0.7 as 7 tenths. That is {7/10}.', 'Read 0.25 as 25 hundredths. That is {25/100}.', 'To compare, line up the decimal points. Add a zero if it helps: 0.5 is the same as 0.50.', 'To add or subtract, line up the decimal points and work as usual.'],
    ex: [['Which is bigger, 0.5 or 0.45?', 'Write 0.5 as 0.50. 50 hundredths is more than 45 hundredths. So 0.5 is bigger.'], ['2.3 + 1.8 = ?', 'Tenths: 3 + 8 = 11 tenths. Write 1 and carry 1. Ones: 2 + 1 + 1 = 4. The answer is 4.1.']],
    watch: 'More digits does not mean a bigger number. 0.45 is smaller than 0.5.',
    words: [['tenth', 'one of ten equal parts'], ['hundredth', 'one of a hundred equal parts']],
  });

  // ---------------- Grade 5
  L('g5s0', {
    idea: 'Fractions must have the same bottom number before you can add or subtract them.',
    steps: ['Find a bottom number that both bottoms divide into. The smallest one is best.', 'Rewrite each fraction with that bottom number.', 'Add or subtract the tops. Keep the bottom the same.', 'Simplify the answer if you can.'],
    ex: [['{1/2} + {1/3} = ?', 'Use sixths. {1/2} = {3/6} and {1/3} = {2/6}. Add the tops: {3/6} + {2/6} = {5/6}.'], ['{3/4} - {1/6} = ?', 'Use twelfths. {3/4} = {9/12} and {1/6} = {2/12}. Subtract: {9/12} - {2/12} = {7/12}.']],
    watch: 'Never add the bottoms. {1/2} + {1/3} is not {2/5}.',
    words: [['common denominator', 'a bottom number that both fractions can use']],
  });
  L('g5s1', {
    idea: 'To multiply fractions, multiply the tops and multiply the bottoms. The word "of" means multiply.',
    steps: ['Multiply the top numbers.', 'Multiply the bottom numbers.', 'Simplify the answer.', 'For a whole number, put it over 1. 4 is the same as {4/1}.'],
    ex: [['{2/3} × {3/4} = ?', 'Tops: 2 × 3 = 6. Bottoms: 3 × 4 = 12. {6/12} simplifies to {1/2}.'], ['What is {3/4} of 20?', '20 ÷ 4 = 5. That is one quarter. Three quarters is 5 × 3 = 15.']],
    watch: 'You do not need a common bottom number to multiply. Multiplying by a fraction less than 1 makes the answer smaller, not bigger.',
    words: [['of', 'in fraction problems this means multiply']],
  });
  L('g5s2', {
    idea: 'Decimals follow the same rules as whole numbers. The only extra job is keeping the decimal point in the right place.',
    steps: ['To add or subtract, line up the decimal points. Fill gaps with zeros.', 'To multiply, ignore the point and multiply. Then count the decimal places in the question and put that many in the answer.', 'To multiply by 10, 100 or 1000, move the point right 1, 2 or 3 places.', 'To divide by 10, or multiply by 0.1, move the point left 1 place.'],
    ex: [['3.45 + 2.7 = ?', 'Write 2.7 as 2.70. Then 3.45 + 2.70 = 6.15.'], ['2.4 × 3 = ?', '24 × 3 = 72. There is 1 decimal place in the question, so the answer is 7.2.']],
    watch: 'Line up the decimal points, not the last digits.',
    words: [['decimal place', 'a position after the decimal point']],
  });
  L('g5s3', {
    idea: 'When a problem has more than one operation, everyone must do them in the same order so everyone gets the same answer.',
    steps: ['Brackets first.', 'Then powers, like 3^2.', 'Then multiply and divide, working left to right.', 'Then add and subtract, working left to right.'],
    ex: [['3 + 4 × 2 = ?', 'Multiply first: 4 × 2 = 8. Then add: 3 + 8 = 11.'], ['20 - 2 × 3^2 = ?', 'Power first: 3^2 = 9. Multiply: 2 × 9 = 18. Subtract: 20 - 18 = 2.']],
    watch: 'Do not just work left to right. 3 + 4 × 2 is 11, not 14. Use brackets if you want the adding done first: (3 + 4) × 2 = 14.',
    words: [['operation', 'adding, subtracting, multiplying or dividing'], ['power', 'a small raised number that says how many times to multiply']],
  });
  L('g5s4', {
    idea: 'Volume is the space inside a solid shape. A coordinate grid uses two numbers to say exactly where a point is.',
    fig: figGrid([[3, 2]], 0, 6), cap: 'The point (3, 2): go 3 across, then 2 up.',
    steps: ['Volume of a box = length × width × height.', 'Volume is measured in cubic units.', 'A point is written (x, y). The first number is how far across. The second is how far up.', 'If you know the volume and two sides, divide to find the third.'],
    ex: [['A box is 4 long, 3 wide and 2 tall. What is its volume?', '4 × 3 × 2 = 24 cubic units.'], ['A box has volume 60. It is 5 long and 3 wide. How tall is it?', '5 × 3 = 15. Then 60 ÷ 15 = 4. It is 4 tall.']],
    watch: '(3, 2) and (2, 3) are different points. Across always comes first.',
    words: [['volume', 'the space inside a solid'], ['coordinates', 'the pair of numbers that locate a point']],
  });

  // ---------------- Grade 6
  L('g6s0', {
    idea: 'A ratio compares two amounts. A rate compares amounts with different units, like miles and hours. A unit rate tells you the amount for just 1.',
    steps: ['Write a ratio as a to b, or a:b.', 'To make an equal ratio, multiply or divide both parts by the same number.', 'To find a unit rate, divide so that the second amount becomes 1.', 'Use the unit rate to find any other amount by multiplying.'],
    ex: [['2:3 = ☐:12', '3 was multiplied by 4 to get 12. Multiply 2 by 4 as well: 8. So 2:3 = 8:12.'], ['3 notebooks cost $6. How much is 1?', '6 ÷ 3 = 2. Each notebook costs $2.']],
    watch: 'Order matters. 2:3 is not the same as 3:2. And always multiply both parts. Adding the same number to both parts changes the ratio.',
    words: [['ratio', 'a comparison of two amounts'], ['unit rate', 'the amount for one']],
  });
  L('g6s1', {
    idea: 'Percent means "out of 100". 25% is 25 out of 100, which is {25/100} or 0.25.',
    steps: ['To change a percent to a decimal, divide by 100. 25% becomes 0.25.', 'To find a percent of a number, multiply the number by that decimal.', 'Use shortcuts: 50% is half, 25% is a quarter, 10% is divide by 10.', 'To find what percent one number is of another, divide part by whole, then multiply by 100.'],
    ex: [['What is 25% of 80?', '25% is one quarter. 80 ÷ 4 = 20.'], ['15 is what percent of 60?', '15 ÷ 60 = 0.25. Multiply by 100: 25%.']],
    watch: '0.5 is 50%, not 5%. Moving from a decimal to a percent shifts the point two places.',
    words: [['percent', 'out of one hundred']],
  });
  L('g6s2', {
    idea: 'Negative numbers are less than zero. On a number line they sit to the left of zero. The further left, the smaller the number.',
    steps: ['Picture a number line. Adding a positive moves right. Subtracting moves left.', 'Adding a negative moves left: 4 + (-10) is the same as 4 - 10.', 'Subtracting a negative moves right: 5 - (-3) is the same as 5 + 3.', 'To compare, the number further right is greater.'],
    ex: [['4 + (-10) = ?', 'Start at 4. Move 10 to the left. You land on -6.'], ['5 - (-3) = ?', 'Subtracting a negative is adding. 5 + 3 = 8.']],
    watch: '-8 looks bigger than -3 but it is smaller, because it is further left on the number line.',
    words: [['negative', 'less than zero'], ['integer', 'a whole number, positive, negative or zero']],
  });
  L('g6s3', {
    idea: 'In algebra a letter stands for a number. Solving an equation means finding the number that makes it true.',
    steps: ['To work out an expression, replace the letter with its number, then calculate.', 'To solve an equation, undo what was done to the letter.', 'Whatever you do to one side, do the same to the other side.', 'Check by putting your answer back into the equation.'],
    ex: [['If x = 4, what is 3x + 2?', '3 × 4 = 12. Then 12 + 2 = 14.'], ['Solve x + 7 = 15.', 'Subtract 7 from both sides. x = 8. Check: 8 + 7 = 15.']],
    watch: '3x means 3 times x. If x is 4, then 3x is 12, not 34.',
    words: [['variable', 'a letter that stands for a number'], ['equation', 'two things joined by an equals sign']],
  });
  L('g6s4', {
    idea: 'A triangle is half of a rectangle, so its area is half of base × height. For a list of numbers, the mean, median and range each describe it in one number.',
    steps: ['Area of a triangle = {1/2} × base × height.', 'Mean: add all the numbers, then divide by how many there are.', 'Median: put the numbers in order and take the middle one.', 'Range: biggest number minus smallest number.'],
    ex: [['A triangle has base 10 and height 6. What is its area?', '{1/2} × 10 × 6 = 30.'], ['Find the mean and median of 3, 9, 5, 1, 7.', 'Mean: 3 + 9 + 5 + 1 + 7 = 25, and 25 ÷ 5 = 5. Median: in order they are 1, 3, 5, 7, 9. The middle one is 5.']],
    watch: 'Put the numbers in order before you find the median. The middle of the list as written is usually wrong.',
    words: [['mean', 'the average'], ['median', 'the middle value'], ['range', 'the spread from smallest to biggest']],
  });
})();
