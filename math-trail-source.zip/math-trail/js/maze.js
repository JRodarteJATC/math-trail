/* Math Trail - maze breaks: the pick-it-up maze game.
   MT.maze.mount(host, maze, opts) draws one maze from js/maze-data.js inside host and runs it.
   opts.label   small heading above the title
   opts.onPick  called each time something is picked up
   opts.onWin   called with the step count when the maze is cleared; returns the buttons to offer: [{ text, main, fn }] */
(function () {
  const N = 1, E = 2, S = 4, W = 8, SVGNS = 'http://www.w3.org/2000/svg';
  const STEP = { N: [-1, 0], E: [0, 1], S: [1, 0], W: [0, -1] };
  const TURNS = [[N, -1, 0], [E, 0, 1], [S, 1, 0], [W, 0, -1]];
  const HELP = 'Move with the arrow keys, drag through the maze, or tap the arrows.';
  const ARROWS = [['u', '-1,0', 'Up', 'M10 4l7 11H3z'], ['l', '0,-1', 'Left', 'M4 10l11-7v14z'], ['r', '0,1', 'Right', 'M16 10L5 3v14z'], ['d', '1,0', 'Down', 'M10 16L3 5h14z']];
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  let cur = null;                                  // the maze being played, or null

  const cells = (r, c, letters) => { const out = [[r, c]]; for (const ch of letters) { r += STEP[ch][0]; c += STEP[ch][1]; out.push([r, c]); } return out; };
  const el = (name, attrs, text) => { const n = document.createElementNS(SVGNS, name); for (const k in attrs) n.setAttribute(k, attrs[k]); if (text != null) n.textContent = text; return n; };
  const mid = v => v * 10 + 5;
  const pts = list => list.map(([r, c]) => mid(c) + ',' + mid(r)).join(' ');
  const openBits = (m, r, c) => parseInt(m.open[r][c], 16);
  const hasKey = k => cur.got.has(cur.m.items.findIndex(it => it.key === k));
  const part = name => cur.host.querySelector(`[data-r="${name}"]`);
  const say = t => { part('say').textContent = t; };
  const alive = () => { if (cur && !cur.host.isConnected) cur = null; return !!cur; };

  function drawBoard() {
    const { m, pos } = cur, svg = cur.svg, p = cur.parts = {};
    const sw = Math.min(1.15, 0.5 + m.cols * 0.03);
    svg.setAttribute('viewBox', `${-sw} ${-sw} ${m.cols * 10 + 2 * sw} ${m.rows * 10 + 2 * sw}`);
    svg.setAttribute('aria-label', `${m.title} maze, ${m.cols} by ${m.rows} squares`);
    svg.replaceChildren();
    for (const [r, c] of [m.start, m.end]) svg.append(el('rect', { class: 'mz-tint', x: c * 10, y: r * 10, width: 10, height: 10 }));

    p.hint = el('g', {});
    p.hint.append(el('polyline', { class: 'mz-hint', points: pts(cells(m.start[0], m.start[1], m.path)) }));
    for (const b of m.branches) p.hint.append(el('polyline', { class: 'mz-hint side', points: pts(cells(b[0], b[1], b[2])) }));
    p.hint.style.display = 'none';
    svg.append(p.hint);

    p.trail = el('polyline', { class: 'mz-trail' });
    svg.append(p.trail);

    let d = '';
    for (let r = 0; r < m.rows; r++) for (let c = 0; c < m.cols; c++) {
      const o = openBits(m, r, c), x = c * 10, y = r * 10;
      if (!(o & N)) d += `M${x} ${y}h10`;
      if (!(o & W)) d += `M${x} ${y}v10`;
      if (r === m.rows - 1) d += `M${x} ${y + 10}h10`;
      if (c === m.cols - 1) d += `M${x + 10} ${y}v10`;
    }
    svg.append(el('path', { class: 'mz-walls', d, 'stroke-width': sw }));

    p.doors = (m.doors || []).map(dr => {
      const g = el('g', { class: 'mz-door', 'data-k': dr.k });
      g.append(el('rect', { x: dr.c * 10 + 0.8, y: dr.r * 10 + 0.8, width: 8.4, height: 8.4, rx: 1.3 }));
      g.append(el('text', { class: 'mz-ltr', x: mid(dr.c), y: mid(dr.r), dy: '.36em', 'font-size': 6 }, dr.k));
      svg.append(g);
      return g;
    });
    p.items = m.items.map(it => {
      const g = el('g', { class: it.key ? 'mz-item mz-keyb' : 'mz-item' });
      if (it.key) {
        g.setAttribute('data-k', it.key);
        g.append(el('circle', { cx: mid(it.c), cy: mid(it.r), r: 3.7 }));
        g.append(el('text', { class: 'mz-ltr', x: mid(it.c), y: mid(it.r), dy: '.36em', 'font-size': 5.4 }, it.key));
      } else g.append(el('text', { class: 'mz-em', x: mid(it.c), y: mid(it.r), dy: '.36em', 'font-size': 6.6 }, it.e));
      svg.append(g);
      return g;
    });

    // a start or finish in the middle of the maze gets a wide ring so it is easy to find again
    const inside = ([r]) => r > 0 && r < m.rows - 1;
    if (inside(m.start)) svg.append(el('circle', { class: 'mz-mark', cx: mid(m.start[1]), cy: mid(m.start[0]), r: 8 }));
    p.goal = el('g', { class: 'mz-goal' });
    p.goal.append(el('circle', { class: 'mz-ring', cx: mid(m.end[1]), cy: mid(m.end[0]), r: inside(m.end) ? 8 : 4.3 }));
    p.goal.append(el('text', { class: 'mz-em', x: mid(m.end[1]), y: mid(m.end[0]), dy: '.36em', 'font-size': 6.4 }, m.goal));
    svg.append(p.goal);

    p.player = el('g', { class: 'mz-player' });
    p.player.style.transform = `translate(${pos[1] * 10}px,${pos[0] * 10}px)`;
    p.player.append(el('circle', { cx: 5, cy: 5, r: 4.2 }));
    p.player.append(el('text', { class: 'mz-em', x: 5, y: 5, dy: '.36em', 'font-size': 5.6 }, m.hero));
    svg.append(p.player);
  }

  function update() {
    const { m, parts: p, pos, got } = cur;
    p.trail.setAttribute('points', pts(cur.trail));
    p.player.style.transform = `translate(${pos[1] * 10}px,${pos[0] * 10}px)`;
    p.items.forEach((g, i) => g.classList.toggle('got', got.has(i)));
    p.goal.classList.toggle('open', got.size === m.items.length);
    [...part('chips').children].forEach((li, i) => li.classList.toggle('got', got.has(i)));
    p.doors.forEach((g, i) => g.classList.toggle('open', hasKey(m.doors[i].k)));
    part('count').textContent = `Picked up ${got.size} of ${m.items.length} · ${cur.steps} steps (shortest way: ${m.walk})`;
  }

  // Big mazes scroll inside their frame; keep the player in view.
  function follow(smooth) {
    const sc = part('scroller'), svg = cur.svg, vb = svg.viewBox.baseVal, pos = cur.pos;
    if (sc.scrollWidth <= sc.clientWidth + 1 && sc.scrollHeight <= sc.clientHeight + 1) return;
    const k = svg.clientWidth / vb.width, cell = 10 * k;
    const px = (mid(pos[1]) - vb.x) * k, py = (mid(pos[0]) - vb.y) * k;
    let left = sc.scrollLeft, top = sc.scrollTop;
    if (px < left + 3 * cell || px > left + sc.clientWidth - 3 * cell) left = px - sc.clientWidth / 2;
    if (py < top + 3 * cell || py > top + sc.clientHeight - 3 * cell) top = py - sc.clientHeight / 2;
    if (left !== sc.scrollLeft || top !== sc.scrollTop) sc.scrollTo({ left, top, behavior: smooth ? 'smooth' : 'auto' });
  }

  function reset() {
    const m = cur.m;
    cur.pos = [...m.start]; cur.got = new Set(); cur.trail = [[...m.start]]; cur.steps = 0; cur.won = false;
    clearTimeout(cur.hintTimer);
    const old = cur.host.querySelector('.mz-win'); if (old) old.remove();
    drawBoard(); update(); follow(false);
    say(HELP);
  }

  function win() {
    const { m, steps, opts } = cur;
    cur.won = true;
    const acts = [...((opts.onWin && opts.onWin(steps)) || []), { text: 'Play again', fn: reset }];
    const box = document.createElement('div');
    box.className = 'mz-win';
    box.innerHTML = `<div><h2>Maze cleared!</h2><p class="mz-haul" aria-hidden="true">${m.items.map(it => esc(it.e)).join('')}</p>
      <p>You picked up all ${m.items.length} and reached the ${esc(m.goalName)} in ${steps} steps. ${steps <= m.walk ? 'That is the shortest way possible!' : `The shortest way is ${m.walk}.`}</p>
      <p class="row">${acts.map((a, i) => `<button class="btn ${a.main ? 'main' : ''}" type="button" data-a="${i}">${esc(a.text)}</button>`).join('')}</p></div>`;
    box.querySelectorAll('[data-a]').forEach(b => b.addEventListener('click', () => acts[+b.dataset.a].fn()));
    part('stage').append(box);
    say('');
    box.querySelector('[data-a]').focus({ preventScroll: true });
  }

  function move(dr, dc) {
    if (!alive() || cur.won) return false;
    const { m, pos, got } = cur;
    const bit = dr === -1 ? N : dr === 1 ? S : dc === 1 ? E : W;
    if (!(openBits(m, pos[0], pos[1]) & bit)) return false;
    const door = (m.doors || []).find(d => d.r === pos[0] + dr && d.c === pos[1] + dc);
    if (door && !hasKey(door.k)) { say(`Door ${door.k} is locked. Find key ${door.k} first.`); return false; }
    const now = cur.pos = [pos[0] + dr, pos[1] + dc];
    cur.steps++;
    const prev = cur.trail[cur.trail.length - 2];
    if (prev && prev[0] === now[0] && prev[1] === now[1]) cur.trail.pop(); else cur.trail.push(now);

    const idx = m.items.findIndex(it => it.r === now[0] && it.c === now[1]);
    if (idx >= 0 && !got.has(idx)) {
      got.add(idx);
      const left = m.items.length - got.size, it = m.items[idx];
      const what = it.key ? `key ${it.key}. Door ${it.key} is open now` : `the ${it.name}`;
      say(left ? `You picked up ${what}. ${left} more to find.` : `You picked up ${what}. That is everything! Head to the ${m.goalName}.`);
      if (cur.opts.onPick) cur.opts.onPick();
    }
    update();
    follow(true);
    if (now[0] === m.end[0] && now[1] === m.end[1]) {
      const left = m.items.length - got.size;
      if (left === 0) win(); else say(`Not yet. ${left} more to pick up before the ${m.goalName}.`);
    }
    return true;
  }

  // Dragging or tapping: walk down a clear corridor, or around a nearby corner (up to 3 steps).
  function shortRoute(target, limit) {
    const { m, pos } = cur, key = ([r, c]) => r * 100 + c;
    const from = new Map([[key(pos), null]]);
    let frontier = [pos];
    for (let depth = 0; depth < limit && frontier.length; depth++) {
      const next = [];
      for (const cell of frontier) {
        const o = openBits(m, cell[0], cell[1]);
        for (const [bit, dr, dc] of TURNS) {
          if (!(o & bit)) continue;
          const n = [cell[0] + dr, cell[1] + dc];
          if (from.has(key(n))) continue;
          from.set(key(n), cell);
          if (n[0] === target[0] && n[1] === target[1]) {
            const route = []; let x = n;
            while (from.get(key(x))) { const q = from.get(key(x)); route.unshift([x[0] - q[0], x[1] - q[1]]); x = q; }
            return route;
          }
          next.push(n);
        }
      }
      frontier = next;
    }
    return null;
  }
  function walkTo(target) {
    const m = cur.m;
    if (target[0] < 0 || target[1] < 0 || target[0] >= m.rows || target[1] >= m.cols) return;
    const dr = Math.sign(target[0] - cur.pos[0]), dc = Math.sign(target[1] - cur.pos[1]);
    if (!dr && !dc) return;
    if (!dr || !dc) {
      let guard = 50, moved = false;
      while (guard-- && (cur.pos[0] !== target[0] || cur.pos[1] !== target[1]) && move(dr, dc)) moved = true;
      if (moved) return;
    }
    const route = shortRoute(target, 3);
    if (route) for (const [a, b] of route) if (!move(a, b)) break;
  }
  function cellAt(e) {
    const svg = cur.svg, box = svg.getBoundingClientRect(), vb = svg.viewBox.baseVal;
    const x = (e.clientX - box.left) / box.width * vb.width + vb.x;
    const y = (e.clientY - box.top) / box.height * vb.height + vb.y;
    return [Math.floor(y / 10), Math.floor(x / 10)];
  }

  function mount(host, m, opts) {
    opts = opts || {};
    const doors = m.doors || [];
    const badge = (cls, k) => `<span class="${cls}" data-k="${k}">${k}</span>`;
    host.innerHTML = `<div class="mz" style="--ar:${m.cols / m.rows};--cols:${m.cols}">
      <section class="mz-info">
        ${opts.label ? `<p class="label">${esc(opts.label)}</p>` : ''}
        <h1>${esc(m.title)}</h1>
        <p class="lead">${esc(m.mission)}</p>
        <p class="mz-ends">Start <span>${esc(m.hero)}</span> → Finish <span>${esc(m.goal)}</span></p>
        ${doors.length ? `<p class="mz-rule">${doors.length > 1 ? 'Doors' : 'Door'} ${doors.map(d => badge('mz-db', d.k)).join(' ')} ${doors.length > 1 ? 'open with keys' : 'opens with key'} ${doors.map(d => badge('mz-kb', d.k)).join(' ')}</p>` : ''}
      </section>
      <section class="mz-stage" data-r="stage"><div class="mz-scroller" data-r="scroller"><svg class="mz-board" role="img"></svg></div></section>
      <section class="mz-list">
        <p class="mz-count" data-r="count"></p>
        <ul class="mz-chips" data-r="chips">${m.items.map(it => `<li class="mz-chip"><span class="tick"></span>${it.key ? badge('mz-kb', it.key) : `<span class="e">${esc(it.e)}</span>`}${esc(it.name)}</li>`).join('')}</ul>
        <p class="mz-say" data-r="say" aria-live="polite"></p>
      </section>
      <section class="mz-controls">
        <div class="mz-pad" aria-label="Move">${ARROWS.map(([cls, d, name, shape]) => `<button class="${cls}" type="button" data-d="${d}" aria-label="${name}"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="${shape}"/></svg></button>`).join('')}</div>
        <div class="mz-acts"><button class="btn" type="button" data-r="hint">Show the way</button><button class="btn" type="button" data-r="reset">Start over</button></div>
      </section>
    </div>`;
    const svg = host.querySelector('.mz-board');
    cur = { host, m, opts, svg, parts: {}, hintTimer: null };

    let dragging = false;
    svg.addEventListener('pointerdown', e => { if (!alive()) return; dragging = true; try { svg.setPointerCapture(e.pointerId); } catch (x) {} walkTo(cellAt(e)); e.preventDefault(); });
    svg.addEventListener('pointermove', e => { if (dragging && alive()) walkTo(cellAt(e)); });
    for (const t of ['pointerup', 'pointercancel']) svg.addEventListener(t, () => { dragging = false; });

    for (const b of host.querySelectorAll('.mz-pad button')) {
      const [dr, dc] = b.dataset.d.split(',').map(Number);
      let timer = null;
      const stop = () => { clearInterval(timer); timer = null; };
      b.addEventListener('pointerdown', e => { e.preventDefault(); move(dr, dc); stop(); timer = setInterval(() => { if (b.isConnected) move(dr, dc); else stop(); }, 150); });
      for (const t of ['pointerup', 'pointerleave', 'pointercancel']) b.addEventListener(t, stop);
      b.addEventListener('click', e => { if (e.detail === 0) move(dr, dc); });      // keyboard activation
    }
    part('hint').addEventListener('click', () => {
      const h = cur.parts.hint;
      h.style.display = '';
      clearTimeout(cur.hintTimer);
      cur.hintTimer = setTimeout(() => { h.style.display = 'none'; }, 4000);
      say('The red line shows the way for a few seconds. Dashed parts are side trips.');
    });
    part('reset').addEventListener('click', reset);
    reset();
  }

  const KEYS = { ArrowUp: [-1, 0], ArrowDown: [1, 0], ArrowLeft: [0, -1], ArrowRight: [0, 1], w: [-1, 0], s: [1, 0], a: [0, -1], d: [0, 1] };
  window.addEventListener('keydown', e => {
    if (!alive() || e.metaKey || e.ctrlKey || e.altKey) return;
    const k = KEYS[e.key] || KEYS[e.key.toLowerCase()];
    if (!k) return;
    e.preventDefault();
    move(k[0], k[1]);
  });

  MT.maze = { mount, move, get state() { return alive() ? { m: cur.m, pos: cur.pos, got: [...cur.got], steps: cur.steps, won: cur.won } : null; } };
})();
