/* Math Trail - full lessons, grades 7 to 12. Same shape as lessons-1-6.js. */
(function () {
  const { figTri, figGrid } = MT;
  const L = (id, lesson) => { MT.lessons[id] = lesson; };

  // ---------------- Grade 7
  L('g7s0', {
    idea: 'When you multiply or divide two numbers, the signs decide whether the answer is positive or negative.',
    steps: ['Ignore the signs and multiply or divide the numbers.', 'If the two signs are the same, the answer is positive.', 'If the two signs are different, the answer is negative.', 'With more steps, follow the order of operations: multiply and divide before you add and subtract.'],
    ex: [['(-3) × (-4) = ?', '3 × 4 = 12. The signs are the same, so the answer is positive: 12.'], ['(-20) ÷ 5 = ?', '20 ÷ 5 = 4. The signs are different, so the answer is negative: -4.']],
    watch: 'The sign rules for multiplying are not the rules for adding. -3 + (-4) is -7, but -3 × (-4) is +12.',
    words: [['product', 'the answer to a multiplication'], ['quotient', 'the answer to a division']],
  });
  L('g7s1', {
    idea: 'A proportion says two ratios are equal. If you know three of the four numbers, you can find the fourth.',
    steps: ['Write the two ratios as fractions with the same kind of thing on top in both.', 'Look for the number one side was multiplied by, and do the same to the other part.', 'Or cross-multiply: multiply each top by the opposite bottom, then solve.', 'In y = kx, k is the constant: divide y by x to find it.'],
    ex: [['Solve {3/4} = {x/20}.', '4 was multiplied by 5 to get 20. So x = 3 × 5 = 15.'], ['5 notebooks cost $8. How much do 15 cost?', '15 is 3 times as many as 5. So the cost is 3 × 8 = $24.']],
    watch: 'Keep the same things in the same places. If notebooks are on top in one ratio, they must be on top in the other.',
    words: [['proportion', 'two equal ratios'], ['constant of proportionality', 'the number k in y = kx']],
  });
  L('g7s2', {
    idea: 'Discounts, tax and tips are all percents of a price. Percent change compares how much something changed with where it started.',
    steps: ['Find the percent of the price by multiplying.', 'For a discount, subtract that amount from the price.', 'For tax or a tip, add that amount to the price.', 'Percent change = change ÷ original amount × 100.'],
    ex: [['A $40 jacket is 25% off. What is the sale price?', '25% of 40 is 10. 40 - 10 = $30.'], ['A price goes from $40 to $50. What is the percent increase?', 'The change is 10. 10 ÷ 40 = 0.25, which is 25%.']],
    watch: 'Divide by the original amount, not the new one. From 40 to 50 is a 25% increase, not 20%.',
    words: [['discount', 'money taken off a price'], ['percent change', 'the change compared with the starting amount']],
  });
  L('g7s3', {
    idea: 'A two-step equation has two things done to x. Undo them in reverse order to get x on its own.',
    steps: ['Undo the adding or subtracting first.', 'Then undo the multiplying or dividing.', 'Do the same thing to both sides every time.', 'If there are brackets, you can divide both sides by the number in front first.', 'Check by putting your answer back in.'],
    ex: [['Solve 3x + 5 = 20.', 'Subtract 5 from both sides: 3x = 15. Divide both sides by 3: x = 5. Check: 3 × 5 + 5 = 20.'], ['Solve 2(x + 3) = 14.', 'Divide both sides by 2: x + 3 = 7. Subtract 3: x = 4.']],
    watch: 'Whatever you do to one side, do to the whole of the other side. Do not divide only one term.',
    words: [['inverse operation', 'the operation that undoes another']],
  });
  L('g7s4', {
    idea: 'Every circle is described by its radius. Probability measures how likely something is, from 0 (never) to 1 (certain).',
    steps: ['The radius is the distance from the center to the edge. The diameter is twice the radius.', 'Circumference (distance around) = 2πr.', 'Area = πr^2.', 'Probability = number of ways you want ÷ number of all possible ways.'],
    ex: [['A circle has radius 5. Find its circumference and area.', 'Circumference: 2 × π × 5 = 10π. Area: π × 5 × 5 = 25π.'], ['A bag has 3 red and 5 blue marbles. What is the chance of picking red?', 'There are 8 marbles and 3 are red. The chance is {3/8}.']],
    watch: 'Squaring is not doubling. 5^2 is 25, not 10. And if you are given the diameter, halve it first.',
    words: [['radius', 'center to edge'], ['circumference', 'the distance around a circle'], ['probability', 'how likely something is']],
  });

  // ---------------- Grade 8
  L('g8s0', {
    idea: 'An exponent tells how many times to multiply a number by itself. 2^3 means 2 × 2 × 2.',
    steps: ['Same base, multiplying: add the exponents. 2^3 × 2^4 = 2^7.', 'Same base, dividing: subtract the exponents. 2^7 ÷ 2^3 = 2^4.', 'Power of a power: multiply the exponents. (5^2)^3 = 5^6.', 'A negative exponent means "one over". 2^-3 = {1/2^3} = {1/8}.', 'Scientific notation: 4.5 × 10^3 means move the decimal point 3 places right, giving 4500.'],
    ex: [['3^4 × 3^5 = 3^☐', 'Same base, so add the exponents: 4 + 5 = 9.'], ['2^-3 = ?', 'One over 2^3. 2^3 = 8, so the answer is {1/8}.']],
    watch: '2^3 is 8, not 6. The exponent rules only work when the bases are the same.',
    words: [['base', 'the number being multiplied'], ['exponent', 'the small number that says how many times']],
  });
  L('g8s1', {
    idea: 'A square root undoes squaring. In any right triangle the squares of the two short sides add up to the square of the longest side.',
    fig: figTri(3, 4, 5), cap: 'A right triangle with legs 3 and 4. The longest side is 5.',
    steps: ['√49 = 7 because 7 × 7 = 49.', 'Pythagorean theorem: a^2 + b^2 = c^2, where c is the longest side.', 'To find c: square both legs, add them, then take the square root.', 'To find a leg: square the longest side, subtract the square of the other leg, then take the square root.'],
    ex: [['The legs are 6 and 8. How long is the longest side?', '6^2 + 8^2 = 36 + 64 = 100. √100 = 10.'], ['The longest side is 13 and one leg is 5. Find the other leg.', '13^2 - 5^2 = 169 - 25 = 144. √144 = 12.']],
    watch: 'c is always the side across from the right angle. Add the squares before taking the root: √(9 + 16) is 5, not 3 + 4.',
    words: [['hypotenuse', 'the longest side of a right triangle'], ['leg', 'one of the two shorter sides']],
  });
  L('g8s2', {
    idea: 'When x appears on both sides of an equation, collect the x terms on one side and the plain numbers on the other.',
    steps: ['Expand any brackets first.', 'Add or subtract to move all the x terms to one side.', 'Add or subtract to move the plain numbers to the other side.', 'Divide to get x on its own.', 'If the x terms cancel completely, there is either no solution or every number works.'],
    ex: [['Solve 5x - 3 = 2x + 9.', 'Subtract 2x: 3x - 3 = 9. Add 3: 3x = 12. Divide by 3: x = 4.'], ['Solve 3(x - 2) = 2x + 5.', 'Expand: 3x - 6 = 2x + 5. Subtract 2x: x - 6 = 5. Add 6: x = 11.']],
    watch: 'When you expand a bracket, multiply every term inside. 3(x - 2) is 3x - 6, not 3x - 2.',
    words: [['like terms', 'terms with the same letter and power']],
  });
  L('g8s3', {
    idea: 'Slope measures how steep a line is. It tells how far the line goes up for each step to the right.',
    fig: figGrid([[0, 1], [1, 3]], -5, 5, [[0, 1], [1, 3]]), cap: 'From one dot to the next: right 1, up 2. The slope is 2.',
    steps: ['Slope = rise ÷ run = (change in y) ÷ (change in x).', 'Pick two points. Subtract the y values. Subtract the x values in the same order. Divide.', 'In y = mx + b, m is the slope and b is where the line crosses the y-axis.', 'A positive slope goes uphill left to right. A negative slope goes downhill.'],
    ex: [['Find the slope through (1, 2) and (3, 8).', 'Rise: 8 - 2 = 6. Run: 3 - 1 = 2. Slope: 6 ÷ 2 = 3.'], ['For y = 3x - 2, what are the slope and y-intercept?', 'The slope is 3. The line crosses the y-axis at -2.']],
    watch: 'Rise goes on top, run on the bottom. Subtract in the same order for both, or the sign will be wrong.',
    words: [['slope', 'the steepness of a line'], ['y-intercept', 'where the line crosses the y-axis']],
  });
  L('g8s4', {
    idea: 'A system is two equations with the same x and y. The solution is the one point that makes both equations true.',
    steps: ['If both equations start with "y =", set the two right sides equal and solve for x.', 'Put that x back into either equation to find y.', 'If the equations are lined up (like x + y and x - y), add or subtract them to remove one letter.', 'Write the answer as a point (x, y) and check it in both equations.'],
    ex: [['Solve y = 2x + 1 and y = x + 4.', 'Set them equal: 2x + 1 = x + 4, so x = 3. Then y = 3 + 4 = 7. The solution is (3, 7).'], ['Solve x + y = 10 and x - y = 4.', 'Add the equations: 2x = 14, so x = 7. Then 7 + y = 10, so y = 3.']],
    watch: 'Find both x and y. Then check the point in both equations, not just one.',
    words: [['system', 'two or more equations solved together'], ['substitute', 'replace a letter with what it equals']],
  });

  // ---------------- Grade 9
  L('g9s0', {
    idea: 'A polynomial is a sum of terms like 3x^2, 5x and 7. You simplify by combining like terms and expand by multiplying out brackets.',
    steps: ['Like terms have the same letter and the same power. Add or subtract their numbers.', 'To expand a(b + c), multiply a by every term inside.', 'To expand two brackets, multiply each term in the first by each term in the second: first, outer, inner, last.', 'Combine like terms at the end.'],
    ex: [['Simplify 3x + 5 + 2x - 1.', 'x terms: 3x + 2x = 5x. Numbers: 5 - 1 = 4. Answer: 5x + 4.'], ['Expand (x + 2)(x + 3).', 'x × x = x^2. x × 3 = 3x. 2 × x = 2x. 2 × 3 = 6. Combine: x^2 + 5x + 6.']],
    watch: 'x and x^2 are not like terms, so they cannot be added together. And 3(2x - 4) is 6x - 12: multiply both terms.',
    words: [['term', 'one piece of an expression'], ['coefficient', 'the number in front of a letter']],
  });
  L('g9s1', {
    idea: 'Factoring is expanding in reverse. You rewrite an expression as things multiplied together.',
    steps: ['First look for a factor every term shares, and take it out.', 'For x^2 + bx + c, find two numbers that multiply to c and add to b.', 'Write them in brackets: (x + first)(x + second).', 'A difference of squares follows a pattern: a^2 - b^2 = (a + b)(a - b).', 'Check by expanding your answer.'],
    ex: [['Factor x^2 + 5x + 6.', 'Two numbers that multiply to 6 and add to 5 are 2 and 3. Answer: (x + 2)(x + 3).'], ['Factor x^2 - x - 6.', 'Two numbers that multiply to -6 and add to -1 are -3 and 2. Answer: (x - 3)(x + 2).']],
    watch: 'Watch the signs. If the last number is negative, the two numbers have different signs.',
    words: [['factor', 'one of the things being multiplied'], ['common factor', 'a factor shared by every term']],
  });
  L('g9s2', {
    idea: 'If two things multiply to make zero, one of them must be zero. That fact lets you solve a quadratic equation by factoring.',
    steps: ['Move everything to one side so the equation equals 0.', 'Factor the quadratic.', 'Set each bracket equal to 0 and solve.', 'For x^2 = a number, take the square root and remember both the positive and negative answers.', 'The discriminant b^2 - 4ac tells how many real solutions: positive gives two, zero gives one, negative gives none.'],
    ex: [['Solve x^2 - 5x + 6 = 0.', 'Factor: (x - 2)(x - 3) = 0. So x = 2 or x = 3.'], ['How many real solutions does x^2 + 2x + 5 = 0 have?', 'b^2 - 4ac = 4 - 20 = -16. It is negative, so there are no real solutions.']],
    watch: 'One side must be zero before you factor. And a quadratic usually has two answers. Give both.',
    words: [['quadratic', 'an expression whose highest power is 2'], ['discriminant', 'b^2 - 4ac'], ['vertex', 'the turning point of the curve, at x = -b ÷ (2a)']],
  });
  L('g9s3', {
    idea: 'An inequality is like an equation, but the answer is a whole range of numbers instead of just one.',
    steps: ['Solve it step by step just like an equation.', 'If you multiply or divide both sides by a negative number, flip the inequality sign.', 'Read the answer: x > 4 means every number bigger than 4.', 'Check by trying one number from your answer.'],
    ex: [['Solve 2x + 3 > 11.', 'Subtract 3: 2x > 8. Divide by 2: x > 4. Check with 5: 2 × 5 + 3 = 13, which is more than 11.'], ['Solve -3x < 12.', 'Divide by -3 and flip the sign: x > -4.']],
    watch: 'Flip the sign only when you multiply or divide by a negative. Adding or subtracting a negative does not flip it.',
    words: [['inequality', 'a statement using <, >, ≤ or ≥']],
  });
  L('g9s4', {
    idea: 'A function is a rule. You put a number in and get exactly one number out. f(x) is read "f of x".',
    steps: ['To find f(3), replace every x in the rule with 3 and calculate.', 'Follow the order of operations: powers before multiplying.', 'The x-intercept is where y = 0. Set the rule equal to 0 and solve.', 'In a table, if y changes by the same amount each time x goes up 1, the rule is a line and that amount is the slope.'],
    ex: [['f(x) = 2x^2 - 1. Find f(3).', '3^2 = 9. 2 × 9 = 18. 18 - 1 = 17.'], ['Where does y = 2x - 6 cross the x-axis?', 'Set y = 0: 2x - 6 = 0, so 2x = 6 and x = 3.']],
    watch: 'f(3) does not mean f times 3. And in 2x^2, square first, then multiply by 2.',
    words: [['function', 'a rule that gives one output for each input'], ['x-intercept', 'where a graph crosses the x-axis']],
  });

  // ---------------- Grade 10
  L('g10s0', {
    idea: 'Angles follow a few fixed rules. Knowing them lets you find a missing angle without measuring.',
    steps: ['The three angles in a triangle add to 180°.', 'Angles on a straight line add to 180°. They are called supplementary.', 'Angles in a right-angle corner add to 90°. They are called complementary.', 'When two lines cross, the angles opposite each other are equal.', 'The angles inside a polygon with n sides add to (n - 2) × 180°.'],
    ex: [['A triangle has angles of 50° and 60°. Find the third.', '180 - 50 - 60 = 70°.'], ['What is each angle of a regular hexagon?', 'Sum: (6 - 2) × 180 = 720°. Six equal angles: 720 ÷ 6 = 120°.']],
    watch: 'Supplementary adds to 180 (a straight line). Complementary adds to 90 (a corner). Do not mix them up.',
    words: [['regular polygon', 'a shape with all sides and all angles equal'], ['vertical angles', 'the opposite angles where two lines cross']],
  });
  L('g10s1', {
    idea: 'Similar shapes have the same angles and the same shape but a different size. Every length is multiplied by the same number, called the scale factor.',
    steps: ['Match up the sides that correspond.', 'Divide a big side by its matching small side to find the scale factor.', 'Multiply any other small side by the scale factor to get its matching big side.', 'Areas are multiplied by the scale factor squared.'],
    ex: [['A triangle has sides 3, 4, 5. A similar one has 9 matching the 3. Find its other sides.', 'Scale factor: 9 ÷ 3 = 3. The other sides are 4 × 3 = 12 and 5 × 3 = 15.'], ['A 6 ft pole casts a 4 ft shadow. A tree casts a 20 ft shadow. How tall is the tree?', 'The tree shadow is 5 times as long. So the tree is 6 × 5 = 30 ft.']],
    watch: 'Match the right sides before you divide. Lengths use the scale factor. Areas use the scale factor squared.',
    words: [['similar', 'same shape, different size'], ['scale factor', 'the number every length is multiplied by']],
  });
  L('g10s2', {
    idea: 'In a right triangle, the ratios between the sides depend only on the angle. Those ratios are called sine, cosine and tangent.',
    fig: figTri(3, 4, 5, true), cap: 'From angle θ: opposite is 3, adjacent is 4, hypotenuse is 5.',
    steps: ['Find the hypotenuse: it is across from the right angle.', 'From your angle θ, the opposite side is across from it and the adjacent side is next to it.', 'Use SOH-CAH-TOA: sin θ = opposite ÷ hypotenuse, cos θ = adjacent ÷ hypotenuse, tan θ = opposite ÷ adjacent.', 'Special values to know: sin 30° = {1/2}, sin 45° = {√2/2}, sin 60° = {√3/2}, tan 45° = 1.'],
    ex: [['In the triangle shown, find sin θ, cos θ and tan θ.', 'sin θ = {3/5}. cos θ = {4/5}. tan θ = {3/4}.'], ['sin θ = {3/5} and the hypotenuse is 20. Find the opposite side.', 'Opposite = hypotenuse × sin θ = 20 × {3/5} = 12.']],
    watch: 'Opposite and adjacent depend on which angle you are looking from. The hypotenuse never changes.',
    words: [['hypotenuse', 'the longest side, across from the right angle'], ['adjacent', 'the side next to the angle']],
  });
  L('g10s3', {
    idea: 'Circles and round solids all use π and the radius. A part of a circle takes the same fraction of the area as its angle takes of 360°.',
    steps: ['Circle: area = πr^2, circumference = 2πr.', 'Sector (a slice): area = (angle ÷ 360) × πr^2.', 'Arc (part of the edge): length = (angle ÷ 360) × 2πr.', 'Cylinder: volume = πr^2h. A cone with the same base and height is one third of that.', 'Sphere: volume = {4/3}πr^3.'],
    ex: [['A sector has a 90° angle and radius 4. Find its area.', '90 ÷ 360 = {1/4}. The whole circle is 16π. A quarter of that is 4π.'], ['A cylinder has radius 3 and height 5. Find its volume.', 'π × 3^2 × 5 = π × 9 × 5 = 45π.']],
    watch: 'Area uses r squared. Circumference uses 2r. Leave π in the answer unless you are told to round.',
    words: [['sector', 'a slice of a circle'], ['arc', 'part of the edge of a circle']],
  });
  L('g10s4', {
    idea: 'On a coordinate grid you can find distances, midpoints and slopes using only the coordinates of the points.',
    steps: ['Distance: find the run and the rise between the points, then use √(run^2 + rise^2).', 'Midpoint: average the x values and average the y values.', 'Parallel lines have the same slope.', 'Perpendicular lines have slopes that are negative reciprocals: flip the fraction and change the sign.', 'A circle (x - h)^2 + (y - k)^2 = r^2 has center (h, k) and radius r.'],
    ex: [['Find the distance from (1, 2) to (4, 6).', 'Run: 3. Rise: 4. √(9 + 16) = √25 = 5.'], ['Find the midpoint of (2, 4) and (6, 10).', 'x: (2 + 6) ÷ 2 = 4. y: (4 + 10) ÷ 2 = 7. The midpoint is (4, 7).']],
    watch: 'In the circle equation the signs are flipped. (x - 3)^2 + (y + 1)^2 = 25 has center (3, -1), and the radius is 5, not 25.',
    words: [['midpoint', 'the point halfway between two points'], ['reciprocal', 'a fraction turned upside down']],
  });

  // ---------------- Grade 11
  L('g11s0', {
    idea: 'The number i is defined as the square root of -1, so i^2 = -1. It lets us take square roots of negative numbers. A complex number has a real part and an i part, like 3 + 2i.',
    steps: ['√(-25) = √25 × √(-1) = 5i.', 'Powers of i repeat every four: i, -1, -i, 1. Divide the power by 4 and use the remainder.', 'To add, combine the real parts and combine the i parts.', 'To multiply, expand the brackets, then replace i^2 with -1.', 'If the discriminant b^2 - 4ac is negative, the quadratic has complex solutions.'],
    ex: [['(2 + 3i) + (1 - i) = ?', 'Real parts: 2 + 1 = 3. i parts: 3i - i = 2i. Answer: 3 + 2i.'], ['(1 + 2i)(3 + i) = ?', 'Expand: 3 + i + 6i + 2i^2. Replace i^2 with -1: 3 + 7i - 2 = 1 + 7i.']],
    watch: 'i^2 is -1, so the last term changes sign and joins the real part. Forgetting this is the most common mistake.',
    words: [['imaginary unit', 'the number i, where i^2 = -1'], ['complex number', 'a number written as a + bi']],
  });
  L('g11s1', {
    idea: 'A logarithm asks a question: what power do I need? log₂ 8 = 3 because 2^3 = 8. Logs undo exponents.',
    steps: ['To find log of a number, ask what power of the base gives that number.', 'To solve 3^x = 81, write 81 as a power of 3.', 'A fraction exponent is a root: the bottom number is the root, the top is the power.', 'Log rules: log(ab) = log a + log b, log(a ÷ b) = log a - log b, log(a^n) = n × log a.', 'For any base: the log of 1 is 0, and the log of the base itself is 1.'],
    ex: [['Solve 3^x = 81.', '81 = 3 × 3 × 3 × 3 = 3^4. So x = 4.'], ['8^(2/3) = ?', 'Cube root first: the cube root of 8 is 2. Then square it: 2^2 = 4.']],
    watch: 'log(a + b) is not log a + log b. The adding rule is for multiplying inside the log.',
    words: [['logarithm', 'the power needed to reach a number'], ['base', 'the number being raised to a power']],
  });
  L('g11s2', {
    idea: 'A sequence is a list of numbers that follows a rule. Arithmetic sequences add the same amount each time. Geometric sequences multiply by the same amount each time.',
    steps: ['Arithmetic: find the common difference d by subtracting neighbors. Term n = first + (n - 1) × d.', 'Geometric: find the common ratio r by dividing neighbors. Term n = first × r^(n - 1).', 'Sum of an arithmetic sequence = number of terms × (first + last) ÷ 2.', 'A handy case: 1 + 2 + 3 + ... + n = n(n + 1) ÷ 2.'],
    ex: [['5, 8, 11, ... What is term 10?', 'The difference is 3. Term 10 = 5 + 9 × 3 = 32.'], ['3, 6, 12, ... What is term 6?', 'The ratio is 2. Term 6 = 3 × 2^5 = 3 × 32 = 96.']],
    watch: 'It takes n - 1 jumps to reach term n, not n jumps. Term 10 is 9 jumps from the first term.',
    words: [['common difference', 'the amount added each time'], ['common ratio', 'the amount multiplied each time']],
  });
  L('g11s3', {
    idea: 'Functions can be combined, reversed and moved around. Each change to the rule moves or reverses the graph in a predictable way.',
    steps: ['f(g(x)) means do g first, then put that answer into f.', 'To find an inverse, swap x and y, then solve for y.', 'y = f(x) + k moves the graph up k. y = f(x) - k moves it down.', 'y = f(x - h) moves the graph right h. y = f(x + h) moves it left.', 'y = (x - h)^2 + k is the basic parabola with its vertex moved to (h, k).'],
    ex: [['f(x) = 2x + 1 and g(x) = x^2. Find f(g(3)).', 'g(3) = 9. Then f(9) = 2 × 9 + 1 = 19.'], ['Find the inverse of f(x) = 3x + 6.', 'Write y = 3x + 6. Swap: x = 3y + 6. Solve: y = (x - 6) ÷ 3.']],
    watch: 'Changes inside the bracket work backwards. x - 3 moves the graph right, and x + 3 moves it left.',
    words: [['composition', 'using the output of one function as the input of another'], ['inverse', 'the function that undoes another']],
  });
  L('g11s4', {
    idea: 'Higher-degree polynomials have zeros, remainders and end behavior that you can read from the way they are written.',
    steps: ['Remainder theorem: the remainder when p(x) is divided by (x - a) is p(a). Just plug in a.', 'Zeros: in factored form, each bracket gives one zero. (x - 3) gives 3 and (x + 4) gives -4.', 'To simplify a fraction of polynomials, factor the top and bottom, then cancel matching brackets.', 'End behavior: even degree means both ends go the same way. Odd degree means they go opposite ways. A positive leading number means the right end goes up.'],
    ex: [['Find the remainder when x^3 - 2x + 5 is divided by (x - 2).', 'Plug in 2: 8 - 4 + 5 = 9. The remainder is 9.'], ['Simplify (x^2 - 9) ÷ (x - 3).', 'Factor the top: (x + 3)(x - 3). Cancel (x - 3). Answer: x + 3.']],
    watch: 'The zero from (x + 4) is -4, not 4. And only cancel whole brackets, never single terms.',
    words: [['zero', 'an x value that makes the polynomial equal 0'], ['degree', 'the highest power of x']],
  });

  // ---------------- Grade 12
  L('g12s0', {
    idea: 'The unit circle is a circle of radius 1 centered at the origin. For any angle, cosine is the x value on the circle and sine is the y value.',
    steps: ['Know the key values: sin 0° = 0, sin 30° = {1/2}, sin 45° = {√2/2}, sin 60° = {√3/2}, sin 90° = 1.', 'Cosine takes the same values in the opposite order: cos 0° = 1 down to cos 90° = 0.', 'Radians: a full turn is 2π, so 180° = π. Multiply degrees by {π/180} to convert.', 'Signs by quadrant: all positive in I, only sine in II, only tangent in III, only cosine in IV.', 'Two identities to know: sin^2 θ + cos^2 θ = 1 and tan θ = sin θ ÷ cos θ.'],
    ex: [['Convert 60° to radians.', '60 × {π/180} = {π/3}.'], ['What is cos 180°?', 'At 180° the point on the circle is (-1, 0). Cosine is the x value: -1.']],
    watch: 'Cosine is x and sine is y. Do not swap them. And π radians is 180°, not 360°.',
    words: [['radian', 'an angle measure where a full turn is 2π'], ['identity', 'an equation that is true for every angle']],
  });
  L('g12s1', {
    idea: 'A limit is the value a function gets closer and closer to as x approaches some number. It is the idea that calculus is built on.',
    steps: ['First try plugging the number in. For polynomials that gives the limit.', 'If you get {0/0}, factor the top and bottom, cancel, then plug in again.', 'As x goes to infinity, a number divided by x goes to 0.', 'For a fraction of polynomials as x goes to infinity: if the top and bottom have the same highest power, the limit is the ratio of their leading numbers.'],
    ex: [['Find the limit of (x^2 - 9) ÷ (x - 3) as x → 3.', 'Plugging in gives {0/0}. Factor: (x + 3)(x - 3) ÷ (x - 3) = x + 3. Now plug in: 3 + 3 = 6.'], ['Find the limit of (6x^2 + 1) ÷ (2x^2 + 5x) as x → ∞.', 'Both have x^2 as the highest power. 6 ÷ 2 = 3.']],
    watch: 'Getting {0/0} does not mean the limit is 0 or that it does not exist. It means simplify first.',
    words: [['limit', 'the value a function approaches'], ['infinity', 'growing without any bound']],
  });
  L('g12s2', {
    idea: 'The derivative measures how fast something is changing. On a graph it is the slope of the curve at a point.',
    steps: ['Power rule: for x^n, bring the power down in front and lower the power by one. x^3 becomes 3x^2.', 'A number in front stays and multiplies: 4x^5 becomes 20x^4.', 'Take the derivative of each term separately. A plain number becomes 0.', 'To find the slope at a point, plug the x value into the derivative.', 'Know these: sin x → cos x, cos x → -sin x, e^x → e^x, ln x → {1/x}.'],
    ex: [['f(x) = 3x^2 + 5x - 7. Find f\'(x).', '3x^2 becomes 6x. 5x becomes 5. -7 becomes 0. So f\'(x) = 6x + 5.'], ['What is the slope of that curve at x = 2?', 'f\'(2) = 6 × 2 + 5 = 17.']],
    watch: 'Multiply by the power first, then lower the power. And the derivative of a plain number is 0, not the number itself.',
    words: [['derivative', 'the rate of change of a function'], ['tangent line', 'a line that just touches the curve at one point']],
  });
  L('g12s3', {
    idea: 'Integrating is the reverse of differentiating. An indefinite integral gives a function. A definite integral gives a number: the area under the curve.',
    steps: ['Power rule backwards: raise the power by one, then divide by the new power. x^2 becomes {x^3/3}.', 'For an indefinite integral, add + C at the end.', 'For a definite integral from a to b: find the antiderivative, plug in b, plug in a, and subtract.', 'The integral of a constant k from a to b is a rectangle: k × (b - a).', 'Know these: cos x → sin x, sin x → -cos x, e^x → e^x, {1/x} → ln|x|.'],
    ex: [['∫ 6x^2 dx = ?', 'Raise the power to 3 and divide by 3: 6 ÷ 3 = 2. Answer: 2x^3 + C.'], ['∫ from 0 to 3 of 2x dx = ?', 'The antiderivative is x^2. At 3 it is 9. At 0 it is 0. 9 - 0 = 9.']],
    watch: 'Do not forget + C on an indefinite integral. For a definite integral it is the top value minus the bottom value, in that order.',
    words: [['antiderivative', 'a function whose derivative is the one you started with'], ['definite integral', 'an integral between two limits']],
  });
  L('g12s4', {
    idea: 'Counting rules tell you how many ways something can happen without listing them all. Probability then compares the ways you want with all the ways.',
    steps: ['n! (n factorial) means n × (n - 1) × ... × 1. It counts the ways to arrange n things.', 'Permutations: order matters. Picking 3 from 5 in order is 5 × 4 × 3.', 'Combinations: order does not matter. Divide the permutations by the number of orders of the group.', 'Independent events: multiply the probabilities.', 'Expected value: multiply each prize by its probability and add.'],
    ex: [['How many ways can 3 of 5 people stand in a line?', '5 × 4 × 3 = 60.'], ['How many teams of 3 can be chosen from 5 people?', 'Start with 60 ordered picks. Each team of 3 can be ordered 3! = 6 ways. 60 ÷ 6 = 10.']],
    watch: 'Ask first: does order matter? A line or a code: yes, use permutations. A team or a hand of cards: no, use combinations.',
    words: [['factorial', 'the product of a number and every whole number below it'], ['permutation', 'an ordered choice'], ['combination', 'a choice where order does not matter']],
  });
})();
