/* Math Trail - grades 1 to 4. Each section has a tip (the mini lesson) and a list of puzzle makers. */
(function () {
  const { rnd, ri, pick, shuffle, range, distinct, rd, lcm, isPrime, fr, mc, mcn, num, tf, cmp, ord, matchOf, pickFrom, pickMix, target,
    figDots, figClock, figBar, figRect } = MT;
  const clock = (h, m) => `${h}:${String(m).padStart(2, '0')}`;
  const pl = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;

  MT.grades.push({
    grade: 1, title: 'Counting, adding and taking away', sections: [
      { name: 'Count and order', tip: 'Numbers go up by one each time you count: 7, 8, 9, 10. A number that comes later when you count is bigger. Example: 12 comes after 9, so 12 is bigger than 9.', gens: [
        () => { const n = ri(3, 98); return num(`What number comes right after ${n}?`, n + 1, `Count on one more: ${n}, then ${n + 1}.`); },
        () => { const n = ri(4, 99); return mcn(`What number comes right before ${n}?`, n - 1, `Count back one: ${n}, then ${n - 1}.`); },
        () => ord('Tap the numbers from smallest to biggest.', distinct(4, 1, 50).map(v => ({ t: String(v), v }))),
        () => { const r = ri(2, 4), c = ri(3, 5); return num('How many dots are there?', r * c, `Count each row: ${r} rows of ${c} makes ${r * c}.`, figDots(r, c)); },
      ] },
      { name: 'Adding to 20', tip: 'Adding puts groups together. Start at the bigger number and count on. Example: 8 + 3. Start at 8 and count 9, 10, 11. So 8 + 3 = 11.', gens: [
        () => { const a = ri(1, 10), b = ri(1, 10); return num(`${a} + ${b} = ?`, a + b, `Start at ${Math.max(a, b)} and count on ${Math.min(a, b)}: you land on ${a + b}.`); },
        () => { const a = ri(1, 9), c = a + ri(1, 10); return mcn(`${a} + ☐ = ${c}`, c - a, `${a} + ${c - a} = ${c}.`); },
        () => target(ri(8, 15), 9),
        () => matchOf('Match each problem to its answer.', () => { const a = ri(1, 9), b = ri(1, 9); return [`${a} + ${b}`, a + b]; }, 'Count on from the bigger number to add.'),
      ] },
      { name: 'Taking away', tip: 'Subtracting takes some away. Start at the first number and count back. Example: 12 - 4. Count back 11, 10, 9, 8. So 12 - 4 = 8.', gens: [
        () => { const a = ri(5, 20), b = ri(1, Math.min(a, 10)); return num(`${a} - ${b} = ?`, a - b, `Start at ${a} and count back ${b}: you land on ${a - b}.`); },
        () => { const a = ri(6, 18), b = ri(1, a - 1), ok = rnd() < 0.5, c = ok ? a - b : a - b + pick([-1, 1, 2]); return tf(`${a} - ${b} = ${c}`, ok, `${a} - ${b} = ${a - b}.`); },
        () => { const a = ri(6, 18), b = ri(1, a - 1); return mcn(`${a} - ☐ = ${a - b}`, b, `${a} - ${b} = ${a - b}.`); },
        () => matchOf('Match each problem to its answer.', () => { const a = ri(5, 18), b = ri(1, a - 1); return [`${a} - ${b}`, a - b]; }, 'Count back to subtract.'),
      ] },
      { name: 'Bigger or smaller', tip: 'The sign < means "is less than" and > means "is greater than". The open side always faces the bigger number. Example: 15 < 21 and 30 > 9.', gens: [
        () => { const a = ri(1, 99), b = rnd() < 0.15 ? a : ri(1, 99); return cmp(String(a), String(b), a, b, `${a} is ${a === b ? 'equal to' : a < b ? 'less than' : 'greater than'} ${b}.`); },
        () => { const a = ri(1, 9), b = ri(1, 9), c = a + b + pick([-2, -1, 0, 1, 2]); return cmp(`${a} + ${b}`, String(c), a + b, c, `${a} + ${b} = ${a + b}.`); },
        () => { const n = ri(20, 70); return pickFrom(`Tap every number that is greater than ${n}.`, range(5, 95), 6, v => v > n, `Numbers greater than ${n} come after ${n} when you count.`); },
        () => ord('Tap the numbers from smallest to biggest.', distinct(4, 10, 99).map(v => ({ t: String(v), v }))),
      ] },
      { name: 'Tens and ones', tip: 'A two-digit number is made of tens and ones. Example: 47 is 4 tens and 7 ones. That is 40 + 7.', gens: [
        () => { const t = ri(1, 9), o = ri(0, 9); return mcn(`${pl(t, 'ten')} and ${pl(o, 'one')} make what number?`, t * 10 + o, `${t} tens is ${t * 10}. Add ${o} ones to get ${t * 10 + o}.`, [o * 10 + t, t + o]); },
        () => { const n = ri(11, 99); return num(`How many tens are in ${n}?`, Math.floor(n / 10), `${n} is ${Math.floor(n / 10)} tens and ${n % 10} ones.`); },
        () => { const n = ri(11, 89), up = rnd() < 0.5, a = up ? n + 10 : n - 10; return mcn(`What is 10 ${up ? 'more' : 'less'} than ${n}?`, a, `Only the tens digit changes: ${a}.`, [up ? n + 1 : n - 1]); },
        () => { const t = ri(1, 9), o = ri(1, 9), ok = rnd() < 0.5 || t === o; return tf(`${t * 10 + o} has ${pl(ok ? t : o, 'ten')} and ${pl(ok ? o : t, 'one')}.`, ok, `${t * 10 + o} has ${t} tens and ${o} ones.`); },
      ] },
    ],
  });

  MT.grades.push({
    grade: 2, title: 'Bigger sums, patterns, time and money', sections: [
      { name: 'Adding to 100', tip: 'Add the ones first, then the tens. If the ones make 10 or more, carry a ten. Example: 38 + 25. Ones: 8 + 5 = 13, write 3 and carry 1. Tens: 3 + 2 + 1 = 6. Answer: 63.', gens: [
        () => { const a = ri(11, 59), b = ri(11, 99 - a); return num(`${a} + ${b} = ?`, a + b, `Ones: ${a % 10} + ${b % 10} = ${a % 10 + b % 10}. Then add the tens to get ${a + b}.`); },
        () => { const a = ri(11, 60), c = a + ri(11, 39); return mcn(`${a} + ☐ = ${c}`, c - a, `${a} + ${c - a} = ${c}.`); },
        () => { const a = ri(11, 49), b = ri(11, 49), ok = rnd() < 0.5, c = ok ? a + b : a + b + pick([-10, 10, 1, -1]); return tf(`${a} + ${b} = ${c}`, ok, `${a} + ${b} = ${a + b}.`); },
        () => matchOf('Match each problem to its answer.', () => { const a = ri(11, 49), b = ri(11, 49); return [`${a} + ${b}`, a + b]; }, 'Add the ones, then the tens.'),
      ] },
      { name: 'Subtracting within 100', tip: 'Subtract the ones first, then the tens. If you cannot take the ones away, borrow a ten. Example: 52 - 27. Borrow: 12 - 7 = 5. Tens: 4 - 2 = 2. Answer: 25.', gens: [
        () => { const a = ri(30, 99), b = ri(11, a - 5); return num(`${a} - ${b} = ?`, a - b, `Take away the tens and ones of ${b} from ${a}: ${a - b}.`); },
        () => { const a = ri(40, 99), b = ri(11, a - 11); return mcn(`${a} - ☐ = ${a - b}`, b, `${a} - ${b} = ${a - b}.`); },
        () => { const a = ri(30, 99), b = ri(11, a - 5), ok = rnd() < 0.5, c = ok ? a - b : a - b + pick([-10, 10, 2, -2]); return tf(`${a} - ${b} = ${c}`, ok, `${a} - ${b} = ${a - b}.`); },
        () => { const a = ri(30, 99), b = ri(11, a - 5), c = a - b + pick([-3, 0, 0, 4]); return cmp(`${a} - ${b}`, String(c), a - b, c, `${a} - ${b} = ${a - b}.`); },
      ] },
      { name: 'Skip counting', tip: 'Skip counting jumps by the same amount each time. By 5s: 5, 10, 15, 20. By 10s: 10, 20, 30. Find the jump size, then keep jumping.', gens: [
        () => { const k = pick([2, 5, 10, 3]), s = k * ri(1, 8); return mcn(`${s}, ${s + k}, ${s + 2 * k}, ☐`, s + 3 * k, `The pattern goes up by ${k} each time.`, [s + 2 * k + 1, s + 4 * k]); },
        () => { const k = pick([2, 5, 10]); return pickFrom(`Tap every number you say when you count by ${k}s.`, range(k, k * 12), 6, v => v % k === 0, `Counting by ${k}s: ${k}, ${2 * k}, ${3 * k}, ${4 * k} ...`); },
        () => { const k = pick([5, 10, 100]), s = k * ri(2, 9); return num(`Count back by ${k}s: ${s + 2 * k}, ${s + k}, ${s}, ?`, s - k, `Each step goes down by ${k}.`); },
        () => { const k = pick([2, 3, 4, 5, 10]), n = ri(3, 9); return num(`You make ${n} jumps of ${k} on a number line, starting at 0. Where do you land?`, n * k, `Count by ${k}s, ${n} times: ${n * k}.`); },
      ] },
      { name: 'Even, odd and hundreds', tip: 'Even numbers end in 0, 2, 4, 6 or 8. Odd numbers end in 1, 3, 5, 7 or 9. A three-digit number has hundreds, tens and ones: 365 is 3 hundreds, 6 tens, 5 ones.', gens: [
        () => pickFrom('Tap all the even numbers.', range(1, 60), 6, v => v % 2 === 0, 'Even numbers end in 0, 2, 4, 6 or 8.'),
        () => { const n = ri(11, 99), says = pick(['even', 'odd']); return tf(`${n} is ${says}.`, (n % 2 === 0) === (says === 'even'), `${n} ends in ${n % 10}, so it is ${n % 2 ? 'odd' : 'even'}.`); },
        () => { const h = ri(1, 9), t = ri(0, 9), o = ri(0, 9), n = h * 100 + t * 10 + o; return mcn(`${pl(h, 'hundred')}, ${pl(t, 'ten')} and ${pl(o, 'one')} make what number?`, n, `${h * 100} + ${t * 10} + ${o} = ${n}.`, [h * 100 + o * 10 + t, h + t + o]); },
        () => { const a = ri(100, 999), b = rnd() < 0.3 ? Math.floor(a / 10) * 10 + ri(0, 9) : ri(100, 999); return cmp(String(a), String(b), a, b, 'Compare the hundreds first, then the tens, then the ones.'); },
      ] },
      { name: 'Time and money', tip: 'On a clock the short hand shows the hour and the long hand shows the minutes. Coins: a penny is 1 cent, a nickel 5, a dime 10 and a quarter 25.', gens: [
        () => { const h = ri(1, 12), m = pick([0, 30, 15, 45]); return mc('What time does the clock show?', clock(h, m), [clock(h % 12 + 1, m), clock(h, (m + 30) % 60), clock(m / 5 || 12, h * 5 % 60), clock((h + 10) % 12 + 1, m), clock(h, (m + 15) % 60)], `The short hand shows the hour (${h}). The long hand shows the minutes (${String(m).padStart(2, '0')}).`, figClock(h, m)); },
        () => { let q = ri(0, 2), d = ri(0, 4), n = ri(0, 3), pn = ri(0, 4); if (q + d + n === 0) d = 2; const parts = [[q, 'quarter'], [d, 'dime'], [n, 'nickel'], [pn, 'penny']].filter(x => x[0]).map(([c, w]) => `${c} ${c > 1 ? (w === 'penny' ? 'pennies' : w + 's') : w}`); const total = q * 25 + d * 10 + n * 5 + pn; return num(`How many cents is this? ${parts.join(', ')}`, total, `Quarters are 25, dimes 10, nickels 5, pennies 1. Total: ${total} cents.`); },
        () => { const cost = ri(2, 9) * 5; return num(`A toy costs ${cost} cents. You pay with 50 cents. How many cents do you get back?`, 50 - cost, `50 - ${cost} = ${50 - cost}.`); },
        () => { const h = ri(1, 11); return mc(`It is ${h}:00. What time will it be in 30 minutes?`, `${h}:30`, [`${h + 1}:00`, `${h}:15`, `${h + 1}:30`], 'Thirty minutes is half an hour, so the minutes become 30.'); },
      ] },
    ],
  });

  MT.grades.push({
    grade: 3, title: 'Times tables, fractions and area', sections: [
      { name: 'Multiplication', tip: 'Multiplying is adding equal groups. 4 × 3 means 4 groups of 3: 3 + 3 + 3 + 3 = 12. You can picture it as 4 rows with 3 in each row.', gens: [
        () => { const a = ri(2, 10), b = ri(2, 10); return num(`${a} × ${b} = ?`, a * b, `${a} groups of ${b} make ${a * b}.`); },
        () => { const r = ri(2, 6), c = ri(2, 9); return num('How many dots? Multiply the rows by the columns.', r * c, `${r} rows × ${c} in each row = ${r * c}.`, figDots(r, c)); },
        () => { const a = ri(2, 9), b = ri(2, 9); return mcn(`${a} × ☐ = ${a * b}`, b, `${a} × ${b} = ${a * b}.`); },
        () => matchOf('Match each problem to its answer.', () => { const a = ri(2, 9), b = ri(2, 9); return [`${a} × ${b}`, a * b]; }, 'Think of equal groups, or skip count.'),
      ] },
      { name: 'Division', tip: 'Dividing shares into equal groups. 12 ÷ 3 asks: how many in each group if 12 is shared by 3? It is the opposite of multiplying: 3 × 4 = 12, so 12 ÷ 3 = 4.', gens: [
        () => { const a = ri(2, 10), b = ri(2, 10); return num(`${a * b} ÷ ${a} = ?`, b, `${a} × ${b} = ${a * b}, so ${a * b} ÷ ${a} = ${b}.`); },
        () => { const a = ri(2, 9), b = ri(2, 9), ok = rnd() < 0.5, c = ok ? b : b + pick([-1, 1]); return tf(`${a * b} ÷ ${a} = ${c}`, ok, `${a} × ${b} = ${a * b}, so the answer is ${b}.`); },
        () => { const b = ri(2, 9), c = ri(2, 9); return mcn(`☐ ÷ ${b} = ${c}`, b * c, `${b} × ${c} = ${b * c}.`, [b + c]); },
        () => { const k = ri(2, 6), each = ri(2, 9); return num(`${k * each} cookies are shared equally by ${k} friends. How many does each friend get?`, each, `${k * each} ÷ ${k} = ${each}.`); },
      ] },
      { name: 'Fractions', tip: 'A fraction names equal parts of a whole. The bottom number says how many equal parts there are. The top number says how many parts you have. {3/4} means 3 of 4 equal parts.', gens: [
        () => { const d = ri(2, 8), n = ri(1, d - 1); return mc('What fraction of the bar is shaded?', `{${n}/${d}}`, [`{${d - n}/${d}}`, `{${n}/${d + 1}}`, `{${d}/${n}}`, `{${n + 1}/${d}}`, `{${n}/${d + 2}}`], `${n} of the ${d} equal parts are shaded.`, figBar(n, d)); },
        () => { const d = ri(3, 10), a = ri(1, d - 1), b = ri(1, d - 1); return cmp(`{${a}/${d}}`, `{${b}/${d}}`, a, b, `The pieces are the same size, so compare the top numbers: ${a} and ${b}.`); },
        () => { const n = ri(1, 3), a = ri(4, 9), b = ri(4, 9); return cmp(`{${n}/${a}}`, `{${n}/${b}}`, n / a, n / b, 'Same number of pieces. The pieces are bigger when the bottom number is smaller.'); },
        () => pickMix('Tap every fraction that equals {1/2}.', ['{2/4}', '{3/6}', '{4/8}', '{5/10}'], ['{1/3}', '{2/5}', '{3/4}', '{2/6}', '{3/8}', '{4/6}', '{1/4}'], ri(2, 3), 3, 'A fraction equals {1/2} when the top is half of the bottom.'),
        () => { const d = ri(2, 8); return num(`How many {1/${d}} pieces make one whole?`, d, `${d} pieces of {1/${d}} make {${d}/${d}}, which is 1 whole.`); },
      ] },
      { name: 'Area and perimeter', tip: 'Perimeter is the distance around a shape: add all the sides. Area is the space inside: for a rectangle, multiply length × width. A 5 by 3 rectangle has perimeter 16 and area 15.', gens: [
        () => { const w = ri(2, 9), h = ri(2, 7); return num('What is the area of this rectangle, in square units?', w * h, `Area = length × width = ${w} × ${h} = ${w * h}.`, figRect(w, h)); },
        () => { const w = ri(2, 9), h = ri(2, 7); return num('What is the perimeter of this rectangle?', 2 * (w + h), `Add all four sides: ${w} + ${h} + ${w} + ${h} = ${2 * (w + h)}.`, figRect(w, h)); },
        () => { const w = ri(2, 9), h = ri(2, 9); return mcn(`A rectangle has an area of ${w * h} square units. One side is ${w} units long. How long is the other side?`, h, `${w} × ${h} = ${w * h}.`, [w * h - w]); },
        () => { const s = ri(2, 12); return num(`A square has sides ${s} units long. What is its perimeter?`, 4 * s, `A square has 4 equal sides: 4 × ${s} = ${4 * s}.`); },
      ] },
      { name: 'Rounding', tip: 'To round to the nearest ten, look at the ones digit. 5 or more rounds up, 4 or less rounds down. 47 rounds to 50. 43 rounds to 40. For hundreds, look at the tens digit.', gens: [
        () => { let n = ri(11, 989); if (n % 10 === 0) n += 3; const a = Math.round(n / 10) * 10; return mcn(`Round ${n} to the nearest ten.`, a, `The ones digit is ${n % 10}, so round ${n % 10 >= 5 ? 'up' : 'down'} to ${a}.`, [Math.floor(n / 10) * 10, Math.ceil(n / 10) * 10]); },
        () => { let n = ri(101, 949); if (n % 100 === 0) n += 37; const a = Math.round(n / 100) * 100; return num(`Round ${n} to the nearest hundred.`, a, `The tens digit is ${Math.floor(n / 10) % 10}, so round ${n % 100 >= 50 ? 'up' : 'down'} to ${a}.`); },
        () => { const T = 10 * ri(2, 9); return pickFrom(`Tap every number that rounds to ${T} (nearest ten).`, range(T - 9, T + 9).filter(v => v !== T), 6, v => Math.round(v / 10) * 10 === T, `Numbers from ${T - 5} to ${T + 4} round to ${T}.`); },
        () => { let n = ri(11, 98); if (n % 10 === 0) n += 4; const a = Math.round(n / 10) * 10, ok = rnd() < 0.5; return tf(`${n} rounded to the nearest ten is ${ok ? a : (a > n ? a - 10 : a + 10)}.`, ok, `${n} rounds to ${a}.`); },
      ] },
    ],
  });

  const FRACS = [[1, 2], [1, 3], [2, 3], [1, 4], [3, 4], [1, 5], [2, 5], [3, 5], [4, 5], [1, 6], [5, 6], [1, 8], [3, 8], [5, 8], [7, 8]];
  MT.grades.push({
    grade: 4, title: 'Big multiplication, factors and decimals', sections: [
      { name: 'Bigger multiplication', tip: 'Break a big number into tens and ones, multiply each part, then add. Example: 34 × 6 = (30 × 6) + (4 × 6) = 180 + 24 = 204.', gens: [
        () => { const a = ri(12, 99), b = ri(2, 9), t = Math.floor(a / 10) * 10, o = a % 10; return num(`${a} × ${b} = ?`, a * b, `${t} × ${b} = ${t * b} and ${o} × ${b} = ${o * b}. Add them: ${a * b}.`); },
        () => { const a = ri(11, 30), b = ri(11, 30), t = Math.floor(b / 10) * 10, o = b % 10; return mcn(`${a} × ${b} = ?`, a * b, `${a} × ${t} = ${a * t} and ${a} × ${o} = ${a * o}. Add them: ${a * b}.`, [a * t + o, a * b + a]); },
        () => { const a = ri(12, 99), k = pick([10, 100, 1000]); return num(`${a} × ${k} = ?`, a * k, `Multiplying by ${k} shifts the digits ${String(k).length - 1} place${k > 10 ? 's' : ''} to the left.`); },
        () => { const a = ri(12, 49), b = ri(3, 9), ok = rnd() < 0.5, c = ok ? a * b : a * b + pick([-b, b, 10, -10]); return tf(`${a} × ${b} = ${c}`, ok, `${a} × ${b} = ${a * b}.`); },
      ] },
      { name: 'Division with remainders', tip: 'Sometimes a number does not divide evenly. What is left over is the remainder. 17 ÷ 5: five goes in 3 times (15), with 2 left over. Write 3 R2.', gens: [
        () => { const d = ri(3, 9), q = ri(3, 12), r = ri(1, d - 1), n = d * q + r; return mc(`${n} ÷ ${d} = ?`, `${q} R${r}`, [`${q + 1} R${r}`, `${q - 1} R${r}`, `${q} R${r % (d - 1) + 1}`, `${r} R${q}`, `${q + 1} R0`], `${d} × ${q} = ${d * q}, and ${n} - ${d * q} = ${r} left over.`); },
        () => { const d = ri(2, 9), q = ri(12, 120); return num(`${d * q} ÷ ${d} = ?`, q, `${d} × ${q} = ${d * q}.`); },
        () => { const d = ri(3, 9), q = ri(3, 12), r = ri(1, d - 1), n = d * q + r; return num(`What is the remainder when ${n} is divided by ${d}?`, r, `${d} × ${q} = ${d * q}. ${n} - ${d * q} = ${r}.`); },
        () => { const d = ri(4, 12), q = ri(4, 15), r = ri(1, d - 1); return num(`${d * q + r} pencils are packed ${d} to a box. How many full boxes are there?`, q, `${d} × ${q} = ${d * q}, with ${r} pencils left over.`); },
      ] },
      { name: 'Factors, multiples and primes', tip: 'A factor divides a number evenly: the factors of 12 are 1, 2, 3, 4, 6, 12. A multiple is what you get by skip counting: 3, 6, 9, 12. A prime has only two factors, 1 and itself.', gens: [
        () => { const n = pick([12, 16, 18, 20, 24, 28, 30, 36, 40, 42, 48]); return pickFrom(`Tap every factor of ${n}.`, range(2, 12), 6, v => n % v === 0, `A factor divides ${n} with nothing left over.`); },
        () => pickFrom('Tap every prime number.', range(2, 40), 6, isPrime, 'A prime has exactly two factors: 1 and itself.'),
        () => { const k = ri(3, 9); return pickFrom(`Tap every multiple of ${k}.`, range(k + 1, k * 10), 6, v => v % k === 0, `Multiples of ${k}: ${k}, ${2 * k}, ${3 * k}, ${4 * k} ...`); },
        () => { const n = ri(11, 60), says = rnd() < 0.5; return tf(`${n} is ${says ? '' : 'not '}a prime number.`, isPrime(n) === says, isPrime(n) ? `${n} has no factors other than 1 and ${n}.` : `${n} = ${range(2, n).find(v => n % v === 0)} × ${n / range(2, n).find(v => n % v === 0)}, so it is not prime.`); },
        () => { const [a, b] = pick([[4, 6], [3, 5], [6, 8], [2, 7], [6, 9], [4, 10], [3, 4], [5, 6], [8, 12]]); return mcn(`What is the least common multiple of ${a} and ${b}?`, lcm(a, b), `It is the first number in both lists of multiples: ${lcm(a, b)}.`, [a * b === lcm(a, b) ? a + b : a * b, Math.max(a, b)]); },
      ] },
      { name: 'Equivalent fractions', tip: 'Multiply or divide the top and bottom by the same number and the fraction keeps its value. {1/2} = {2/4} = {3/6}. To compare fractions, give them the same bottom number first.', gens: [
        () => { const [n, d] = pick([[1, 2], [1, 3], [2, 3], [1, 4], [3, 4], [2, 5], [3, 5]]), k = ri(2, 5); return mc(`Which fraction is equal to {${n}/${d}}?`, `{${n * k}/${d * k}}`, [`{${n * k}/${d * k + 1}}`, `{${n + k}/${d + k}}`, `{${n * k + 1}/${d * k}}`, `{${d * k}/${n * k}}`], `Multiply top and bottom by ${k}: {${n * k}/${d * k}}.`); },
        () => { const [[a, b], [c, d]] = shuffle(FRACS).slice(0, 2); return cmp(`{${a}/${b}}`, `{${c}/${d}}`, a / b, c / d, `Cross-multiply: ${a} × ${d} = ${a * d} and ${c} × ${b} = ${c * b}.`); },
        () => { const [n, d] = pick(FRACS), k = ri(2, 6); return num(`{${n}/${d}} = {☐/${d * k}}   What number goes in the box?`, n * k, `The bottom was multiplied by ${k}, so multiply the top by ${k}: ${n * k}.`); },
        () => { const out = []; for (const f of shuffle(FRACS)) { if (out.length < 4 && !out.some(g => Math.abs(g[0] / g[1] - f[0] / f[1]) < 1e-9)) out.push(f); } return ord('Tap the fractions from smallest to biggest.', out.map(([n, d]) => ({ t: `{${n}/${d}}`, v: n / d }))); },
      ] },
      { name: 'Decimals', tip: 'Decimals are another way to write fractions with 10 or 100 on the bottom. 0.7 = {7/10} and 0.25 = {25/100}. Line up the decimal points to compare or add.', gens: [
        () => { const a = ri(1, 99) / 10, b = rnd() < 0.5 ? ri(1, 999) / 100 : ri(1, 99) / 10; return cmp(String(a), String(b), a, b, 'Compare the whole numbers first, then tenths, then hundredths.'); },
        () => ord('Tap the decimals from smallest to biggest.', distinct(4, 1, 99).map(v => v / (rnd() < 0.5 ? 10 : 100)).filter((v, i, a) => a.indexOf(v) === i).map(v => ({ t: String(v), v }))),
        () => { const d = pick([10, 100]), n = ri(1, d - 1), a = rd(n / d, 2); return mc(`Which decimal equals {${n}/${d}}?`, String(a), [String(rd(n / d / 10, 3)), String(rd(n / d * 10, 2)), String(n), String(rd(a + 0.1, 2)), String(rd(a + 0.01, 2))], `{${n}/${d}} means ${n} ${d === 10 ? 'tenths' : 'hundredths'}: ${a}.`); },
        () => { const a = ri(11, 89) / 10, b = ri(11, 89) / 10; return num(`${a} + ${b} = ?`, rd(a + b, 1), `Line up the decimal points and add: ${rd(a + b, 1)}.`); },
      ] },
    ],
  });
})();
