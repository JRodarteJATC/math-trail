/* Math Trail - the game: screens, puzzle play, hearts, stars and saved progress. */
(function () {
  const SAVE_KEY = 'mathtrail-v1';
  const ROUND = 8, BOSS_ROUND = 10, HEARTS = 3;
  const KIND = { choice: 'Tap the answer', input: 'Type the answer', tf: 'True or false?', compare: 'Pick the sign', order: 'Put in order', match: 'Match the pairs', pick: 'Tap all that fit', target: 'Make the number' };
  const PRAISE = ['Correct!', 'Nice work!', 'You got it!', 'Spot on!', 'Yes!'];
  const $ = id => document.getElementById(id);
  const view = $('view'), app = $('app');

  // ---------- saved progress (this browser only)
  let save = { stars: {}, sound: true };
  try { const s = JSON.parse(localStorage.getItem(SAVE_KEY) || 'null'); if (s && s.stars) save = s; } catch (e) {}
  const persist = () => { try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch (e) {} };

  // ---------- curriculum helpers
  const grades = MT.grades;
  const band = g => Math.ceil(g / 3);
  const stops = g => {
    const gr = grades[g - 1];
    return [...gr.sections, { name: `Grade ${g} challenge`, boss: true, tip: `A mix of everything from Grade ${g}. Pass it to finish the grade.`, gens: gr.sections.flatMap(s => s.gens) }];
  };
  const starsOf = (g, s) => save.stars[MT.sectionId(g, s)] || 0;
  const unlocked = (g, s) => s === 0 || starsOf(g, s - 1) > 0;
  const gradeStars = g => stops(g).reduce((a, _, s) => a + starsOf(g, s), 0);
  const totalStars = () => grades.reduce((a, gr) => a + gradeStars(gr.grade), 0);
  const kindsOf = st => [...new Set(st.gens.slice(0, 12).map(gen => { try { return KIND[gen().kind]; } catch (e) { return null; } }).filter(Boolean))];

  // ---------- text: {a/b} becomes a stacked fraction, ^ becomes a superscript
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const fmt = s => esc(s)
    .replace(/\{([^{}\/]+)\/([^{}]+)\}/g, '<span class="fr"><span>$1</span><span>$2</span></span>')
    .replace(/\^\(([^)]+)\)/g, '<sup>$1</sup>')
    .replace(/\^(-?(?:\w+(?:\.\d+)?|☐))/g, '<sup>$1</sup>');
  const starRow = (n, max = 3) => '★'.repeat(n) + `<i>${'★'.repeat(max - n)}</i>`;

  // ---------- sound (tiny synth, no files)
  let ac = null;
  function tone(freq, at, dur, type) {
    if (!save.sound) return;
    try {
      ac = ac || new (window.AudioContext || window.webkitAudioContext)();
      const o = ac.createOscillator(), g = ac.createGain(), t = ac.currentTime + at;
      o.type = type || 'sine'; o.frequency.value = freq;
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.14, t + 0.015); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g); g.connect(ac.destination); o.start(t); o.stop(t + dur + 0.02);
    } catch (e) {}
  }
  const sfx = {
    right: () => { tone(660, 0, 0.1); tone(880, 0.09, 0.16); },
    wrong: () => tone(196, 0, 0.25, 'triangle'),
    win: () => [523, 659, 784, 1047].forEach((f, i) => tone(f, i * 0.11, 0.2)),
    lose: () => [330, 262, 196].forEach((f, i) => tone(f, i * 0.16, 0.24, 'triangle')),
  };

  // ---------- confetti
  function confetti() {
    if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const c = $('confetti'), ctx = c.getContext('2d');
    c.hidden = false; c.width = innerWidth; c.height = innerHeight;
    const cs = getComputedStyle(app), cols = ['--band1', '--band2', '--band3', '--band4', '--star'].map(v => cs.getPropertyValue(v).trim());
    const ps = Array.from({ length: 110 }, () => ({ x: Math.random() * c.width, y: -20 - Math.random() * c.height * 0.4, vx: (Math.random() - 0.5) * 3, vy: 2 + Math.random() * 4, s: 5 + Math.random() * 6, r: Math.random() * 6, c: cols[Math.floor(Math.random() * cols.length)] }));
    const t0 = performance.now();
    (function frame(t) {
      ctx.clearRect(0, 0, c.width, c.height);
      for (const q of ps) { q.x += q.vx; q.y += q.vy; q.r += 0.1; ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(q.r); ctx.fillStyle = q.c; ctx.fillRect(-q.s / 2, -q.s / 2, q.s, q.s * 0.6); ctx.restore(); }
      if (t - t0 < 2400) requestAnimationFrame(frame); else { ctx.clearRect(0, 0, c.width, c.height); c.hidden = true; }
    })(t0);
  }

  // ---------- chrome
  function chrome(g) {
    app.dataset.band = g ? band(g) : 1;
    $('total').innerHTML = `<b>★</b> ${totalStars()}`;
    $('soundBtn').textContent = save.sound ? 'Sound on' : 'Sound off';
    window.scrollTo(0, 0);
  }
  $('soundBtn').addEventListener('click', () => { save.sound = !save.sound; persist(); $('soundBtn').textContent = save.sound ? 'Sound on' : 'Sound off'; if (save.sound) sfx.right(); });
  $('homeBtn').addEventListener('click', () => { run = null; home(); });

  // ---------- screens
  function home() {
    chrome(0);
    view.innerHTML = `
      <section class="stack">
        <h1>Pick your grade</h1>
        <p class="lead">Each grade is a trail of six stops. Read the lesson, solve the puzzles, and pass a stop to unlock the next one. You get 3 hearts per stop.</p>
      </section>
      <ul class="grades">${grades.map(gr => {
        const got = gradeStars(gr.grade), max = stops(gr.grade).length * 3;
        return `<li><button class="grade" type="button" data-g="${gr.grade}" data-band="${band(gr.grade)}">
          <span class="g-num">${gr.grade}</span>
          <span class="g-body"><b>Grade ${gr.grade}</b><small>${esc(gr.title)}</small>
          <span class="g-prog"><i style="width:${Math.round(got / max * 100)}%"></i></span>
          <span class="g-stars"><b>★</b> ${got} / ${max}</span></span></button></li>`;
      }).join('')}</ul>
      <div id="resetBox"><button class="link" id="resetBtn" type="button">Reset all progress</button></div>`;
    view.querySelectorAll('.grade').forEach(b => b.addEventListener('click', () => trail(+b.dataset.g)));
    $('resetBtn').addEventListener('click', () => {
      $('resetBox').innerHTML = `<div class="confirm stack"><p>Erase every star on this device? This cannot be undone.</p><div class="row"><button class="btn" id="yesReset" type="button">Erase progress</button><button class="btn" id="noReset" type="button">Keep it</button></div></div>`;
      $('yesReset').addEventListener('click', () => { save.stars = {}; persist(); home(); });
      $('noReset').addEventListener('click', home);
    });
  }

  function trail(g) {
    chrome(g);
    const st = stops(g);
    view.innerHTML = `
      <section class="stack">
        <button class="link" id="back" type="button">All grades</button>
        <h1>Grade ${g}</h1>
        <p class="lead">${esc(grades[g - 1].title)}. Clear each stop in order to reach the challenge at the end.</p>
        <div class="row"><button class="btn" id="bookBtn" type="button">Read all Grade ${g} lessons</button></div>
      </section>
      <ol class="trail">${st.map((s, i) => {
        const got = starsOf(g, i), open = unlocked(g, i), cls = got ? 'done' : open ? 'open' : 'locked';
        return `<li class="stop ${cls}">
          <span class="pin">${s.boss ? '★' : i + 1}</span>
          <div><h2>${esc(s.name)}</h2><small>${open ? esc(kindsOf(s).join(' · ')) : 'Pass the stop before this one to unlock it'}</small>${got ? `<p class="st">${starRow(got)}</p>` : ''}</div>
          <button class="btn ${open && !got ? 'main' : ''}" type="button" data-s="${i}" ${open ? '' : 'disabled'}>${got ? 'Play again' : open ? 'Start' : 'Locked'}</button></li>`;
      }).join('')}</ol>`;
    $('back').addEventListener('click', home);
    $('bookBtn').addEventListener('click', () => book(g));
    view.querySelectorAll('.stop .btn').forEach(b => b.addEventListener('click', () => lesson(g, +b.dataset.s)));
  }

  // the full lesson for one stop; the challenge stop gets a recap of the grade's five topics
  const lessonBody = (g, s) => {
    const st = stops(g)[s];
    if (st.boss) return `<section class="lz"><h3>Quick recap</h3><dl class="words recap">${grades[g - 1].sections.map(x => `<div><dt>${esc(x.name)}</dt><dd>${fmt(x.tip)}</dd></div>`).join('')}</dl></section>`;
    return MT.lessonHtml(st, MT.lessons && MT.lessons[MT.sectionId(g, s)]);
  };

  function lesson(g, s) {
    chrome(g);
    const st = stops(g)[s], n = st.boss ? BOSS_ROUND : ROUND, again = starsOf(g, s) > 0;
    view.innerHTML = `
      <button class="link" id="back" type="button">Grade ${g} trail</button>
      <article class="panel lesson">
        <p class="label">Stop ${s + 1} of ${stops(g).length} · ${st.boss ? 'Review' : 'Lesson'}</p>
        <h1>${esc(st.name)}</h1>
        ${again ? '<div class="row"><button class="btn" id="skip" type="button">Skip the lesson</button></div>' : ''}
        ${lessonBody(g, s)}
        <p class="rules">${n} puzzles. You have ${HEARTS} hearts, and a wrong answer costs one. Finish with at least one heart to pass.</p>
        <div class="row"><button class="btn main" id="go" type="button">Start puzzles</button></div>
      </article>`;
    $('back').addEventListener('click', () => trail(g));
    $('go').addEventListener('click', () => start(g, s));
    if ($('skip')) $('skip').addEventListener('click', () => start(g, s));
  }

  // every lesson of a grade on one page, for reading or teaching without playing
  function book(g) {
    chrome(g);
    view.innerHTML = `
      <section class="stack">
        <button class="link" id="back" type="button">Grade ${g} trail</button>
        <h1>Grade ${g} lessons</h1>
        <p class="lead">${esc(grades[g - 1].title)}. All five lessons in one place.</p>
      </section>
      ${grades[g - 1].sections.map((x, i) => `<article class="panel lesson"><p class="label">Lesson ${i + 1} of 5</p><h2 class="lesson-title">${esc(x.name)}</h2>${lessonBody(g, i)}</article>`).join('')}
      <div class="row"><button class="btn" id="back2" type="button">Back to the Grade ${g} trail</button></div>`;
    $('back').addEventListener('click', () => trail(g));
    $('back2').addEventListener('click', () => trail(g));
  }

  // ---------- a run of puzzles
  let run = null;
  function start(g, s) {
    const st = stops(g)[s];
    run = { g, s, st, qs: MT.round(st.gens, st.boss ? BOSS_ROUND : ROUND), i: 0, hearts: HEARTS, right: 0, streak: 0, marks: [], done: false };
    puzzle();
  }

  function puzzle() {
    const { g, qs, i } = run, q = qs[i];
    run.done = false; run.key = null;
    chrome(g);
    view.innerHTML = `
      <div class="hud">
        <button class="link" id="quit" type="button">Quit</button>
        <ol class="dots" aria-label="Progress">${qs.map((_, k) => `<li class="${k < i ? (run.marks[k] ? 'ok' : 'no') : k === i ? 'now' : ''}"></li>`).join('')}</ol>
        <span class="hearts" aria-label="${run.hearts} hearts left">${'♥'.repeat(run.hearts)}<i>${'♥'.repeat(HEARTS - run.hearts)}</i></span>
      </div>
      <article class="panel">
        <p class="label">Puzzle ${i + 1} of ${qs.length} · ${KIND[q.kind]}</p>
        <h1 class="q">${fmt(q.q)}</h1>
        ${q.fig ? `<div class="figbox">${q.fig}</div>` : ''}
        <div id="area" class="stack"></div>
        <div id="fb" aria-live="polite"></div>
      </article>`;
    $('quit').addEventListener('click', () => { run = null; trail(g); });
    BUILD[q.kind](q, $('area'));
  }

  // called once per puzzle with the verdict
  function grade(ok, answerText) {
    if (!run || run.done) return;
    run.done = true; run.marks[run.i] = ok;
    const q = run.qs[run.i];
    if (ok) { run.right++; run.streak++; sfx.right(); } else { run.hearts--; run.streak = 0; sfx.wrong(); }
    const last = run.i === run.qs.length - 1, out = run.hearts === 0;
    view.querySelector('.hearts').innerHTML = `${'♥'.repeat(run.hearts)}<i>${'♥'.repeat(HEARTS - run.hearts)}</i>`;
    view.querySelector('.dots .now').className = ok ? 'ok' : 'no';
    $('fb').innerHTML = `<div class="feedback ${ok ? '' : 'no'}">
      <p class="verdict">${ok ? PRAISE[Math.floor(Math.random() * PRAISE.length)] + (run.streak >= 3 ? ` ${run.streak} in a row!` : '') : 'Not quite.'}</p>
      ${!ok && answerText ? `<p><b>Answer:</b> ${fmt(answerText)}</p>` : ''}
      ${q.why ? `<p>${fmt(q.why)}</p>` : ''}
      <button class="btn main" id="next" type="button">${out || last ? 'See how you did' : 'Next puzzle'}</button></div>`;
    $('next').addEventListener('click', () => { if (out || last) finish(); else { run.i++; puzzle(); } });
    $('next').focus({ preventScroll: true });
    $('fb').scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }

  function finish() {
    const { g, s, st, qs, hearts, right } = run, passed = hearts > 0, id = MT.sectionId(g, s), all = stops(g);
    if (passed) { save.stars[id] = Math.max(save.stars[id] || 0, hearts); persist(); sfx.win(); confetti(); } else sfx.lose();
    chrome(g);
    const lastStop = s === all.length - 1;
    view.innerHTML = passed ? `
      <article class="panel">
        <p class="label">Grade ${g} · ${esc(st.name)}</p>
        <h1>${lastStop ? `Grade ${g} complete!` : 'Stop cleared!'}</h1>
        <p class="bigstars pop">${starRow(hearts)}</p>
        <p>You got ${right} of ${qs.length} right and kept ${hearts} ${hearts === 1 ? 'heart' : 'hearts'}.${hearts < 3 ? ' Play again to try for 3 stars.' : ''}</p>
        <div class="row">
          ${lastStop ? (g < 12 ? '<button class="btn main" id="a" type="button">On to Grade ' + (g + 1) + '</button>' : '<button class="btn main" id="a" type="button">Back to all grades</button>') : `<button class="btn main" id="a" type="button">Next stop: ${esc(all[s + 1].name)}</button>`}
          <button class="btn" id="b" type="button">Play again</button><button class="btn" id="c" type="button">Grade ${g} trail</button>
        </div>
      </article>` : `
      <article class="panel">
        <p class="label">Grade ${g} · ${esc(st.name)}</p>
        <h1>Out of hearts</h1>
        <p>You got ${right} right before the hearts ran out. Read the tip once more, then have another go. The next stop stays locked until you pass this one.</p>
        <p class="tip">${fmt(st.tip)}</p>
        <div class="row"><button class="btn main" id="b" type="button">Try again</button><button class="btn" id="d" type="button">Read the lesson again</button><button class="btn" id="c" type="button">Grade ${g} trail</button></div>
      </article>`;
    run = null;
    if ($('a')) $('a').addEventListener('click', () => (lastStop ? (g < 12 ? trail(g + 1) : home()) : lesson(g, s + 1)));
    $('b').addEventListener('click', () => start(g, s));
    $('c').addEventListener('click', () => trail(g));
    if ($('d')) $('d').addEventListener('click', () => lesson(g, s));
    ($('a') || $('b')).focus({ preventScroll: true });
  }

  // ---------- puzzle kinds.  Each builds its controls and calls grade() once.
  const lock = root => root.querySelectorAll('button').forEach(b => { b.disabled = true; });
  const BUILD = {
    choice(q, area) {
      const long = q.opts.some(o => o.replace(/[{}]/g, '').length > 14);
      area.innerHTML = `<div class="opts ${long ? 'long' : ''}">${q.opts.map((o, i) => `<button class="opt" type="button" data-i="${i}">${fmt(o)}</button>`).join('')}</div>`;
      const btns = [...area.querySelectorAll('.opt')];
      const choose = i => { if (run.done) return; lock(area); btns[q.a].classList.add('right'); if (i !== q.a) btns[i].classList.add('wrong'); grade(i === q.a, q.opts[q.a]); };
      btns.forEach((b, i) => b.addEventListener('click', () => choose(i)));
      run.key = e => { const i = '1234'.indexOf(e.key); if (i >= 0 && i < btns.length) choose(i); };
    },
    tf(q, area) {
      area.innerHTML = `<div class="opts"><button class="opt" type="button">True</button><button class="opt" type="button">False</button></div>`;
      const btns = [...area.querySelectorAll('.opt')];
      const choose = v => { if (run.done) return; lock(area); btns[q.a ? 0 : 1].classList.add('right'); if (v !== q.a) btns[v ? 0 : 1].classList.add('wrong'); grade(v === q.a, q.a ? 'True' : 'False'); };
      btns[0].addEventListener('click', () => choose(true)); btns[1].addEventListener('click', () => choose(false));
      run.key = e => { const k = e.key.toLowerCase(); if (k === 't') choose(true); if (k === 'f') choose(false); };
    },
    compare(q, area) {
      const signs = ['<', '=', '>'];
      area.innerHTML = `<div class="cmp"><span>${fmt(q.L)}</span><span class="slot" id="slot">?</span><span>${fmt(q.R)}</span></div>
        <div class="opts three">${signs.map(s => `<button class="opt" type="button">${esc(s)}</button>`).join('')}</div>`;
      const btns = [...area.querySelectorAll('.opt')];
      const choose = i => { if (run.done) return; lock(area); $('slot').textContent = q.a; btns[signs.indexOf(q.a)].classList.add('right'); if (signs[i] !== q.a) btns[i].classList.add('wrong'); grade(signs[i] === q.a, `${q.L} ${q.a} ${q.R}`); };
      btns.forEach((b, i) => b.addEventListener('click', () => choose(i)));
      run.key = e => { const i = ['<', '=', '>'].indexOf(e.key); if (i >= 0) choose(i); };
    },
    input(q, area) {
      let typed = '';
      area.innerHTML = `<div class="center"><div class="typed empty" id="typed">Type your answer</div>
        <div class="keys">${['7', '8', '9', '⌫', '4', '5', '6', '-', '1', '2', '3', '/', '0', '.'].map(k => `<button type="button" data-k="${k}" aria-label="${k === '⌫' ? 'Delete' : k === '-' ? 'Minus' : k}">${k === '-' ? '−' : k}</button>`).join('')}</div>
        <button class="btn main" id="check" type="button">Check</button></div>`;
      const show = () => { const el = $('typed'); el.textContent = typed ? typed.replace(/-/g, '−') : 'Type your answer'; el.classList.toggle('empty', !typed); };
      const press = k => {
        if (run.done) return;
        if (k === '⌫') typed = typed.slice(0, -1);
        else if (k === '-') typed = typed.startsWith('-') ? typed.slice(1) : '-' + typed;
        else if (typed.length < 10 && !((k === '.' || k === '/') && /[./]$/.test(typed))) typed += k;
        show();
      };
      const check = () => {
        if (run.done) return;
        const v = MT.value(typed);
        if (Number.isNaN(v)) { $('typed').classList.remove('shake'); void $('typed').offsetWidth; $('typed').classList.add('shake'); return; }
        lock(area);
        grade(Math.abs(v - MT.value(q.a)) < 1e-6, MT.showAnswer(q.a));
      };
      area.querySelectorAll('.keys button').forEach(b => b.addEventListener('click', () => press(b.dataset.k)));
      $('check').addEventListener('click', check);
      run.key = e => { if (/^[0-9./-]$/.test(e.key)) press(e.key); else if (e.key === 'Backspace') press('⌫'); else if (e.key === 'Enter') { e.preventDefault(); check(); } };
    },
    order(q, area) {
      const picked = [];
      area.innerHTML = `<p class="hint">Tap them in order. Tap one in the top row to put it back.</p><div class="tiles slots" id="slots"></div><div class="tiles" id="pool"></div>
        <div class="row"><button class="btn main" id="check" type="button" disabled>Check</button></div>`;
      const draw = () => {
        $('slots').innerHTML = picked.map(i => `<button class="tile sel" type="button" data-i="${i}">${fmt(q.items[i].t)}</button>`).join('');
        $('pool').innerHTML = q.items.map((it, i) => (picked.includes(i) ? '' : `<button class="tile" type="button" data-i="${i}">${fmt(it.t)}</button>`)).join('');
        $('check').disabled = picked.length !== q.items.length;
        $('pool').querySelectorAll('.tile').forEach(b => b.addEventListener('click', () => { if (!run.done) { picked.push(+b.dataset.i); draw(); } }));
        $('slots').querySelectorAll('.tile').forEach(b => b.addEventListener('click', () => { if (!run.done) { picked.splice(picked.indexOf(+b.dataset.i), 1); draw(); } }));
      };
      draw();
      $('check').addEventListener('click', () => {
        const ok = picked.every((i, k) => k === 0 || q.items[picked[k - 1]].v <= q.items[i].v);
        $('slots').querySelectorAll('.tile').forEach(b => b.classList.add(ok ? 'right' : 'wrong'));
        lock(area); grade(ok, '');
      });
    },
    match(q, area) {
      const right = MT.shuffle(q.pairs.map((pr, i) => i));
      let sel = null, miss = false, left = q.pairs.length;
      area.innerHTML = `<p class="hint">Tap one on the left, then its partner on the right.</p><div class="cols">${q.pairs.map((pr, k) =>
        `<button class="tile" type="button" data-side="L" data-i="${k}">${fmt(pr[0])}</button><button class="tile" type="button" data-side="R" data-i="${right[k]}">${fmt(q.pairs[right[k]][1])}</button>`).join('')}</div>`;
      const btns = [...area.querySelectorAll('.tile')];
      btns.forEach(b => b.addEventListener('click', () => {
        if (run.done || b.classList.contains('paired')) return;
        if (b.dataset.side === 'L') { btns.forEach(x => x.classList.remove('sel')); sel = b; b.classList.add('sel'); return; }
        if (!sel) return;
        if (sel.dataset.i === b.dataset.i) {
          [sel, b].forEach(x => { x.classList.remove('sel'); x.classList.add('paired'); x.disabled = true; });
          sel = null; left--;
          if (left === 0) grade(!miss, '');
        } else {
          miss = true; b.classList.remove('shake'); void b.offsetWidth; b.classList.add('shake');
          if (!area.querySelector('.missnote')) area.insertAdjacentHTML('beforeend', '<p class="hint missnote">That pair does not match. Keep going to finish the puzzle.</p>');
        }
      }));
    },
    pick(q, area) {
      area.innerHTML = `<div class="tiles">${q.tiles.map((t, i) => `<button class="tile" type="button" data-i="${i}" aria-pressed="false">${fmt(t.t)}</button>`).join('')}</div>
        <div class="row"><button class="btn main" id="check" type="button">Check</button></div>`;
      const btns = [...area.querySelectorAll('.tile')];
      btns.forEach(b => b.addEventListener('click', () => { if (!run.done) { const on = b.classList.toggle('sel'); b.setAttribute('aria-pressed', on); } }));
      $('check').addEventListener('click', () => {
        const ok = btns.every((b, i) => b.classList.contains('sel') === q.tiles[i].ok);
        btns.forEach((b, i) => { if (q.tiles[i].ok) b.classList.add('right'); else if (b.classList.contains('sel')) b.classList.add('wrong'); });
        lock(area); grade(ok, q.tiles.filter(t => t.ok).map(t => t.t).join(',  '));
      });
    },
    target(q, area) {
      area.innerHTML = `<div class="tiles">${q.tiles.map((t, i) => `<button class="tile" type="button" data-i="${i}" aria-pressed="false">${t}</button>`).join('')}</div>
        <p class="sum" id="sum">Total so far: 0</p><div class="row"><button class="btn main" id="check" type="button">Check</button></div>`;
      const btns = [...area.querySelectorAll('.tile')];
      const total = () => btns.reduce((a, b, i) => a + (b.classList.contains('sel') ? q.tiles[i] : 0), 0);
      btns.forEach(b => b.addEventListener('click', () => { if (!run.done) { const on = b.classList.toggle('sel'); b.setAttribute('aria-pressed', on); $('sum').textContent = `Total so far: ${total()}`; } }));
      $('check').addEventListener('click', () => { const ok = total() === q.T; btns.forEach(b => { if (b.classList.contains('sel')) b.classList.add(ok ? 'right' : 'wrong'); }); lock(area); grade(ok, ''); });
    },
  };

  window.addEventListener('keydown', e => {
    if (!run || e.metaKey || e.ctrlKey || e.altKey) return;
    if (run.done) return;                       // Enter on the focused Next button moves on by itself
    if (run.key) run.key(e);
  });

  // small hook used by automated tests
  window.MathTrail = { get run() { return run; }, home, trail, lesson, book, start, grade, save: () => save };
  home();
})();
