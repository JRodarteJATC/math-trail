/* Math Trail - core helpers: random numbers, question builders, figures.
   No DOM here, so the same file runs in the browser and in Node (tools/make-exports.js). */
(function () {
  const MT = (globalThis.MT = globalThis.MT || {});
  MT.grades = [];

  // ---------- random helpers
  const rnd = () => Math.random();
  const ri = (a, b) => a + Math.floor(rnd() * (b - a + 1));
  const pick = arr => arr[Math.floor(rnd() * arr.length)];
  const shuffle = arr => { const a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  const range = (a, b) => Array.from({ length: b - a + 1 }, (_, i) => a + i);
  const distinct = (k, lo, hi) => shuffle(range(lo, hi)).slice(0, k);
  const nz = (a, b) => { let v = 0; while (v === 0) v = ri(a, b); return v; };          // random non-zero integer
  const rd = (x, p = 2) => +(+x).toFixed(p);
  const gcd = (a, b) => (b ? gcd(b, a % b) : Math.abs(a));
  const lcm = (a, b) => a * b / gcd(a, b);
  const isPrime = n => { if (n < 2) return false; for (let i = 2; i * i <= n; i++) if (n % i === 0) return false; return true; };
  const fact = n => (n <= 1 ? 1 : n * fact(n - 1));

  // ---------- text helpers.  {a/b} shows as a stacked fraction, ^ makes a superscript.
  const fr = (n, d) => { const g = gcd(n, d) || 1; n /= g; d /= g; if (d < 0) { n = -n; d = -d; } return d === 1 ? String(n) : (n < 0 ? '-' : '') + `{${Math.abs(n)}/${d}}`; };
  const frs = (n, d) => { const g = gcd(n, d) || 1; n /= g; d /= g; if (d < 0) { n = -n; d = -d; } return d === 1 ? String(n) : `${n}/${d}`; };   // typed-answer form
  const p = n => (n < 0 ? `(${n})` : String(n));                                        // negative numbers in brackets
  const money = x => (Number.isInteger(x) ? String(x) : x.toFixed(2));
  const poly = (cs, v = 'x') => {                                                       // coefficients, highest power first
    const n = cs.length - 1; let out = '';
    cs.forEach((c, i) => {
      if (!c) return;
      const pw = n - i, mag = Math.abs(c);
      const body = pw === 0 ? String(mag) : (mag === 1 ? '' : mag) + v + (pw > 1 ? '^' + pw : '');
      out += out ? (c < 0 ? ' - ' : ' + ') + body : (c < 0 ? '-' : '') + body;
    });
    return out || '0';
  };
  const lin = (a, b, v = 'x') => poly([a, b], v);
  const mono = (c, pw, v = 'x') => (pw === 0 ? String(c) : poly([c, ...Array(pw).fill(0)], v));
  const fac = r => (r === 0 ? 'x' : `(x ${r < 0 ? '-' : '+'} ${Math.abs(r)})`);         // fac(3) = (x + 3)
  const facs = (...rs) => rs.slice().sort((a, b) => a - b).map(fac).join('');
  const cx = (a, b) => (b === 0 ? String(a) : a === 0 ? (Math.abs(b) === 1 ? (b < 0 ? '-i' : 'i') : b + 'i') : `${a} ${b < 0 ? '-' : '+'} ${Math.abs(b) === 1 ? '' : Math.abs(b)}i`);

  // ---------- question builders
  function near(n, extra = []) {
    const out = [], add = x => { x = rd(x, 4); if (x !== n && !out.includes(x) && (n < 0 || x >= 0)) out.push(x); };
    extra.forEach(add);
    const cand = Number.isInteger(n) ? [n + 1, n - 1, n + 2, n - 2, n + 10, n - 10, n + 3, n * 2, n + 5, n - 3, n + 4, n + 6]
      : [n + 0.1, n - 0.1, n + 1, n - 1, n * 10, n / 10, n + 0.5, n + 0.2];
    shuffle(cand).forEach(add);
    return out;
  }
  function mc(q, ans, wrong, why, fig) {
    ans = String(ans);
    const opts = [ans];
    for (const w of wrong.map(String)) { if (!opts.includes(w)) opts.push(w); if (opts.length === 4) break; }
    if (opts.length < 4) throw new Error('not enough options for: ' + q);
    const sh = shuffle(opts);
    return { kind: 'choice', q, opts: sh, a: sh.indexOf(ans), why, fig };
  }
  const mcn = (q, n, why, extra, fig) => mc(q, String(n), near(n, extra || []), why, fig);
  const num = (q, ans, why, fig) => ({ kind: 'input', q, a: ans, why, fig });
  const tf = (q, truth, why) => ({ kind: 'tf', q, a: !!truth, why });
  const cmp = (L, R, lv, rv, why) => ({ kind: 'compare', q: 'Which sign makes this true?', L, R, a: Math.abs(lv - rv) < 1e-9 ? '=' : lv < rv ? '<' : '>', why });
  const ord = (q, items, why) => {
    const sorted = items.slice().sort((a, b) => a.v - b.v);
    return { kind: 'order', q, items: shuffle(items), why: why || `In order: ${sorted.map(i => i.t).join(',  ')}.` };
  };
  function matchOf(q, gen, why) {
    const pairs = [], L = new Set(), R = new Set(); let guard = 0;
    while (pairs.length < 4 && guard++ < 400) {
      const [l, r] = gen(); const rs = String(r);
      if (L.has(l) || R.has(rs)) continue;
      L.add(l); R.add(rs); pairs.push([l, rs]);
    }
    if (pairs.length < 4) throw new Error('not enough pairs for: ' + q);
    return { kind: 'match', q, pairs, why };
  }
  const pickAll = (q, tiles, why) => {
    if (!tiles.some(t => t.ok) || tiles.every(t => t.ok)) throw new Error('bad tiles for: ' + q);
    return { kind: 'pick', q, tiles: shuffle(tiles), why };
  };
  function pickFrom(q, pool, count, pred, why) {                                         // sample numbers, some fit the rule
    for (let g = 0; g < 400; g++) {
      const s = shuffle(pool).slice(0, count), k = s.filter(pred).length;
      if (k >= 1 && k <= count - 1) return pickAll(q, s.map(v => ({ t: String(v), ok: !!pred(v) })), why);
    }
    throw new Error('pickFrom failed: ' + q);
  }
  const pickMix = (q, okPool, badPool, nOk, nBad, why) =>
    pickAll(q, [...shuffle(okPool).slice(0, nOk).map(t => ({ t: String(t), ok: true })), ...shuffle(badPool).slice(0, nBad).map(t => ({ t: String(t), ok: false }))], why);
  function target(T, maxTile) {                                                          // tap tiles that add up to T
    const a = ri(1, T - 1), tiles = [a, T - a];
    while (tiles.length < 5) tiles.push(ri(1, maxTile));
    return { kind: 'target', q: `Tap numbers that add up to ${T}.`, tiles: shuffle(tiles), T, why: `One way: ${a} + ${T - a} = ${T}.` };
  }

  // ---------- figures (inline SVG, colors come from the page's CSS)
  const svg = (w, h, body) => `<svg viewBox="0 0 ${w} ${h}" class="fig" style="max-width:${w * 1.4}px" role="img" aria-hidden="true">${body}</svg>`;
  const figDots = (r, c) => {
    let s = '';
    for (let i = 0; i < r; i++) for (let j = 0; j < c; j++) s += `<circle class="f-fill" cx="${13 + j * 24}" cy="${13 + i * 24}" r="8.5"/>`;
    return svg(c * 24 + 2, r * 24 + 2, s);
  };
  const figClock = (h, m) => {
    const pt = (deg, len) => { const t = deg * Math.PI / 180; return [(70 + len * Math.sin(t)).toFixed(1), (70 - len * Math.cos(t)).toFixed(1)]; };
    let s = '<circle class="f-face" cx="70" cy="70" r="64"/>';
    for (let i = 1; i <= 12; i++) { const [x, y] = pt(i * 30, 50); s += `<text class="f-text" x="${x}" y="${y}" dy=".36em" font-size="13">${i}</text>`; }
    for (let i = 0; i < 60; i += 5) { const [x1, y1] = pt(i * 6, 60), [x2, y2] = pt(i * 6, 64); s += `<line class="f-line" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"/>`; }
    const [hx, hy] = pt((h % 12 + m / 60) * 30, 30), [mx, my] = pt(m * 6, 46);
    s += `<line class="f-hand" x1="70" y1="70" x2="${hx}" y2="${hy}" stroke-width="5"/><line class="f-hand" x1="70" y1="70" x2="${mx}" y2="${my}" stroke-width="3"/><circle class="f-ink" cx="70" cy="70" r="4"/>`;
    return svg(140, 140, s);
  };
  const figBar = (n, d) => {
    const w = 220 / d; let s = '';
    for (let i = 0; i < d; i++) s += `<rect class="${i < n ? 'f-fill' : 'f-empty'} f-edge" x="${(2 + i * w).toFixed(1)}" y="2" width="${w.toFixed(1)}" height="44"/>`;
    return svg(224, 48, s);
  };
  const figRect = (w, h) => {
    const k = Math.min(170 / w, 96 / h), W = w * k, H = h * k;
    return svg(W + 40, H + 30, `<rect class="f-soft f-edge" x="4" y="4" width="${W.toFixed(1)}" height="${H.toFixed(1)}"/><text class="f-text" x="${(4 + W / 2).toFixed(1)}" y="${(H + 22).toFixed(1)}" font-size="15">${w}</text><text class="f-text" x="${(W + 20).toFixed(1)}" y="${(4 + H / 2).toFixed(1)}" dy=".36em" font-size="15">${h}</text>`);
  };
  // right triangle: bottom side "across", right side "up", sloped side "hyp"; theta sits at the left corner
  const figTri = (up, across, hyp, theta) =>
    svg(230, 150, `<polygon class="f-soft f-edge" points="24,118 190,118 190,24"/><polyline class="f-line" points="178,118 178,106 190,106" fill="none"/>` +
      `<text class="f-text" x="107" y="140" font-size="15">${across}</text><text class="f-text" x="208" y="72" dy=".36em" font-size="15">${up}</text><text class="f-text" x="94" y="60" font-size="15">${hyp}</text>` +
      (theta ? '<text class="f-text" x="56" y="112" font-size="14">θ</text>' : ''));
  // coordinate grid from lo..hi with optional points and a line through two points
  const figGrid = (pts, lo, hi, line) => {
    const n = hi - lo, u = 200 / n, X = x => (10 + (x - lo) * u).toFixed(1), Y = y => (10 + (hi - y) * u).toFixed(1);
    let s = '';
    for (let i = lo; i <= hi; i++) s += `<line class="f-grid" x1="${X(i)}" y1="${Y(lo)}" x2="${X(i)}" y2="${Y(hi)}"/><line class="f-grid" x1="${X(lo)}" y1="${Y(i)}" x2="${X(hi)}" y2="${Y(i)}"/>`;
    s += `<line class="f-axis" x1="${X(0)}" y1="${Y(lo)}" x2="${X(0)}" y2="${Y(hi)}"/><line class="f-axis" x1="${X(lo)}" y1="${Y(0)}" x2="${X(hi)}" y2="${Y(0)}"/>`;
    for (let i = lo; i <= hi; i++) if (i !== 0 && (n <= 8 || i % 2 === 0)) s += `<text class="f-num" x="${X(i)}" y="${(+Y(0) + 11).toFixed(1)}" font-size="8">${i}</text><text class="f-num" x="${(+X(0) - 7).toFixed(1)}" y="${Y(i)}" dy=".36em" font-size="8">${i}</text>`;
    if (line) {
      const [[x1, y1], [x2, y2]] = line, m = (y2 - y1) / (x2 - x1), b = y1 - m * x1;
      const clip = x => Math.max(lo, Math.min(hi, x));
      let xa = lo, xb = hi;
      if (m !== 0) { const c1 = (lo - b) / m, c2 = (hi - b) / m; xa = clip(Math.max(lo, Math.min(c1, c2))); xb = clip(Math.min(hi, Math.max(c1, c2))); }
      s += `<line class="f-plot" x1="${X(xa)}" y1="${Y(m * xa + b)}" x2="${X(xb)}" y2="${Y(m * xb + b)}"/>`;
    }
    for (const [x, y] of pts) s += `<circle class="f-pt" cx="${X(x)}" cy="${Y(y)}" r="5"/>`;
    return svg(220, 220, s);
  };

  Object.assign(MT, { rnd, ri, pick, shuffle, range, distinct, nz, rd, gcd, lcm, isPrime, fact, fr, frs, p, money, poly, lin, mono, fac, facs, cx,
    near, mc, mcn, num, tf, cmp, ord, matchOf, pickAll, pickFrom, pickMix, target, figDots, figClock, figBar, figRect, figTri, figGrid });

  // ---------- shared by the app and the export tool
  // numeric value of a typed or stored answer: "3/4", "-2.5", 7
  MT.value = s => { s = String(s).trim().replace(/−/g, '-'); if (/^-?\d*\.?\d+\/-?\d*\.?\d+$/.test(s)) { const [a, b] = s.split('/'); return +a / +b; } return /^-?\d*\.?\d+$/.test(s) ? +s : NaN; };
  MT.showAnswer = a => (typeof a === 'string' && a.includes('/') ? `{${a}}` : String(a));
  // build one round: n questions cycling through the section's puzzle makers, no repeated prompts
  MT.round = (gens, n) => {
    const out = [], seen = new Set(); let order = shuffle(gens), i = 0, guard = 0;
    while (out.length < n && guard++ < 500) {
      if (i >= order.length) { order = shuffle(gens); i = 0; }
      const q = order[i++](), key = q.q + '|' + (q.L || '') + (q.R || '') + (q.fig ? q.fig.length : '') + (q.pairs ? q.pairs.join() : '') + (q.tiles ? q.tiles.map(t => t.t || t).join() : '');
      if (seen.has(key)) continue;
      seen.add(key); out.push(q);
    }
    return out;
  };
  MT.sectionId = (g, s) => `g${g}s${s}`;
})();
