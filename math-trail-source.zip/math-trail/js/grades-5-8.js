/* Math Trail - grades 5 to 8. */
(function () {
  const { rnd, ri, pick, shuffle, range, distinct, nz, rd, gcd, lcm, fr, frs, p, money, lin, mc, mcn, num, tf, cmp, ord, matchOf, pickAll, pickFrom, pickMix,
    figTri, figGrid } = MT;

  // two fractions with different bottoms
  const twoFr = () => { const b = pick([2, 3, 4, 5, 6]), d = pick([2, 3, 4, 5, 6, 8].filter(x => x !== b)); return [ri(1, b - 1), b, ri(1, d - 1), d]; };

  MT.grades.push({
    grade: 5, title: 'Fractions, decimals and order of operations', sections: [
      { name: 'Adding and subtracting fractions', tip: 'Fractions need the same bottom number before you add or subtract. {1/2} + {1/3}: use sixths. {3/6} + {2/6} = {5/6}. Then simplify if you can.', gens: [
        () => { const [a, b, c, d] = twoFr(), n = a * d + c * b, den = b * d; return mc(`{${a}/${b}} + {${c}/${d}} = ?`, fr(n, den), [fr(a + c, b + d), fr(n + 1, den), fr(n, den + 1), fr(n - 1, den), fr(n + 2, den)], `Use ${den} as the bottom number: {${a * d}/${den}} + {${c * b}/${den}} = {${n}/${den}}${fr(n, den) !== `{${n}/${den}}` ? ' = ' + fr(n, den) : ''}.`); },
        () => { let [a, b, c, d] = twoFr(); if (a / b < c / d) [a, b, c, d] = [c, d, a, b]; const n = a * d - c * b, den = b * d; return mc(`{${a}/${b}} - {${c}/${d}} = ?`, fr(n, den), [fr(Math.abs(a - c) || 1, Math.abs(b - d) || 1), fr(n + 1, den), fr(n, den + 1), fr(n + 2, den), fr(n + 3, den)], `Use ${den} as the bottom number: {${a * d}/${den}} - {${c * b}/${den}} = {${n}/${den}}${fr(n, den) !== `{${n}/${den}}` ? ' = ' + fr(n, den) : ''}.`); },
        () => { const d = ri(5, 12), a = ri(1, d - 2), c = ri(1, d - 1 - a); return num(`{${a}/${d}} + {${c}/${d}} = ?   Type it like 3/4.`, frs(a + c, d), `The bottoms match, so add the tops: {${a + c}/${d}}${frs(a + c, d) !== `${a + c}/${d}` ? ' = ' + fr(a + c, d) : ''}.`); },
        () => { const b = pick([2, 3, 4, 6]), d = pick([3, 4, 5, 6, 8, 10].filter(x => x !== b)); return mcn(`What is the smallest common bottom number (denominator) for {1/${b}} and {1/${d}}?`, lcm(b, d), `It is the first number that both ${b} and ${d} divide into: ${lcm(b, d)}.`, [b * d === lcm(b, d) ? b + d : b * d, Math.max(b, d)]); },
      ] },
      { name: 'Multiplying fractions', tip: 'Multiply the tops, multiply the bottoms, then simplify. {2/3} × {3/4} = {6/12} = {1/2}. "Of" means multiply: {3/4} of 20 is 15.', gens: [
        () => { const [a, b, c, d] = twoFr(); return mc(`{${a}/${b}} × {${c}/${d}} = ?`, fr(a * c, b * d), [fr(a * d, b * c), fr(a + c, b + d), fr(a * c, b + d), fr(a * c + 1, b * d), fr(a * c, b * d + 1)], `Tops: ${a} × ${c} = ${a * c}. Bottoms: ${b} × ${d} = ${b * d}. Simplified: ${fr(a * c, b * d)}.`); },
        () => { const d = ri(2, 8), n = ri(1, d - 1), k = ri(2, 9); return num(`What is {${n}/${d}} of ${d * k}?`, n * k, `${d * k} ÷ ${d} = ${k}, then ${k} × ${n} = ${n * k}.`); },
        () => { const d = ri(2, 9), ok = rnd() < 0.5; return tf(`{1/2} of {1/${d}} is {1/${ok ? 2 * d : d + 2}}.`, ok, `{1/2} × {1/${d}} = {1/${2 * d}}.`); },
        () => { const d = ri(3, 9), n = ri(1, d - 1), k = ri(2, 6); return num(`${k} × {${n}/${d}} = ?   Type it like 3/4.`, frs(k * n, d), `${k} × ${n} = ${k * n}, so the answer is {${k * n}/${d}}${frs(k * n, d) !== `${k * n}/${d}` ? ' = ' + fr(k * n, d) : ''}.`); },
      ] },
      { name: 'Decimal operations', tip: 'To add or subtract decimals, line up the decimal points. To multiply by 10, 100 or 1000, move the decimal point right. To divide, move it left. 3.4 × 10 = 34.', gens: [
        () => { const a = ri(101, 999) / 100, b = ri(101, 999) / 100; return num(`${a} + ${b} = ?`, rd(a + b), `Line up the decimal points and add: ${rd(a + b)}.`); },
        () => { const a = ri(501, 999) / 100, b = ri(101, 499) / 100; return num(`${a} - ${b} = ?`, rd(a - b), `Line up the decimal points and subtract: ${rd(a - b)}.`); },
        () => { const a = ri(11, 99) / 10, k = ri(2, 9); return num(`${a} × ${k} = ?`, rd(a * k, 1), `${a * 10} × ${k} = ${rd(a * 10 * k, 0)}, then put the decimal point back: ${rd(a * k, 1)}.`); },
        () => { const a = ri(11, 999) / 100, k = pick([10, 100, 0.1]); return mc(`${a} × ${k} = ?`, String(rd(a * k, 4)), [String(rd(a * k * 10, 4)), String(rd(a * k / 10, 4)), String(rd(a * k * 100, 4)), String(rd(a + k, 4))], k > 1 ? `Move the decimal point ${k === 10 ? 'one place' : 'two places'} to the right.` : 'Multiplying by 0.1 moves the decimal point one place to the left.'); },
      ] },
      { name: 'Order of operations', tip: 'Work in this order: brackets first, then powers, then multiply and divide, then add and subtract. 3 + 4 × 2 = 3 + 8 = 11, but (3 + 4) × 2 = 14.', gens: [
        () => { const a = ri(2, 9), b = ri(2, 9), c = ri(2, 9); return num(`${a} + ${b} × ${c} = ?`, a + b * c, `Multiply first: ${b} × ${c} = ${b * c}. Then add ${a}: ${a + b * c}.`); },
        () => { const a = ri(2, 9), b = ri(2, 9), c = ri(2, 9); return num(`(${a} + ${b}) × ${c} = ?`, (a + b) * c, `Brackets first: ${a} + ${b} = ${a + b}. Then × ${c}: ${(a + b) * c}.`); },
        () => { const a = ri(4, 9), b = ri(4, 9), c = ri(2, 3), d = ri(2, 5); return num(`${a} × ${b} - ${c} × ${d} = ?`, a * b - c * d, `Do both multiplications first: ${a * b} - ${c * d} = ${a * b - c * d}.`); },
        () => { const a = ri(2, 20), b = ri(2, 6); return num(`${a} + ${b}^2 = ?`, a + b * b, `The power comes first: ${b}^2 = ${b * b}. Then add ${a}: ${a + b * b}.`); },
        () => { const a = ri(2, 9), b = ri(2, 9), c = ri(2, 9), ok = rnd() < 0.5; return tf(`${a} + ${b} × ${c} = ${ok ? a + b * c : (a + b) * c}`, ok, `Multiply before adding: ${a} + ${b * c} = ${a + b * c}.`); },
      ] },
      { name: 'Volume and coordinates', tip: 'Volume of a box = length × width × height. On a grid, a point is written (x, y): go across x first, then up y. (3, 2) is 3 across and 2 up.', gens: [
        () => { const l = ri(2, 9), w = ri(2, 6), h = ri(2, 6); return num(`A box is ${l} long, ${w} wide and ${h} tall. What is its volume in cubic units?`, l * w * h, `${l} × ${w} × ${h} = ${l * w * h}.`); },
        () => { const x = ri(1, 5), y = ri(1, 5); return mc('What are the coordinates of the point?', `(${x}, ${y})`, [`(${y}, ${x})`, `(${x + 1}, ${y})`, `(${x}, ${y + 1})`, `(${x - 1}, ${y})`, `(${x}, ${y - 1})`], `Go across ${x}, then up ${y}. Across always comes first.`, figGrid([[x, y]], 0, 6)); },
        () => { const l = ri(2, 9), w = ri(2, 6), h = ri(2, 6); return mcn(`A box has a volume of ${l * w * h} cubic units. It is ${l} long and ${w} wide. How tall is it?`, h, `${l} × ${w} = ${l * w}, and ${l * w * h} ÷ ${l * w} = ${h}.`); },
        () => { const s = ri(2, 6); return num(`How many unit cubes fill a cube with sides of ${s}?`, s ** 3, `${s} × ${s} × ${s} = ${s ** 3}.`); },
      ] },
    ],
  });

  const meanSet = () => { for (;;) { const n = pick([4, 5]), m = ri(5, 20), xs = Array.from({ length: n - 1 }, () => ri(m - 4, m + 4)), last = m * n - xs.reduce((a, b) => a + b, 0); if (last > 0 && last < 40) return { xs: shuffle([...xs, last]), m }; } };
  MT.grades.push({
    grade: 6, title: 'Ratios, percents, negatives and equations', sections: [
      { name: 'Ratios and rates', tip: 'A ratio compares two amounts, like 2 to 3 (2:3). Multiply both parts by the same number to get an equal ratio: 2:3 = 4:6. A unit rate is the amount for 1: $6 for 3 is $2 each.', gens: [
        () => { const k = ri(2, 8), c = pick([2, 3, 4, 5, 1.5, 2.5]); return num(`${k} notebooks cost $${money(k * c)}. How much does 1 notebook cost, in dollars?`, c, `Divide the cost by the number of notebooks: ${money(k * c)} ÷ ${k} = ${c}.`); },
        () => { const a = ri(1, 5), b = ri(a + 1, 8), k = ri(2, 6); return mcn(`${a}:${b} = ☐:${b * k}`, a * k, `${b} was multiplied by ${k}, so multiply ${a} by ${k}: ${a * k}.`, [a + b * k - b, a * b]); },
        () => { const [a, b] = pick([[1, 2], [2, 3], [3, 4], [2, 5], [3, 5], [1, 4]]); const ks = shuffle([2, 3, 4, 5]); return pickAll(`Tap every ratio equal to ${a}:${b}.`, [...ks.slice(0, ri(2, 3)).map(k => ({ t: `${a * k}:${b * k}`, ok: true })), { t: `${b * 2}:${a * 2}`, ok: false }, { t: `${a + 2}:${b + 2}`, ok: false }, { t: `${a * 3}:${b * 3 + 1}`, ok: false }], 'Equal ratios come from multiplying both parts by the same number.'); },
        () => { const s = ri(20, 65), t = ri(2, 6); return num(`A car goes ${s * t} miles in ${t} hours. What is its speed in miles per hour?`, s, `${s * t} ÷ ${t} = ${s} miles each hour.`); },
      ] },
      { name: 'Percents', tip: 'Percent means "out of 100". 25% = {25/100} = {1/4}. To find a percent of a number, turn it into a fraction or decimal and multiply: 25% of 80 = 80 ÷ 4 = 20.', gens: [
        () => { const pc = pick([5, 10, 20, 25, 50, 75]), n = 20 * ri(1, 10); return num(`What is ${pc}% of ${n}?`, pc * n / 100, `${pc}% = {${pc}/100}. ${n} × ${pc} ÷ 100 = ${pc * n / 100}.`); },
        () => matchOf('Match each fraction to its percent.', () => pick([['{1/2}', '50%'], ['{1/4}', '25%'], ['{3/4}', '75%'], ['{1/5}', '20%'], ['{1/10}', '10%'], ['{2/5}', '40%'], ['{3/5}', '60%'], ['{1/20}', '5%'], ['{4/5}', '80%']]), 'Change the bottom number to 100, or divide top by bottom and multiply by 100.'),
        () => { const pc = pick([10, 20, 25, 40, 50, 60, 75, 80]), b = pick([20, 40, 60, 80, 200]); return num(`${pc * b / 100} is what percent of ${b}?`, pc, `${pc * b / 100} ÷ ${b} = ${pc / 100}, which is ${pc}%.`); },
        () => { const d = pick([0.07, 0.35, 0.6, 1.2, 0.09, 0.45, 0.8]), v = rd(d * 100, 0); return mc(`Write ${d} as a percent.`, `${v}%`, [`${rd(d * 10, 1)}%`, `${d}%`, `${v * 10}%`], `Multiply by 100: ${d} × 100 = ${v}%.`); },
      ] },
      { name: 'Negative numbers', tip: 'Numbers below zero are negative. On a number line, adding moves right and subtracting moves left. Subtracting a negative is the same as adding: 5 - (-3) = 5 + 3 = 8.', gens: [
        () => { const a = ri(-12, 12), b = ri(-12, -1); return num(`${a} + ${p(b)} = ?`, a + b, `Adding a negative moves left on the number line: ${a + b}.`); },
        () => { const a = ri(-10, 10), b = ri(-10, 10); return num(`${a} - ${p(b)} = ?`, a - b, b < 0 ? `Subtracting a negative is adding: ${a} + ${-b} = ${a - b}.` : `Move ${b} to the left of ${a}: ${a - b}.`); },
        () => { const a = ri(-20, 20), b = rnd() < 0.15 ? a : ri(-20, 20); return cmp(String(a), String(b), a, b, 'The number further right on the number line is greater. -3 is greater than -8.'); },
        () => ord('Tap the numbers from smallest to biggest.', distinct(4, -20, 20).map(v => ({ t: String(v), v }))),
        () => { const a = ri(2, 12), b = ri(2, 9), ok = rnd() < 0.5; return tf(`${a} - (-${b}) = ${ok ? a + b : a - b}`, ok, `Subtracting a negative is adding: ${a} + ${b} = ${a + b}.`); },
      ] },
      { name: 'Expressions and equations', tip: 'A letter stands for a number. To solve an equation, undo what was done to x, on both sides. x + 7 = 15: subtract 7 from both sides, so x = 8.', gens: [
        () => { const x = ri(2, 9), a = ri(2, 9), b = ri(1, 12); return num(`If x = ${x}, what is ${a}x + ${b}?`, a * x + b, `${a} × ${x} = ${a * x}, then add ${b}: ${a * x + b}.`); },
        () => { const x = ri(2, 30), a = ri(2, 20); return num(`Solve: x + ${a} = ${a + x}`, x, `Subtract ${a} from both sides: x = ${x}.`); },
        () => { const x = ri(2, 12), a = ri(2, 12); return num(`Solve: ${a}x = ${a * x}`, x, `Divide both sides by ${a}: x = ${x}.`); },
        () => { const a = ri(2, 15), x = a + ri(1, 20); return num(`Solve: x - ${a} = ${x - a}`, x, `Add ${a} to both sides: x = ${x}.`); },
        () => { const [a, b] = distinct(2, 2, 9); return mc(`Which expression means "${a} more than ${b} times a number n"?`, `${b}n + ${a}`, [`${a}n + ${b}`, `${a + b}n`, `${b}(n + ${a})`], `"${b} times a number" is ${b}n. "${a} more" adds ${a}.`); },
      ] },
      { name: 'Area and data', tip: 'Area of a triangle = {1/2} × base × height. The mean is the total divided by how many numbers there are. The median is the middle number when they are in order.', gens: [
        () => { const b = 2 * ri(2, 10), h = ri(3, 12); return num(`A triangle has a base of ${b} and a height of ${h}. What is its area?`, b * h / 2, `{1/2} × ${b} × ${h} = ${b * h / 2}.`); },
        () => { const { xs, m } = meanSet(); return num(`What is the mean (average) of ${xs.join(', ')}?`, m, `The total is ${m * xs.length}. Divide by ${xs.length}: ${m}.`); },
        () => { const xs = distinct(5, 1, 40), s = xs.slice().sort((a, b) => a - b); return num(`What is the median of ${xs.join(', ')}?`, s[2], `In order: ${s.join(', ')}. The middle one is ${s[2]}.`); },
        () => { const xs = distinct(5, 1, 60), hi = Math.max(...xs), lo = Math.min(...xs); return mcn(`What is the range of ${xs.join(', ')}?`, hi - lo, `Biggest minus smallest: ${hi} - ${lo} = ${hi - lo}.`, [hi, hi + lo]); },
      ] },
    ],
  });

  const SIGN_FACTS = [['A negative times a negative is positive.', true], ['A negative times a positive is negative.', true], ['A negative divided by a negative is negative.', false], ['A positive times a negative is positive.', false], ['The product of three negative numbers is negative.', true], ['Zero times a negative number is negative.', false]];
  const PCT_FACTS = [['50% off, then another 50% off, makes an item free.', false, 'The second 50% is taken from the lower price, so you still pay 25%.'], ['A 100% increase doubles a number.', true, 'Adding 100% of a number to itself doubles it.'], ['To find a 20% tip you can find 10% and double it.', true, '20% is twice 10%.'], ['A 10% increase followed by a 10% decrease gets you back to the start.', false, 'The decrease is taken from the bigger number, so you end up a little lower.'], ['25% of a number is the same as dividing it by 4.', true, '25% = {1/4}.'], ['Sales tax makes the total smaller.', false, 'Tax is added to the price.']];
  MT.grades.push({
    grade: 7, title: 'Signed numbers, proportions and two-step equations', sections: [
      { name: 'Multiplying signed numbers', tip: 'Same signs give a positive answer, different signs give a negative answer. (-3) × (-4) = 12 and (-3) × 4 = -12. The same rule works for division.', gens: [
        () => { const a = nz(-9, 9), b = ri(-9, -2); return num(`${p(a)} × ${p(b)} = ?`, a * b, `${Math.abs(a)} × ${Math.abs(b)} = ${Math.abs(a * b)}. The signs are ${a * b > 0 ? 'the same, so the answer is positive' : 'different, so the answer is negative'}.`); },
        () => { const a = nz(-9, 9), b = nz(-9, 9); return num(`${a * b} ÷ ${p(b)} = ?`, a, `${Math.abs(a * b)} ÷ ${Math.abs(b)} = ${Math.abs(a)}. The signs are ${a > 0 ? 'the same, so the answer is positive' : 'different, so the answer is negative'}.`); },
        () => { const a = nz(-6, 6), b = ri(-6, -2), c = ri(1, 15); return num(`${p(a)} × ${p(b)} + ${c} = ?`, a * b + c, `Multiply first: ${a * b}. Then add ${c}: ${a * b + c}.`); },
        () => { const [s, t] = pick(SIGN_FACTS); return tf(s, t, 'Same signs give a positive, different signs give a negative.'); },
        () => { const a = nz(-6, 6), b = nz(-6, 6), c = a * b + pick([-5, 0, 0, 5]); return cmp(`${p(a)} × ${p(b)}`, String(c), a * b, c, `${p(a)} × ${p(b)} = ${a * b}.`); },
      ] },
      { name: 'Proportions', tip: 'A proportion says two ratios are equal. To solve {3/4} = {x/20}, see that 4 was multiplied by 5 to get 20, so x = 3 × 5 = 15. Or cross-multiply: 4x = 60.', gens: [
        () => { const a = ri(1, 7), b = ri(a + 1, 9), k = ri(2, 9); return num(`Solve: {${a}/${b}} = {x/${b * k}}`, a * k, `${b} × ${k} = ${b * k}, so x = ${a} × ${k} = ${a * k}.`); },
        () => { const a = ri(2, 5), c = ri(2, 6), k = ri(2, 5); return num(`${a} notebooks cost $${a * c}. How much do ${a * k} notebooks cost, in dollars?`, a * c * k, `That is ${k} times as many notebooks, so ${k} times the cost: ${a * c * k}.`); },
        () => { const k = ri(2, 9), x = ri(2, 6), x2 = ri(7, 12); return mcn(`y is proportional to x. When x = ${x}, y = ${k * x}. What is y when x = ${x2}?`, k * x2, `y is always ${k} times x. ${k} × ${x2} = ${k * x2}.`, [k * x + x2, x2 + k]); },
        () => { const s = pick([5, 10, 20, 25, 50]), n = ri(2, 9); return num(`A map uses 1 inch for ${s} miles. How many miles is ${n} inches?`, s * n, `${n} × ${s} = ${s * n} miles.`); },
        () => { const k = ri(2, 12), x = ri(2, 9); return mcn(`In y = kx, x = ${x} gives y = ${k * x}. What is k?`, k, `k = y ÷ x = ${k * x} ÷ ${x} = ${k}.`, [k * x - x, x]); },
      ] },
      { name: 'Percent change', tip: 'For a discount, find the percent of the price and subtract it. For tax or a tip, add it. Percent change = change ÷ original × 100. From 40 to 50 is a change of 10, and 10 ÷ 40 = 25%.', gens: [
        () => { const price = 20 * ri(1, 10), pc = pick([10, 20, 25, 30, 50]); return num(`A $${price} jacket is ${pc}% off. What is the sale price in dollars?`, price * (100 - pc) / 100, `${pc}% of ${price} is ${price * pc / 100}. ${price} - ${price * pc / 100} = ${price * (100 - pc) / 100}.`); },
        () => { const m = 20 * ri(1, 6), t = pick([10, 15, 20]); return num(`A meal costs $${m}. You leave a ${t}% tip. What is the total in dollars?`, m + m * t / 100, `${t}% of ${m} is ${m * t / 100}. ${m} + ${m * t / 100} = ${m + m * t / 100}.`); },
        () => { const a = pick([20, 40, 60, 80, 200]), pc = pick([10, 20, 25, 50, 100]), b = a * (100 + pc) / 100; return mcn(`A price goes from $${a} to $${b}. What is the percent increase?`, pc, `The change is ${b - a}. ${b - a} ÷ ${a} = ${pc / 100}, which is ${pc}%.`, [b - a, rd((b - a) / b * 100, 0)]); },
        () => { const [s, t, w] = pick(PCT_FACTS); return tf(s, t, w); },
      ] },
      { name: 'Two-step equations', tip: 'Undo the adding or subtracting first, then undo the multiplying or dividing. 3x + 5 = 20: subtract 5 to get 3x = 15, then divide by 3 to get x = 5.', gens: [
        () => { const a = ri(2, 9), x = ri(-5, 9), b = ri(1, 12); return num(`Solve: ${a}x + ${b} = ${a * x + b}`, x, `Subtract ${b}: ${a}x = ${a * x}. Divide by ${a}: x = ${x}.`); },
        () => { const a = ri(2, 9), x = ri(-4, 9), b = ri(1, 12); return num(`Solve: ${a}x - ${b} = ${a * x - b}`, x, `Add ${b}: ${a}x = ${a * x}. Divide by ${a}: x = ${x}.`); },
        () => { const a = ri(2, 6), b = ri(1, 9), c = ri(1, 9); return num(`Solve: {x/${a}} - ${b} = ${c}`, a * (b + c), `Add ${b}: {x/${a}} = ${b + c}. Multiply by ${a}: x = ${a * (b + c)}.`); },
        () => { const a = ri(2, 6), x = ri(-3, 9), b = ri(1, 9); return num(`Solve: ${a}(x + ${b}) = ${a * (x + b)}`, x, `Divide by ${a}: x + ${b} = ${x + b}. Subtract ${b}: x = ${x}.`); },
        () => { const a = ri(2, 9), b = ri(2, 12), c = b + a * ri(2, 9); return mc(`What is the best first step to solve ${a}x + ${b} = ${c}?`, `Subtract ${b} from both sides`, [`Add ${b} to both sides`, `Divide only the ${c} by ${a}`, `Multiply both sides by ${a}`], 'Undo the adding first, then the multiplying.'); },
      ] },
      { name: 'Circles and chance', tip: 'For a circle with radius r: circumference = 2πr and area = πr^2. Probability = (ways you want) ÷ (all possible ways). One red out of 4 marbles is a chance of {1/4}.', gens: [
        () => { const r = ri(3, 12); return mc(`A circle has a radius of ${r}. What is its circumference?`, `${2 * r}π`, [`${r}π`, `${r * r}π`, `${4 * r}π`, `${2 * r + 2}π`], `C = 2πr = 2 × π × ${r} = ${2 * r}π.`); },
        () => { const r = ri(3, 12); return mc(`A circle has a radius of ${r}. What is its area?`, `${r * r}π`, [`${2 * r}π`, `${r}π`, `${4 * r * r}π`, `${r * r + r}π`], `A = πr^2 = π × ${r} × ${r} = ${r * r}π.`); },
        () => { const r = ri(1, 6), b = ri(1, 6), t = r + b; return mc(`A bag has ${r} red and ${b} blue marbles. You pick one without looking. What is the chance it is red?`, fr(r, t), [fr(b, t), fr(r, t + 1), fr(1, t), fr(r + 1, t + 2), fr(1, t + 1), fr(r, t + 2), '{3/4}', '{2/3}', '{1/5}', '{1/3}'].filter(x => x !== '1'), `${r} of the ${t} marbles are red: ${fr(r, t)}.`); },
        () => { const r = ri(2, 15); return num(`A circle has a diameter of ${2 * r}. What is its radius?`, r, `The radius is half the diameter: ${2 * r} ÷ 2 = ${r}.`); },
        () => { const k = ri(1, 5); return mc(`You roll a number cube (1 to 6). What is the chance of rolling a number greater than ${k}?`, fr(6 - k, 6), ['{1/6}', '{1/3}', '{1/2}', '{2/3}', '{5/6}', '{1/4}'], `${6 - k} of the 6 numbers are greater than ${k}: ${fr(6 - k, 6)}.`); },
      ] },
    ],
  });

  const TRIPLES = [[3, 4, 5], [6, 8, 10], [5, 12, 13], [8, 15, 17], [9, 12, 15], [12, 16, 20]];
  MT.grades.push({
    grade: 8, title: 'Exponents, roots, lines and systems', sections: [
      { name: 'Exponents', tip: 'An exponent says how many times to multiply: 2^3 = 2 × 2 × 2 = 8. Same base: multiply by adding exponents (2^3 × 2^4 = 2^7), divide by subtracting. A negative exponent flips: 2^-3 = {1/8}.', gens: [
        () => { const b = ri(2, 5), e = ri(2, 4); return num(`${b}^${e} = ?`, b ** e, `Multiply ${b} by itself ${e} times: ${b ** e}.`); },
        () => { const b = ri(2, 9), m = ri(2, 7), n = ri(2, 7); return num(`${b}^${m} × ${b}^${n} = ${b}^☐   What goes in the box?`, m + n, `Same base, so add the exponents: ${m} + ${n} = ${m + n}.`); },
        () => { const b = ri(2, 9), m = ri(2, 5), n = ri(2, 4); return num(`(${b}^${m})^${n} = ${b}^☐   What goes in the box?`, m * n, `A power of a power: multiply the exponents: ${m} × ${n} = ${m * n}.`); },
        () => { const b = ri(2, 5), e = ri(2, 3); return mc(`${b}^-${e} = ?`, `{1/${b ** e}}`, [`-${b ** e}`, `-{1/${b ** e}}`, `${b ** e}`, `{1/${b * e + 1}}`], `A negative exponent means "one over": {1/${b}^${e}} = {1/${b ** e}}.`); },
        () => { const m = ri(11, 99) / 10, e = ri(2, 5), v = rd(m * 10 ** e, 0); return mc(`${m} × 10^${e} = ?`, String(v), [String(v * 10), String(v / 10), String(rd(m * e, 1))], `Move the decimal point ${e} places to the right: ${v}.`); },
        () => { const b = ri(2, 9), n = ri(2, 5), m = n + ri(1, 5); return num(`${b}^${m} ÷ ${b}^${n} = ${b}^☐   What goes in the box?`, m - n, `Same base, so subtract the exponents: ${m} - ${n} = ${m - n}.`); },
      ] },
      { name: 'Roots and right triangles', tip: 'A square root undoes squaring: √49 = 7 because 7 × 7 = 49. In a right triangle, a^2 + b^2 = c^2, where c is the longest side. Legs 3 and 4 give c = 5.', gens: [
        () => { const n = ri(2, 15); return num(`√${n * n} = ?`, n, `${n} × ${n} = ${n * n}.`); },
        () => { const [a, b, c] = pick(TRIPLES); return num('How long is the missing side?', c, `${a}^2 + ${b}^2 = ${a * a} + ${b * b} = ${c * c}, and √${c * c} = ${c}.`, figTri(a, b, '?')); },
        () => { const [a, b, c] = pick(TRIPLES); return num('How long is the missing side?', b, `${c}^2 - ${a}^2 = ${c * c} - ${a * a} = ${b * b}, and √${b * b} = ${b}.`, figTri(a, '?', c)); },
        () => { let n = ri(5, 99); if (Number.isInteger(Math.sqrt(n))) n += 1; const lo = Math.floor(Math.sqrt(n)); return mc(`√${n} is between which two whole numbers?`, `${lo} and ${lo + 1}`, [`${lo - 1} and ${lo}`, `${lo + 1} and ${lo + 2}`, `${lo + 2} and ${lo + 3}`], `${lo}^2 = ${lo * lo} and ${lo + 1}^2 = ${(lo + 1) ** 2}. ${n} is between them.`); },
        () => pickMix('Tap every perfect square.', [4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144], [8, 12, 18, 20, 24, 27, 32, 45, 48, 50, 60, 72, 90, 99, 110, 125], 3, 3, 'A perfect square is a whole number times itself, like 6 × 6 = 36.'),
      ] },
      { name: 'Linear equations', tip: 'Collect the x terms on one side and the numbers on the other. 5x - 3 = 2x + 9: subtract 2x to get 3x - 3 = 9, add 3 to get 3x = 12, so x = 4.', gens: [
        () => { const a = ri(3, 9), c = ri(1, a - 1), x = ri(-4, 8), b = ri(1, 9), d = (a - c) * x - b; return num(`Solve: ${lin(a, -b)} = ${lin(c, d)}`, x, `Subtract ${c}x from both sides: ${lin(a - c, -b)} = ${d}. Then x = ${x}.`); },
        () => { const a = ri(2, 5), c = ri(1, a - 1), b = ri(1, 6), x = ri(-3, 9), d = a * (x - b) - c * x; return num(`Solve: ${a}(x - ${b}) = ${lin(c, d)}`, x, `Expand: ${lin(a, -a * b)} = ${lin(c, d)}. Collect terms: ${lin(a - c, 0)} = ${d + a * b}. So x = ${x}.`); },
        () => { const a = ri(2, 6), b = ri(1, 9), c = b + ri(1, 9); return num(`Solve: {x/${a}} + ${b} = ${c}`, a * (c - b), `Subtract ${b}: {x/${a}} = ${c - b}. Multiply by ${a}: x = ${a * (c - b)}.`); },
        () => { const a = ri(2, 9), b = ri(1, 9), same = rnd() < 0.5, c = same ? b : b + ri(1, 5); return mc(`How many solutions does ${a}x + ${b} = ${a}x + ${c} have?`, same ? 'Infinitely many' : 'None', ['None', 'One', 'Two', 'Infinitely many'], same ? 'Both sides are identical, so every number works.' : `Subtract ${a}x from both sides and you get ${b} = ${c}, which is never true.`); },
      ] },
      { name: 'Slope and lines', tip: 'Slope is rise over run: how far up for each step right. Between (1, 2) and (3, 8) the slope is (8 - 2) ÷ (3 - 1) = 3. In y = mx + b, m is the slope and b is where the line crosses the y-axis.', gens: [
        () => { const m = nz(-4, 5), x1 = ri(-4, 3), y1 = ri(-5, 5), dx = ri(1, 4); return num(`What is the slope of the line through (${x1}, ${y1}) and (${x1 + dx}, ${y1 + m * dx})?`, m, `Rise ÷ run = ${m * dx} ÷ ${dx} = ${m}.`); },
        () => { const m = nz(-6, 6), b = nz(-9, 9); return mcn(`What is the slope of y = ${lin(m, b)}?`, m, 'In y = mx + b, the slope is the number multiplying x.', [b, -m]); },
        () => { const m = nz(-6, 6), b = nz(-9, 9); return mcn(`Where does y = ${lin(m, b)} cross the y-axis? (Give the y value.)`, b, 'In y = mx + b, the line crosses the y-axis at b.', [m, -b]); },
        () => { const m = nz(-5, 5), b = ri(-9, 9), x = ri(-4, 6); return num(`For y = ${lin(m, b)}, what is y when x = ${x}?`, m * x + b, `${m} × ${p(x)} = ${m * x}, then ${b < 0 ? 'subtract ' + -b : 'add ' + b}: ${m * x + b}.`); },
        () => { const m = pick([-2, -1, 1, 2, 3]), b = ri(-2, 2); return mcn('What is the slope of this line? The two dots are on the line.', m, `From one dot to the next, go right 1 and ${m > 0 ? 'up' : 'down'} ${Math.abs(m)}. Slope = ${m}.`, [-m, b === m ? m + 1 : b], figGrid([[0, b], [1, b + m]], -5, 5, [[0, b], [1, b + m]])); },
      ] },
      { name: 'Systems of equations', tip: 'A system is two equations that share an answer. If y = 2x + 1 and y = x + 4, set them equal: 2x + 1 = x + 4, so x = 3 and y = 7. The answer is the point (3, 7).', gens: [
        () => { const x = ri(-3, 5), m1 = nz(-3, 4), b1 = ri(-6, 6), y = m1 * x + b1; let m2 = nz(-3, 4); if (m2 === m1) m2 = m1 + 1 || 2; const b2 = y - m2 * x; return mc(`Solve the system:   y = ${lin(m1, b1)}   and   y = ${lin(m2, b2)}`, `(${x}, ${y})`, [`(${y}, ${x})`, `(${x + 1}, ${y})`, `(${x}, ${y + 1})`, `(${-x}, ${y})`, `(${x - 1}, ${y - 1})`], `Set them equal and solve: x = ${x}. Put it back in: y = ${y}.`); },
        () => { const x = ri(2, 12), y = ri(1, x - 1); return num(`x + y = ${x + y} and x - y = ${x - y}. What is x?`, x, `Add the two equations: 2x = ${2 * x}, so x = ${x}.`); },
        () => { const m = nz(-4, 4), b = ri(-6, 6), x = ri(-3, 5), ok = rnd() < 0.5, y = m * x + b + (ok ? 0 : pick([-2, -1, 1, 2])); return tf(`(${x}, ${y}) is a solution of y = ${lin(m, b)}.`, ok, `Put x = ${x} in: y = ${m * x + b}.`); },
        () => { const a = ri(1, 5), k = ri(1, 4), x = ri(1, 8); return num(`${lin(a, 0)} + y = ${(a + k) * x} and y = ${lin(k, 0)}. What is x?`, x, `Replace y with ${lin(k, 0)}: ${a + k}x = ${(a + k) * x}, so x = ${x}.`); },
      ] },
    ],
  });
})();
